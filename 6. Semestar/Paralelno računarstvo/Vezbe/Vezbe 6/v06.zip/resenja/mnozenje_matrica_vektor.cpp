#include <iostream>
#include <vector>

#include <omp.h>

#include "hpc_helpers.hpp"

template<typename value_t, typename index_t>
void init(
    std::vector<value_t> &matrica,
    std::vector<value_t> &vektor,
    index_t vrsta,
    index_t kolona
) {
    for (index_t i = 0; i < vrsta; i++) {
        for (index_t j = 0; j < kolona; j++) {
            matrica[i * kolona + j] = i >= j ? 1 : 0;
        }
    }
    for (index_t j = 0; j < kolona; j++) {
        vektor[j] = j;
    }
}


template<typename value_t, typename index_t>
void mnozenje_sekvencijalno(
    std::vector<value_t> &matrica, 
    std::vector<value_t> &vektor, 
    std::vector<value_t> &rez, 
    index_t vrsta, 
    index_t kolona
) {
    for (int i = 0; i < vrsta; i++) {
        for (int j = 0; j < kolona; j++) {
            rez[i] += matrica[i * kolona + j] * vektor[j];
        }
    }
}


template<typename value_t, typename index_t>
void mnozenje_openmp(
    std::vector<value_t> &matrica, 
    std::vector<value_t> &vektor,
    std::vector<value_t> &rez, 
    index_t vrsta, 
    index_t kolona,
    const index_t broj_niti
) {
    
    #pragma omp parallel for num_threads(broj_niti)
    for (index_t i = 0; i < vrsta; i++) {
        value_t sum = value_t(0);
        for (index_t j = 0; j < kolona; j++) {
            sum += matrica[i * kolona + j] * vektor[j];
        }
        rez[i] = sum;
    }
}


int main() {

    const unsigned int m = 1UL << 14;
    const unsigned int n = 1UL << 14;
    const unsigned int nt = 16UL;

    TIMERSTART(overall)

    TIMERSTART(alloc)
    std::vector<int> matrica(m*n);
    std::vector<int> vektor(n);
    std::vector<int> rezultat(m);
    TIMERSTOP(alloc)

    init(matrica, vektor, m, n);

    // zakomentarisati nakon sto implementirante mnozenje_openmp funkciju
    TIMERSTART(seq)
    mnozenje_sekvencijalno(matrica, vektor, rezultat, m, n);
    TIMERSTOP(seq)

    // otkomentarisati nakon sto implementirate mnozenje_openmp funkciju
    // TIMERSTART(openmp)
    // mnozenje_openmp(matrica, vektor, rezultat, m, n, nt);
    // TIMERSTOP(openmp)

    TIMERSTOP(overall)

    // ukoliko je rezultat u vektoru 'rezultat' tacan, ova petlja se
    // nece nista ispisati
    for (int i = 0; i < m; i++)
        if (rezultat[i] != i*(i+1)/2)
            std::cout << "error at position " << i << " "
                        << rezultat[i] << std::endl;


    return 0;
}