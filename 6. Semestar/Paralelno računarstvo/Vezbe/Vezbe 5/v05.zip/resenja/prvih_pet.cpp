// Resenje zadatka 6

#include <iostream>

using namespace std;

int main() {

    int proizvod = 1;

    #pragma omp parallel for reduction(*:proizvod)  // dodata reduction klauzula
    for (int i = 1; i <= 5; i++)
        proizvod *= i;

    cout << "Proizvod prvih pet elemenata je " << proizvod;
    cout << ", a treba da bude 120." << endl;

    return 0;
}