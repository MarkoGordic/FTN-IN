// Resenje zadatka 1

#include <iostream>
#include <omp.h>

using namespace std;


int main() {

    #pragma omp parallel num_threads(4)
    // cout << omp_get_thread_num() << endl;        // i ovo je ispravno resenje zadatka, preplitanje na izlazu
                                                    // je trenutno u redu
    cout << to_string(omp_get_thread_num()) + "\n"; // moze da se napise ovako da bi se izbeglo preplitanje na standardnom izlazu

    return 0;
}