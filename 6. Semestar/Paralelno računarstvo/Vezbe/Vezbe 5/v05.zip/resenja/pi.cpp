// Resenje zadatka 5

#include <iostream>
#include <vector>
#include <numeric>     // std::accumulate
#include <omp.h>

#include "hpc_helpers.hpp"

#define NOTIMPLEMENTED -1

static long num_steps = 1000000;


double pi_sekvencijalno() {
    int i;
    double x, pi, sum = 0.0;

    double step = 1.0 / (double) num_steps;

    for (i = 0; i < num_steps; i++) { 
        double x = (i + 0.5) * step;
        sum = sum + 4.0 / (1.0 + x * x);    
    }
    pi = step * sum;

    return pi;
}

// Resenje zadatka 5 (openmp termin 1)
double pi_openmp_parallel1(const int num_threads) {

    int i, nthreads;
    double x, pi;
    std::vector<double> sum(num_threads);

    double step = 1.0 / (double) num_steps;

    // Funkcijom omp_set_num_threads programer zapravo zahteva odredjeni broj niti,
    // sto ne znaci nuzno da ce zahtevani broj niti stvarno biti i pokrenut. Okruzenje
    // moze da odluci da napravi manji broj niti od zahtevanog.
    omp_set_num_threads(num_threads);
    #pragma omp parallel
    {
        int i, id, nthrds;
        id = omp_get_thread_num();
        // Kako zahtevani broj niti i broj napravljenih niti mogu biti razliciti, 
        // potrebno je unutar pralelnog regiona proveriti koliko je niti stvarno
        // napravljeno i aktivirano.
        nthrds = omp_get_num_threads();


        // Kako je neophodno sabrati sve parcijalne rezultate izvan paralelog regiona
        // (dovoljno je da) jedna od niti sacuva informaciju o broju aktivnih niti
        // unutar paralelnog regiona. Kada se paralelni region zavrsi, sve niti koje 
        // su vrsile racun osim master niti ce biti termisane i ova informacija vise
        // nece biti dostupna.
        if (id == 0) nthreads = nthrds;

        // Round-robin raspodela intervala. Stetno preplitanje uklonjeno
        // tako sto svaka nit ima svoju promenljivu u koju upisuje rezultat
        // racunanja.
        for (i = id, sum[id] = 0; i < num_steps; i += nthrds) { 
            double x = (i + 0.5) * step;
            sum[id] = sum[id] + 4.0 / (1.0 + x * x);    // ova linija dovodi do laznog deljenja (false sharing)
                                                        // razmisliti o tome kako bi se ovo moglo resiti
        }
    }
    pi = std::accumulate(sum.begin(), sum.end(), 0.0f); // akumulira sve elemente vektora sum
    pi *= step;  

    return pi;
}

// Resenje zadatka 5 koriscenjem reduction klauzule (openmp termin 1)
double pi_openmp_parallel2(const int num_threads) {
    int i;
    double x, pi, sum = 0.0;

    double step = 1.0 / (double) num_steps;

    {
        // Svaka nit napravi svoju privatnu kopiju promenljive sum. 
        // Po redukcionim pravilima, svaka privatna promenljiva sum dobija inicijalnu
        // vrednost 0.0. Svaka nit akumulira sracunate vrednosti nad svojom privatnom
        // kopijom. Pre zavrsetka paralelnog regiona vrednosti svi privatnih kopija
        // promenljive sum se dodaju deljenoj promenljivoj sum, a privatne kopije se
        // smatraju unistenim.
        #pragma omp parallel for reduction(+:sum)
        for (i = 0; i < num_steps; i++) { 
            double x = (i + 0.5) * step;
            sum = sum + 4.0 / (1.0 + x * x);
        }
    }

    return step * sum;
}

double pi_openmp_parallel3(const int num_threads) {
    // TODO implementirati resenje zadatka 8 (openmp vezbe 2)
}


int main() {

    const int broj_niti = 4;

    TIMERSTART(seq)
    double pi1 = pi_sekvencijalno();
    TIMERSTOP(seq)

    TIMERSTART(openmp_parallel)
    double pi2 = pi_openmp_parallel1(broj_niti);
    TIMERSTOP(openmp_parallel)

    TIMERSTART(openmp_parallel_reduction)
    double pi3 = pi_openmp_parallel2(broj_niti);
    TIMERSTOP(openmp_parallel_reduction)

    TIMERSTART(openmp_parallel_sync)
    double pi4 = pi_openmp_parallel3(broj_niti);
    TIMERSTOP(openmp_parallel_sync)

    std::cout << "[pi_sekvencijalno]    pi = " << pi1 << std::endl;
    std::cout << "[pi_openmp_parallel1] pi = " << pi2 << std::endl;
    std::cout << "[pi_openmp_parallel2] pi = " << pi3 << std::endl;
    std::cout << "[pi_openmp_parallel3] pi = " << pi4 << std::endl;

    return 0;
}

