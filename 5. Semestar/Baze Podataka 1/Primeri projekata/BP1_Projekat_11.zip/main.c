//Projektni zadatak #11

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

#define MAXIME 51
#define MAXSMER 5
#define MAXPREDMET 31
#define MAX_NAZIV_DATOTEKE 256

//za drugi deo

#define B 7 //broj baketa
#define b 5 //faktor baketiranja
#define b_owerflow 1
#define MAX_OWERFLOW (B*b_owerflow)
#define MAX_RECORDS (B*b+MAX_OWERFLOW)
#define STATUS_AKTIVAN 1
#define STATUS_OBRISAN 0

#define FAKTOR_BLOKIRANJA_LOG 4

char naziv_datoteke_studenti[MAX_NAZIV_DATOTEKE]="";
char naziv_datoteke_polaganja[MAX_NAZIV_DATOTEKE]="";
char naziv_datoteke_ag[MAX_NAZIV_DATOTEKE]="";
char naziv_log_datoteke[MAX_NAZIV_DATOTEKE]="log.dat";

int FAKTOR_BLOKIRANJA_STUDENT=5;
int FAKTOR_BLOKIRANJA_POLAGANJA=4;

typedef struct
{
   int studentski_broj; // identifikator studenta
   char ime_i_prezime[MAXIME];
   char smer[MAXSMER];
   int broj_dosijea;
   int godina_upisa;
   int godina_studija;
}Student;

typedef struct
{
    int identifikator;
    int studentski_broj;
    char naziv_predmeta[MAXPREDMET];
    int ocena; //od 5-10
    int broj_predispitnih_poena;
    int broj_ispitnih_poena;

}PolaganjeIspita;

typedef struct
{
    int studentski_broj;
    char ime_prezime[MAXIME];
    char smer[MAXSMER];
    int broj_dosijea;
    int godina_upisa;
    int godina_studija;
    int broj_nepolozenih_ispita;
    int broj_izlazaka;
    float prosek_predispitnih;
    int status;
    int sled;

}AgregiraniSlogovi;

typedef struct{
	int identifikator;
	int identifikator_za_pristup;
	char broj_pristupa[60];
}LogZapis;

//pomocne funkcije
void ocisti_buffer(){
    int c;
    while ((c=getchar()) != '\n' && c !=EOF); //cita dok ne dodje do kraja
}

int provera_ascii(const char* tekst) {
    for (int i = 0; tekst[i]; i++) {
        if ((unsigned char)tekst[i] < 32 || (unsigned char)tekst[i] > 127)
            return 0;
    }
    return 1;
}

void ocisti_novi_red(char* str){
    str[strcspn(str, "\n")]=0;
}

int poredi_studente_po_broju(const void* a, const void* c) {
    Student* s1 = (Student*)a;
    Student* s2 = (Student*)c;
    return s1->studentski_broj - s2->studentski_broj;
}

int je_naziv_datoteke_prazan(const char* naziv) {
    return (naziv[0] == '\0');
}

int preklapanje(int id){
    int suma=0;
    
    while (id>0)
    {
 
        suma+=id%10;
        id/=10;
    }
    return suma %B;


}

void formiraj_datoteku_studenata(){
    char temp_naziv[MAX_NAZIV_DATOTEKE];
    printf("Unesite naziv datoteke za studente (npr. studenti.dat): ");
    scanf("%s", temp_naziv);
    ocisti_buffer();

    strncpy(naziv_datoteke_studenti, temp_naziv, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_studenti[MAX_NAZIV_DATOTEKE-1]='\0';

    FILE* f= fopen(naziv_datoteke_studenti, "wb");
    if(!f){
        printf("Došlo je do greške pri kreiranju datoteke. \n");
        naziv_datoteke_studenti[0]='\0';
        return;
    }

    printf("Prazna datoteka '%s' za evidenciju studenata je uspesno kreirana (faktor blokiranja f1=%d).\n", naziv_datoteke_studenti, FAKTOR_BLOKIRANJA_STUDENT);
    fclose(f);
}

void formiraj_datoteku_polaganja() {
    char temp_naziv[MAX_NAZIV_DATOTEKE];
    printf("Unesite naziv datoteke za polaganja ispita (npr. polaganja.dat): ");
    scanf("%s", temp_naziv);
    ocisti_buffer();

    strncpy(naziv_datoteke_polaganja, temp_naziv, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_polaganja[MAX_NAZIV_DATOTEKE-1]='\0';

    FILE* f = fopen(naziv_datoteke_polaganja, "wb");
    if (!f) {
        printf("Došlo je do greške pri kreiranju datoteke.\n");
        naziv_datoteke_polaganja[0]='\0';
        return;
    }
    printf("Prazna datoteka '%s' za evidenciju polaganja ispita je uspesno kreirana (faktor blokiranja f2=%d).\n", naziv_datoteke_polaganja, FAKTOR_BLOKIRANJA_POLAGANJA);
    fclose(f);
}

void formiraj_staticku_datoteku(){
    char temp_naziv[MAX_NAZIV_DATOTEKE];
    printf("Unesite naziv rasute datoteke (npr. rasuta.dat): \n");
    scanf("%s", temp_naziv);
    ocisti_buffer();

    strncpy(naziv_datoteke_ag, temp_naziv, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_ag[MAX_NAZIV_DATOTEKE-1]='\0';
    
    char temp_naziv_s[MAX_NAZIV_DATOTEKE];
	char temp_naziv_p[MAX_NAZIV_DATOTEKE];
	printf("Unesite naziv datoteke za studente\n");
	scanf("%s", temp_naziv_s);
    ocisti_buffer();

    strncpy(naziv_datoteke_studenti, temp_naziv_s, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_studenti[MAX_NAZIV_DATOTEKE-1]='\0';
    
    printf("Unesite naziv datoteke za polaganje\n");
	scanf("%s", temp_naziv_p);
    ocisti_buffer();

    strncpy(naziv_datoteke_polaganja, temp_naziv_p, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_polaganja[MAX_NAZIV_DATOTEKE-1]='\0';
    

    if (je_naziv_datoteke_prazan(naziv_datoteke_studenti) ||je_naziv_datoteke_prazan(naziv_datoteke_polaganja)) {
        printf("Nazivi datoteka za studente ili polaganja nisu postavljeni.\n");
        return;
    }

    FILE *fs= fopen(naziv_datoteke_studenti, "rb");
    FILE *fp= fopen(naziv_datoteke_polaganja, "rb");
    FILE *fa= fopen(naziv_datoteke_ag, "wb");

    if(!fs || !fp || !fa){
        printf("Greska pri otvaranju datoteka. \n");
        return;

    }

    AgregiraniSlogovi* svi_slogovi=(AgregiraniSlogovi*)calloc(MAX_RECORDS, sizeof(AgregiraniSlogovi));
    Student* blok_student= (Student*)calloc(FAKTOR_BLOKIRANJA_STUDENT, sizeof(Student));
    PolaganjeIspita* blok_polaganje= (PolaganjeIspita*)calloc(FAKTOR_BLOKIRANJA_POLAGANJA, sizeof(PolaganjeIspita));

    if(!svi_slogovi || !blok_student || !blok_polaganje){
        printf("Greska pri alociranju memorije.\n");
        free(svi_slogovi);
        free(blok_student);
        free(blok_polaganje);
        fclose(fs);
        fclose(fp);
        fclose(fa);
        return;
    }
    char* zauzeto=(char*)calloc(MAX_RECORDS, sizeof(char));
    size_t procitano_s;
    
    int slobodna_serijska=B*b; //pokazivac na prvi slobodan prostor u zoni prekoracenja

    while((procitano_s=fread(blok_student, sizeof(Student), FAKTOR_BLOKIRANJA_STUDENT, fs))>0){
        for(size_t i=0; i<procitano_s; i++){
            int nepolozeni=0, izlazaka=0, zbir_predispitnih=0;

            rewind(fp);
            size_t procitano_p;

            while((procitano_p=fread(blok_polaganje, sizeof(PolaganjeIspita), FAKTOR_BLOKIRANJA_POLAGANJA, fp))>0){
                for(size_t j=0; j<procitano_p; j++){
                    if(blok_polaganje[j].studentski_broj==blok_student[i].studentski_broj){
                        izlazaka++;
                        zbir_predispitnih+=blok_polaganje[j].broj_predispitnih_poena;
                        if(blok_polaganje[j].ocena==5) nepolozeni++;
                    }
                }
            }

            int adr= preklapanje(blok_student[i].studentski_broj);
            int k= adr*b;
            int upisano=0;
            
            AgregiraniSlogovi novi;
            novi.studentski_broj= blok_student[i].studentski_broj;
            strcpy(novi.ime_prezime, blok_student[i].ime_i_prezime);
            strcpy(novi.smer, blok_student[i].smer);
            novi.broj_dosijea=blok_student[i].broj_dosijea;
            novi.godina_upisa=blok_student[i].godina_upisa;
            novi.broj_nepolozenih_ispita= nepolozeni;
            novi.broj_izlazaka= izlazaka;
            novi.prosek_predispitnih= (izlazaka>0) ? ((float)zbir_predispitnih/izlazaka):0;
            novi.status= STATUS_AKTIVAN;
            novi.sled=-1;

            //trazim u primarnom baketu
            for(int m=0; m<b; m++, k++){
                if(!zauzeto[k]){
                    svi_slogovi[k]=novi;
                    zauzeto[k]=1;
                    upisano=1;
                    break;
                }
            }

            //trazim u zoni prekoracenja
            if(!upisano){
                if(slobodna_serijska<MAX_RECORDS){
                	int pozicija= slobodna_serijska++;
                	svi_slogovi[pozicija]=novi;
                	zauzeto[pozicija]=1;
                	
                	int pocetak = adr*b;
                	int poslednji=-1;
                	for(int m=0; m<b; m++){
                		if(zauzeto[pocetak+m]){
                			poslednji=pocetak+m;
                			while(svi_slogovi[poslednji].sled !=-1){
                				poslednji=svi_slogovi[poslednji].sled; // trazim poslednji u primarnoj zoni koji dobija pokazivac na prvi u serijskoj zoni
                			}
                			break;
                		}
                	}
                	
                	if(poslednji!=-1){
                		svi_slogovi[poslednji].sled=pozicija; //smestam ga
                	}
                } else{
                	printf("Nema vise mesta u serijskoj zoni\n");
                }
            }

        }
    }

    fwrite(svi_slogovi, sizeof(AgregiraniSlogovi), MAX_RECORDS, fa);
    printf("Datoteka sa staticki rasutom organizacijom je formirana.\n");

    free(blok_polaganje);
    free(blok_student);
    free(zauzeto);
    free(svi_slogovi);

    fclose(fs);
    fclose(fp);
    fclose(fa);

}

void evidentiraj_log(int identifikator_za_pristup, int broj_pristupa){
    FILE *f= fopen(naziv_log_datoteke, "r+b");
    if(!f) f=fopen(naziv_log_datoteke, "w+b");
    if(!f){
        printf("Greska pri otvaranju log fajla.\n");
        return;
    }

    LogZapis blok[FAKTOR_BLOKIRANJA_LOG];
    int id=1;
    size_t procitano;
    rewind(f);
    while ((procitano= fread(blok, sizeof(LogZapis), FAKTOR_BLOKIRANJA_LOG, f))>0){
        id+= procitano; //cita koliko slogova ima log datoteka
    }

    //upis
    LogZapis novi= {id, identifikator_za_pristup, ""};
    sprintf(novi.broj_pristupa, "%d", broj_pristupa);

    fseek(f,0, SEEK_END);
    fwrite(&novi, sizeof(LogZapis),1,f);
    fclose(f);

}

void azuriraj_agregirani_slog(int broj, Student* student_info){

	if(je_naziv_datoteke_prazan(naziv_datoteke_ag)|| je_naziv_datoteke_prazan(naziv_datoteke_studenti) || je_naziv_datoteke_prazan(naziv_datoteke_polaganja)){
	return;
	}
    FILE *fa= fopen(naziv_datoteke_ag, "rb+");
    FILE *fp= fopen(naziv_datoteke_polaganja, "rb+");
    FILE *fs= fopen(naziv_datoteke_studenti, "rb");
    if(!fa|| !fp || !fs){
        printf("Greska pri otvaranju datoteka za azuriranje.\n");
        return;

    }

    AgregiraniSlogovi svi[MAX_RECORDS];
    fread (svi, sizeof(AgregiraniSlogovi), MAX_RECORDS, fa);

    Student s;
    
    if(student_info !=NULL){
    	s=*student_info;
    }else{
    	int pronadjen=0;
    	rewind(fs);
    	while(fread(&s, sizeof(Student),1,fs)){
    		if(s.studentski_broj==broj){
    			pronadjen=1;
    			break;
    		}
    	}
    	if(!pronadjen){
    		printf("Student sa brojem %d nije pronadjen.\n", broj);
    		fclose(fa);
    		fclose(fp);
    		fclose(fs);
    		return;
    	}
    }

    rewind(fp);
    int nepolozeni=0, izlazaka=0, zbir_predispitnih=0;
    PolaganjeIspita p;
    while(fread(&p, sizeof(PolaganjeIspita),1,fp)){
        if(p.studentski_broj==broj){
            izlazaka++;
            zbir_predispitnih += p.broj_predispitnih_poena;
            if(p.ocena== 5){
                nepolozeni++;
            }
        }
    }

    AgregiraniSlogovi novi;
    novi.studentski_broj= s.studentski_broj;
    strcpy(novi.ime_prezime, s.ime_i_prezime);
    strcpy(novi.smer, s.smer);
    novi.broj_dosijea= s.broj_dosijea;
    novi.godina_upisa= s.godina_upisa;
    novi.godina_studija= s.godina_studija;
    novi.broj_nepolozenih_ispita= nepolozeni;
    novi.broj_izlazaka= izlazaka;
    novi.prosek_predispitnih= (izlazaka>0) ? (float)zbir_predispitnih/izlazaka : 0.0f;
    novi.status= STATUS_AKTIVAN;

    int adr= preklapanje(novi.studentski_broj);
    int k= adr*b;
    int pristupa=0;
    int upisano= 0;

    for(int i=0; i<b; i++, k++, pristupa++){
        if(svi[k].status != STATUS_AKTIVAN || svi[k].studentski_broj== novi.studentski_broj){
            svi[k]=novi;
            upisano=1;
            break;
        }
    }
    if(!upisano){
        for(int i=B*b; i< MAX_RECORDS ; i++, pristupa++){
            if(svi[i].status != STATUS_AKTIVAN || svi[i].studentski_broj== novi.studentski_broj){
            	svi[i]=novi;
            	upisano=1;
            	svi[i].sled=-1;
            	
            	//na lanac
            	int pocetak= adr*b;
            	int poslednji= -1;
            	for(int m=0; m<b; m++){
            		if(svi[pocetak+m].status== STATUS_AKTIVAN){
            			poslednji=pocetak+m;
            			while(svi[poslednji].sled != -1){
            				poslednji= svi[poslednji].sled;
            			}
            			break;
            			
            		}
            	}
            	if(poslednji !=-1){
            		svi[poslednji].sled=i;
            	}
            	break;
            }
        }
    }

    evidentiraj_log(novi.studentski_broj, pristupa);
    rewind(fa);
    fwrite(svi, sizeof(AgregiraniSlogovi), MAX_RECORDS, fa);

	printf("Datoteka je uspesno azurirana\n");
    fclose(fa);
    fclose(fp);
   	fclose(fs);

}

void unos_studenata(){
	
	char temp_naziv[MAX_NAZIV_DATOTEKE];
	printf("Unesite naziv datoteke za unos studenta\n");
	scanf("%s", temp_naziv);
    ocisti_buffer();

    strncpy(naziv_datoteke_studenti, temp_naziv, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_studenti[MAX_NAZIV_DATOTEKE-1]='\0';
	
    if(je_naziv_datoteke_prazan(naziv_datoteke_studenti)){
        printf("Naziv datoteke za studente nije postavljen. \n");
        return;
    }
    
    
    FILE* f= fopen(naziv_datoteke_studenti, "rb");

    Student* svi_studenti=NULL;
    long broj_postojecih_slogova=0;

    //citanje postojecih podataka
    if(f){
        fseek(f,0,SEEK_END);
        long velicina_datoteke=ftell(f); //ukupna velicina datoteke
        fseek(f,0,SEEK_SET);

        if(velicina_datoteke>0){
            broj_postojecih_slogova=velicina_datoteke/sizeof(Student);
            svi_studenti= (Student*)malloc(broj_postojecih_slogova*sizeof(Student)); //u svi_studenti smestam postojece studente
            if(svi_studenti==NULL){
                printf("Greska pri alociranju memorije za postojece studente.\n");
                fclose(f);
                return;
            }
            fread(svi_studenti, sizeof(Student), broj_postojecih_slogova, f);
            if(broj_postojecih_slogova>0){
            qsort(svi_studenti, broj_postojecih_slogova, sizeof(Student), poredi_studente_po_broju);
            }
        }
        fclose(f);
    }
    //unos studenata

    char nastavi_upis='d';
    while(nastavi_upis=='d'){
        Student s;
        printf("---UNOS STUDENATA---\n");

        printf("Studentski broj:");
        scanf("%d", &s.studentski_broj);
        ocisti_buffer();

        if(svi_studenti!= NULL){
           
            if(bsearch(&s, svi_studenti, broj_postojecih_slogova, sizeof(Student), poredi_studente_po_broju) !=NULL){
                printf("Student sa brojem %d vec postoji. Molimo Vas da unesite jedinstven broj.\n", s.studentski_broj);
                continue;
            }
        }

        printf("Ime i prezime:");
        fgets(s.ime_i_prezime, MAXIME, stdin);
        ocisti_novi_red(s.ime_i_prezime);
        if (provera_ascii(s.ime_i_prezime) == 0 || strlen(s.ime_i_prezime) == 0) {
            printf("Nevalidan unos karaktera ili prazno ime i prezime.\n");
            continue;
        }

        printf("Smer (max %d karaktera): ", MAXSMER - 1);
        fgets(s.smer, MAXSMER, stdin);
        ocisti_novi_red(s.smer);
        if (provera_ascii(s.smer) == 0 || strlen(s.smer) == 0) {
            printf("Nevalidan unos karaktera ili prazan smer.\n");
            continue;
        }

        printf("Broj dosijea: ");
        scanf(" %d", &s.broj_dosijea);
        ocisti_buffer();

        printf("Godina upisa: ");
        scanf(" %d", &s.godina_upisa);
        ocisti_buffer();

        printf("Godina studija: ");
        scanf(" %d", &s.godina_studija);
        ocisti_buffer();



        //dodavanje studenta u listu u memoriji

        broj_postojecih_slogova++;
        svi_studenti=(Student*)realloc(svi_studenti, broj_postojecih_slogova*sizeof(Student));
        if (svi_studenti == NULL) {
            printf("Greska pri realociranju memorije za novog studenta.\n");
            exit(EXIT_FAILURE); // Fatalna greska
        }
        svi_studenti[broj_postojecih_slogova - 1] = s;

        azuriraj_agregirani_slog(s.studentski_broj, &s);

        printf("Nastavi unos? (uneti d/n): ");
        if (scanf(" %c", &nastavi_upis) != 1) {
            // Ako je unos nevalidan, pretpostavimo 'n' za prekid
            nastavi_upis = 'n';
        }
        ocisti_buffer();

        //sortiranje studenata u memoriji

        if(svi_studenti!= NULL && broj_postojecih_slogova>0){
            qsort(svi_studenti, broj_postojecih_slogova, sizeof(Student), poredi_studente_po_broju);

            f=fopen(naziv_datoteke_studenti, "wb");
            if(!f){
            	printf("Greska pri otvaranju datoteke za upis. \n");
            }else{
                for(long i=0; i<broj_postojecih_slogova; i=i+FAKTOR_BLOKIRANJA_STUDENT){
                    long broj_za_pisanje= (broj_postojecih_slogova-i<FAKTOR_BLOKIRANJA_STUDENT) ? (broj_postojecih_slogova-i) : FAKTOR_BLOKIRANJA_STUDENT;
                    fwrite(&svi_studenti[i], sizeof(Student), broj_za_pisanje, f);
                }
            fclose(f);
            printf("Svi studenti su uspesno sacuvani i sortirani u datoteci.\n");
            }
        }else{
            f=fopen(naziv_datoteke_studenti, "wb");
            if(f) fclose(f);
            printf("Nema studenata za unos. Datoteka je prazna.");
        }


    }
      free(svi_studenti);
      printf("Unos studenata je zavrsen.\n");

}

void unos_polaganja(){
	
	char temp_naziv[MAX_NAZIV_DATOTEKE];
	printf("Unesite naziv datoteke za unos polaganja\n");
	scanf("%s", temp_naziv);
    ocisti_buffer();

    strncpy(naziv_datoteke_polaganja, temp_naziv, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_polaganja[MAX_NAZIV_DATOTEKE-1]='\0';
	
    if(je_naziv_datoteke_prazan(naziv_datoteke_polaganja)){
        printf("Naziv datoteke za polaganja nije postavljen. \n");
        return;
    }


    FILE* f= fopen(naziv_datoteke_polaganja,"a+b");
    if(!f){
        printf("Datoteka ne postoji ili je došlo do greške pri otvaranju. \n");
        return;
    }

    fseek(f,0, SEEK_END);
    PolaganjeIspita* blok=(PolaganjeIspita*)calloc(FAKTOR_BLOKIRANJA_POLAGANJA,sizeof(PolaganjeIspita));
    if (blok == NULL) {
        printf("Greska pri alociranju memorije.\n");
        fclose(f);
        return;
    }
    int i=0;

    char nastavi_upis='d';
    while (nastavi_upis=='d')
    {
        PolaganjeIspita p;
        printf("Unos polaganja:\n");

        printf("Identifikator: ");
        scanf("%d", &p.identifikator);
        ocisti_buffer();

        printf("Studentski broj: ");
        scanf("%d", &p.studentski_broj);
        ocisti_buffer();

        printf("Naziv predmeta (max %d karaktera): ", MAXPREDMET-1);
        fgets(p.naziv_predmeta, MAXPREDMET, stdin);
        ocisti_novi_red(p.naziv_predmeta);
         if(provera_ascii(p.naziv_predmeta)==0){
            printf("Nevalidan unos karaktera.\n");
            continue;
        }

        do{
            printf("Ocena (5-10): ");
            scanf("%d", &p.ocena);
            ocisti_buffer();

            if (p.ocena < 5 || p.ocena > 10) {
            printf("Greška: ocena mora biti između 5 i 10.\n");
            }
        }while(p.ocena<5 || p.ocena>10);

        printf("Predispitni poeni: ");
        scanf("%d", &p.broj_predispitnih_poena);
        ocisti_buffer();

        printf("Ispitni poeni: ");
        scanf("%d", &p.broj_ispitnih_poena);
        ocisti_buffer();

        blok[i++]= p;

        azuriraj_agregirani_slog(p.studentski_broj, NULL);


        if(i==FAKTOR_BLOKIRANJA_POLAGANJA){ //4
            fseek(f,0, SEEK_END);
            fwrite(blok, sizeof(PolaganjeIspita), FAKTOR_BLOKIRANJA_POLAGANJA, f);
            i=0;
        }
        printf("Nastavi unos?(uneti d/n)");
        scanf("%c", &nastavi_upis);
        ocisti_buffer();

    }

    if(i>0){ //za poslednje blokove ako ostanu nepopunjeni
        fseek(f,0,SEEK_END);
        fwrite(blok, sizeof(PolaganjeIspita), i ,f);

    }

    free(blok);
    fclose(f);
    printf("Unos polaganja zavrsen.\n");

}

void prikaz_godine_i_indeksa(){
	
	char temp_naziv[MAX_NAZIV_DATOTEKE];
	printf("Unesite naziv datoteke za prikaz studenata\n");
	scanf("%s", temp_naziv);
    ocisti_buffer();

    strncpy(naziv_datoteke_studenti, temp_naziv, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_studenti[MAX_NAZIV_DATOTEKE-1]='\0';
	
    if(je_naziv_datoteke_prazan(naziv_datoteke_studenti)){
        printf("Naziv datoteke za studente nije postavljen. \n");
        return;
    }
 
    FILE* f= fopen(naziv_datoteke_studenti, "rb");
    if(!f){
        printf("Datoteka ne postoji ili je došlo do greške pri otvaranju. \n");
        return;
    }

    int zadati_broj;
    printf("Unesite studentski broj: ");
    scanf("%d", &zadati_broj);
    ocisti_buffer();

    Student* blok =(Student*)calloc(FAKTOR_BLOKIRANJA_STUDENT, sizeof(Student));
    if (blok == NULL) {
        printf("Greska pri alociranju memorije.\n");
        fclose(f);
        return;
    }

    int adresa_bloka=0;
    int pronadjen=0;
    size_t procitano;

    while((procitano=fread(blok, sizeof(Student), FAKTOR_BLOKIRANJA_STUDENT, f))>0){
        for(size_t i=0; i<procitano; i++){
            if(blok[i].studentski_broj==zadati_broj){
                printf("Podaci o traženom studentu: \n");
                printf("Godina studija: %d\n", blok[i].godina_studija);
                printf("Indeks: %s %d/%d\n", blok[i].smer, blok[i].broj_dosijea, blok[i].godina_upisa);
                printf("Adresa bloka: %d\n", adresa_bloka);
                printf("Redni broj sloga u bloku: %zu\n", i);
                pronadjen=1;
                break;
            }
        }
        if (pronadjen) break;
        adresa_bloka++;

    }

    if (!pronadjen)
    {
        printf("Studnet sa traženim studentskim brojem nije pronadjen.\n");
    }

    free(blok);
    fclose(f);
}

void uslov_studenti(){
	
	char temp_naziv_s[MAX_NAZIV_DATOTEKE];
	char temp_naziv_p[MAX_NAZIV_DATOTEKE];
	printf("Unesite naziv datoteke za studente\n");
	scanf("%s", temp_naziv_s);
    ocisti_buffer();

    strncpy(naziv_datoteke_studenti, temp_naziv_s, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_studenti[MAX_NAZIV_DATOTEKE-1]='\0';
    
    printf("Unesite naziv datoteke za polaganje\n");
	scanf("%s", temp_naziv_p);
    ocisti_buffer();

    strncpy(naziv_datoteke_polaganja, temp_naziv_p, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_polaganja[MAX_NAZIV_DATOTEKE-1]='\0';
	

    if (je_naziv_datoteke_prazan(naziv_datoteke_studenti) || je_naziv_datoteke_prazan(naziv_datoteke_polaganja)) {
        printf("Nazivi datoteka za studente ili polaganja nisu postavljeni.\n");
        return;
    }

    FILE* fs= fopen(naziv_datoteke_studenti, "rb");
    FILE* fp= fopen(naziv_datoteke_polaganja, "rb");

     if (!fs || !fp) {
        printf("Jedna od datoteka ne postoji ili je došlo do greške pri otvaranju.\n");
        return;
    }

    Student* blok_student= (Student*)calloc(FAKTOR_BLOKIRANJA_STUDENT, sizeof(Student));
    PolaganjeIspita* blok_polaganje= (PolaganjeIspita*)calloc(FAKTOR_BLOKIRANJA_POLAGANJA, sizeof(PolaganjeIspita));

    if (blok_student == NULL || blok_polaganje == NULL) {
        printf("Greska pri alociranju memorije.\n");
        if(blok_student) free(blok_student);
        if(blok_polaganje) free(blok_polaganje);
        fclose(fs);
        fclose(fp);
        return;
    }

    int adresa_bloka=0;
    int pronadjen_uslov=0;
    size_t procitano_s;

    while((procitano_s=fread(blok_student, sizeof(Student), FAKTOR_BLOKIRANJA_STUDENT, fs))>0){
        for (size_t i = 0; i < procitano_s; i++)
        {
            if(blok_student[i].godina_upisa==2023){
                int zbir_predispitnih=0;
                int procitano_p;
                rewind(fp);

                while ((procitano_p=fread(blok_polaganje, sizeof(PolaganjeIspita), FAKTOR_BLOKIRANJA_POLAGANJA, fp))>0){
                    for(size_t j=0; j<procitano_p; j++){
                        if(blok_polaganje[j].studentski_broj==blok_student[i].studentski_broj){
                            zbir_predispitnih+=blok_polaganje[j].broj_ispitnih_poena;
                        }
                    }
                }

                if(zbir_predispitnih==70){
                    printf("Podaci o trašenom studentu:\n");
                    printf("Ime i prezime : %s\n", blok_student[i].ime_i_prezime);
                    printf("Smer: %s\n", blok_student[i].smer);
                    printf("Indeks: %s %d/%d\n", blok_student[i].smer, blok_student[i].broj_dosijea, blok_student[i].godina_upisa);
                    printf("Godina studija: %d\n", blok_student[i].godina_studija);
                    printf("Ukupno predispitnih poena: 70\n");
                    printf("Adresa bloka: %d\n", adresa_bloka);
                    printf("Redni broj slogа u bloku: %zu\n", i);
                    pronadjen_uslov = 1;
                }
            }
        }
        adresa_bloka++;
    }

    if(!pronadjen_uslov){
        printf("Ni jedan student ne odgovara zadatom kriterijumu\n");
    }

    free(blok_student);
    free(blok_polaganje);

    fclose(fs);
    fclose(fp);

}

void izmeni_studenta(){

	char temp_naziv[MAX_NAZIV_DATOTEKE];
	printf("Unesite naziv datoteke za studente\n");
	scanf("%s", temp_naziv);
    ocisti_buffer();

    strncpy(naziv_datoteke_studenti, temp_naziv, MAX_NAZIV_DATOTEKE-1);
    naziv_datoteke_studenti[MAX_NAZIV_DATOTEKE-1]='\0';

    if (je_naziv_datoteke_prazan(naziv_datoteke_studenti)) {
        printf("Naziv datoteke za studente nije postavljen. Molimo prvo formirajte datoteku (Opcija 1).\n");
        return;
    }

    FILE* f= fopen(naziv_datoteke_studenti,"r+b");
    if(!f){
        printf("Datoteka ne postoji ili je došlo do greške pri otvaranju. \n");
        return;
    }

    Student* blok = (Student*)calloc(FAKTOR_BLOKIRANJA_STUDENT, sizeof(Student));
    if (blok == NULL) {
        printf("Greska pri alociranju memorije.\n");
        fclose(f);
        return;
    }

    int trazeni;

    printf("Unesite studentski broj za menjanje: ");
    scanf("%d", &trazeni);
    ocisti_buffer();

    int pronadjen=0;
    long pozicija_bloka=0;
    size_t procitano;

    while ((procitano=fread(blok, sizeof(Student), FAKTOR_BLOKIRANJA_STUDENT, f))>0 && !pronadjen)
    {
        for(size_t i=0; i<procitano; i++){
            if(blok[i].studentski_broj==trazeni){
                printf("Izmenite informacije: \n");

                printf("Ime i prezime: ");
                fgets(blok[i].ime_i_prezime, MAXIME, stdin);
                ocisti_novi_red(blok[i].ime_i_prezime);
                if (provera_ascii(blok[i].ime_i_prezime) == 0) {
                    printf("Nevalidan unos karaktera za ime i prezime. Izmena nece biti primenjena.\n");
                }

                printf("Smer: ");
                fgets(blok[i].smer, MAXSMER, stdin);
                ocisti_novi_red(blok[i].smer);
                if (provera_ascii(blok[i].smer) == 0) {
                    printf("Nevalidan unos karaktera za smer. Izmena nece biti primenjena.\n");
                }

                printf("Broj dosijea: ");
                scanf("%d", &blok[i].broj_dosijea);
                ocisti_buffer();

                printf("Godina upisa: ");
                scanf("%d", &blok[i].godina_upisa);
                ocisti_buffer();


                printf("Godina studija: ");
                scanf(" %d", &blok[i].godina_studija);
                ocisti_buffer();

                fseek(f, pozicija_bloka, SEEK_SET);
                fwrite(blok, sizeof(Student), procitano, f);
                azuriraj_agregirani_slog(blok[i].studentski_broj, &blok[i]);
                printf("Student je uspesno izmenjen.\n");
                pronadjen = 1;
                break;
            }
        }
        if (!pronadjen) {
            pozicija_bloka= ftell(f); //cuva poziciju fajla
        }
    }
    if(!pronadjen){
        printf("Student nije pronadjen.\n");
    }
    

    free(blok);
    fclose(f);

}

void upis_sloga_ag(){
    if (je_naziv_datoteke_prazan(naziv_datoteke_ag)) {
        printf("Naziv datoteke nije postavljen. Molimo prvo formirajte datoteku.\n");
        return;
    }

    FILE* f= fopen(naziv_datoteke_ag,"r+b");
    if(!f){
        printf("Datoteka ne postoji ili je došlo do greške pri otvaranju. \n");
        return;
    }

    AgregiraniSlogovi svi[MAX_RECORDS];
    fread(svi, sizeof(AgregiraniSlogovi), MAX_RECORDS, f);

    AgregiraniSlogovi novi;
    printf("Unesite studentski broj\n");
    scanf("%d", &novi.studentski_broj);
    ocisti_buffer();

    int adr=preklapanje(novi.studentski_broj);
    int k= adr*b;
    for(int i= 0; i<b; i++){
    	if(svi[k+i].status==STATUS_AKTIVAN && svi[k+i].studentski_broj== novi.studentski_broj){
    		printf("Student sa tim studentskim brojem vec postoji.\n");
    		fclose(f);
    		return;
    	}
    }

    printf("Ime i prezime:");
    fgets(novi.ime_prezime, MAXIME, stdin);
    ocisti_novi_red(novi.ime_prezime);

    printf("Smer: ");
    fgets(novi.smer, MAXSMER, stdin);
    ocisti_novi_red(novi.smer);

    printf("Broj dosijea: ");
    scanf("%d", &novi.broj_dosijea);
    ocisti_buffer();

    printf("Godina studija: ");
    scanf("%d", &novi.godina_studija);
    ocisti_buffer();

    printf("Broj nepolozenih ispita: ");
    scanf("%d", &novi.broj_nepolozenih_ispita);
    ocisti_buffer();

    printf("Broj izlazaka: ");
    scanf("%d", &novi.broj_izlazaka);
    ocisti_buffer();

    printf("Prosek predispitnih poena: ");
    scanf("%f", &novi.prosek_predispitnih);
    ocisti_buffer();

    novi.status=STATUS_AKTIVAN;
    novi.sled=-1;

    int upisano=0;

	// primarni baket
    for(int i=0; i<b; i++){
        if(svi[k+i].status!=STATUS_AKTIVAN){
            svi[k+i]=novi;
            upisano=1;
            break;
        }
    }
    
    //serijska zona
    if(!upisano){
        for(int i= B*b; i<MAX_RECORDS; i++){
            if(svi[i].status != STATUS_AKTIVAN){
                svi[i]=novi;
                svi[i].sled=-1;
                upisano=1;
                
                int poslednji=-1;
                for(int j=0; j<b; j++){
                	if(svi[k+j].status==STATUS_AKTIVAN){
                		poslednji= k+j;
                		while(svi[poslednji].sled !=-1){
                			poslednji= svi[poslednji].sled;
                		}
                		break;
                	}
                }
                if(poslednji != -1){
                	svi[poslednji].sled=i;
                }
                break;
            }
        }
    }

    if(upisano){
        rewind(f);
        fwrite(svi, sizeof(AgregiraniSlogovi), MAX_RECORDS, f);
        printf("Slog je uspesno upisan. \n");
    }else{
        printf("Nema mesta za novi slog.\n");
    }

    fclose(f);
}

void prikazi_izvestaj_log(){
    FILE *f= fopen(naziv_log_datoteke, "rb");
    if(!f){
        printf("Greska pri otvaranju log fajla.\n");
        return;
    }

    LogZapis l;
    int ukupno=0, suma=0, reorganizuj=0;

    printf("\n--Sadrzaj log datoteke--\n");
    while(fread(&l, sizeof(LogZapis), 1, f)){
        int pristupa= atoi(l.broj_pristupa);
        printf("ID: %d, Student: %d, Pristupa: %d\n", l.identifikator, l.identifikator_za_pristup, pristupa);
        suma += pristupa;
        ukupno++;
        if(pristupa> 5) reorganizuj=1;
    }
    if(ukupno>0) printf("Prosecan broj pristupa: %.2f\n", (float) suma/ukupno);
    if(reorganizuj) printf("Pokrenuta je reorganizacija rasute datoteke!\n");
    if(reorganizuj){
      formiraj_staticku_datoteku();
    }

    fclose(f);

}

void prikaz_nepolozenih(){
    if (je_naziv_datoteke_prazan(naziv_datoteke_ag)) {
        printf("Naziv datoteke nije postavljen. Molimo prvo formirajte datoteku.\n");
        return;
    }

    FILE* f= fopen(naziv_datoteke_ag,"r+b");
    if(!f){
        printf("Datoteka ne postoji ili je došlo do greške pri otvaranju. \n");
        return;
    }

    AgregiraniSlogovi svi[MAX_RECORDS];
    fread(svi, sizeof(AgregiraniSlogovi), MAX_RECORDS, f);

    int broj;
    printf("Unesite studentski broj. \n");
    scanf("%d", &broj);

    int adr= preklapanje(broj);
    int k= adr*b;
    int pronadjen=0;

    for(int i=0; i<b; i++){
        int indeks= k+i;
        if(svi[indeks].status==STATUS_AKTIVAN && svi[indeks].studentski_broj==broj){
            printf("Broj nepolozenih ispita: %d\n", svi[indeks].broj_nepolozenih_ispita);
            printf("Adresa baketa: %d\n", adr);
            printf("Redni broj u baketu: %d\n", i);
            pronadjen=1;
            break;
        }
    }

    if(!pronadjen){
    	for(int i=0; i<b; i++){
    		int glava= k+i;
    		if(svi[glava].status== STATUS_AKTIVAN){
    			int idx= svi[glava].sled;
    			while(idx != -1){
    				if(svi[idx].status== STATUS_AKTIVAN && svi[idx].studentski_broj==broj){
    					printf("Broj nepolozenih ispita: %d\n", svi[idx].broj_nepolozenih_ispita);
    					printf("Slog se nalazi u serijskoj zoni prekoracenja. \n");
    					pronadjen=1;
    					break;
    					
    				}
    				idx= svi[idx].sled;
    			}
    		}
    		if(pronadjen) break;
    		
    	}
    }
    if(!pronadjen){
        printf("Slog sa zadatim studentskim brojem nije pronadjen. \n");
    }

    fclose(f);

}

void prikaz_studenata_pod_uslovom(){
    if (je_naziv_datoteke_prazan(naziv_datoteke_ag)) {
        printf("Naziv datoteke nije postavljen. Molimo prvo formirajte datoteku.\n");
        return;
    }

    FILE* f= fopen(naziv_datoteke_ag,"r+b");
    if(!f){
        printf("Datoteka ne postoji ili je došlo do greške pri otvaranju. \n");
        return;
    }

    AgregiraniSlogovi svi[MAX_RECORDS];
    fread(svi, sizeof(AgregiraniSlogovi), MAX_RECORDS, f);

    int pronadjen=0;

    for(int i=0; i<MAX_RECORDS; i++){
        if(svi[i].status==STATUS_AKTIVAN && svi[i].broj_nepolozenih_ispita==svi[i].broj_izlazaka){
            pronadjen=1;

            int adr= preklapanje(svi[i].studentski_broj);
            int redni_broj= i-adr*b;

            printf("Trazeni student: ");
            printf("Ime i prezime: %s\n", svi[i].ime_prezime);
            printf("Studentski broj: %d\n", svi[i].studentski_broj);
            printf("Nepolozeni=Izlasci: %d\n", svi[i].broj_izlazaka);
            printf("Adresa baketa: %d\n", adr);

            if(i<B*b && i>=adr*b && i<(adr+1)*b){
                printf("Redni broj u baketu: %d\n", redni_broj);
            } else{
                printf("Slog je u zoni prekoracenja,\n");
            }
        }
    }

    if(!pronadjen){
        printf("Nema studenata kod kojih je broj nepolozenih ispita jednak broju izlazaka.\n");
    }

    fclose(f);
}

void logicko_brisanje_sloga(){

    if (je_naziv_datoteke_prazan(naziv_datoteke_ag)) {
        printf("Naziv datoteke nije postavljen. Molimo prvo formirajte datoteku.\n");
        return;
    }

    FILE* f= fopen(naziv_datoteke_ag,"r+b");
    if(!f){
        printf("Datoteka ne postoji ili je došlo do greške pri otvaranju. \n");
        return;
    }

    AgregiraniSlogovi svi[MAX_RECORDS];
    fread(svi, sizeof(AgregiraniSlogovi), MAX_RECORDS, f);

    int broj;
    printf("Unesite studentski broj za brisanje: ");
    scanf("%d", &broj);

    int adr= preklapanje(broj);
    int k= adr*b;
    int obrisan=0;

    for(int i=0; i<b; i++){
        int indeks= k+i;
        if(svi[indeks].status== STATUS_AKTIVAN && svi[indeks].studentski_broj== broj){
            svi[indeks].status=STATUS_OBRISAN;
            obrisan=1;
            break;
        }
    }

    if(!obrisan){
        for(int i=0; i<b; i++){
        	int glava= k+i;
        	if(svi[glava].status== STATUS_AKTIVAN){
        		int idx= svi[glava].sled;
        		while(idx != -1){
        			if(svi[idx].status== STATUS_AKTIVAN && svi[idx].studentski_broj== broj){
        				svi[idx].status= STATUS_OBRISAN;
        				obrisan=-1;
        				break;
        			}
        			idx=svi[idx].sled;
        		}
        	}
        	if(obrisan) break;
        	
        }
    }

    if(obrisan){
        rewind(f);
        fwrite(svi, sizeof(AgregiraniSlogovi), MAX_RECORDS, f);
        printf("Slog je uspesno logicki obrisan. \n");
    } else{
        printf("Slog sa zadatim studentskim brojem nije pronadjen. \n");
    }

    fclose(f);
}

void podmeni_staticka(){
    int izbor;
    do{
        printf("\n---STATICKA RASUTA ORGANIZACIJA---\n");
        printf("1. Formiraj datoteku\n");
        printf("2. Unos podataka u datoteci %s\n", je_naziv_datoteke_prazan(naziv_datoteke_ag) ? "(nije postavljena)" : "");
        printf("3. Broj nepolozenih ispita\n");
        printf("4. Studenti sa uslovom\n");
        printf("5. Brisanje podataka\n");
        printf("0. Povratak u glavni meni\n");
        printf("Izbor:");
        scanf("%d", &izbor);
        ocisti_buffer();

        switch (izbor)
        {
        case 1:
            formiraj_staticku_datoteku();
            break;
        case 2:
            upis_sloga_ag();
            break;
        case 3:
            prikaz_nepolozenih();
            break;
        case 4:
            prikaz_studenata_pod_uslovom();
            break;
        case 5:
            logicko_brisanje_sloga();
            break;
        case 0:
            printf("Povratak u glavni meni\n");
            break;
        default:
            printf("Neispravna opcija!\n");
        }


    } while(izbor !=0);
}

void podmeni_student(){
    int izbor;
    do{
        printf("\n---STUDENT---\n");
        printf("1. Formiraj datoteku za evidenciju studenta\n");
        printf("2. Unos studenata u datoteci \n");
        printf("3. Prikaz studenata po studentskom broju \n");
        printf("4. Prikaz studenata (Godina upisa 2023, suma ispitnih poena 70) \n");
        printf("5. Izmeni studenta \n");
        printf("0. Povratak u glavni meni\n");
        printf("Izbor:");
        scanf("%d", &izbor);
        ocisti_buffer();

        switch (izbor)
        {
        case 1:
            formiraj_datoteku_studenata();
            break;
        case 2:
            unos_studenata();
            break;
        case 3:
            prikaz_godine_i_indeksa();
            break;
        case 4:
            uslov_studenti();
            break;
        case 5:
            izmeni_studenta();
            break;
        case 0:
            printf("Povratak u glavni meni\n");
            break;
        default:
            printf("Neispravna opcija!\n");
        }


    } while(izbor !=0);
}

void podmeni_ispiti(){
    int izbor;
    do{
        printf("\n---ISPIT---\n");
        printf("1. Formiraj datoteku za evidenciju polaganja\n");
        printf("2. Unos polaganja ispita\n");
        printf("0. Povratak u glavni meni\n");
        printf("Izbor:");
        scanf("%d", &izbor);
        ocisti_buffer();

        switch (izbor)
        {
        case 1:
            formiraj_datoteku_polaganja();
            break;
        case 2:
            unos_polaganja();
            break;
        case 0:
            printf("Povratak u glavni meni\n");
            break;
        default:
            printf("Neispravna opcija!\n");
        }


    } while(izbor !=0);
}
int main(){
    int izbor;

    do{
        printf("\n--- MENI ---\n");
        printf("1. Rad na studentu\n");
        printf("2. Rad na ispitima\n");
        printf("3. Rad sa statickom datotekom\n");
        printf("4. Prikazi izvestaj\n");
        printf("0. Izlaz\n");
        printf("Izbor: ");
        scanf("%d", &izbor);
        ocisti_buffer();

        switch (izbor)
        {
        case 1:
            podmeni_student();
            break;
        case 2:
            podmeni_ispiti();
            break;
        case 3:
            podmeni_staticka();
            break;
        case 4:
        	prikazi_izvestaj_log();
        	break;
        default:
            break;
        }
    }while(izbor !=0);

    return 0;
}
