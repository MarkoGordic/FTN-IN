#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Automobil/automobil.h"
#include "Parkiranje/parkiranje.h"
#include "IndeksiraniAutomobil/indeksirani.h"

int main() {
    int glavni_izbor;
    char aktivni_automobili[100] = "automobili.bin";
    char aktivni_parkiranja[100] = "parkiranja.bin";

    do {
        printf("\n--- GLAVNI MENI ---\n");
        printf("1. Rad sa fajlom automobila\n");
        printf("2. Rad sa fajlom parkiranja\n");
        printf("3. Rad sa indeks sekvencijalnom datotekom\n"); // NOVA OPCIJA

        printf("0. Izlaz\n");
        printf("Izbor: ");
        scanf("%d", &glavni_izbor);
        getchar();

        if (glavni_izbor == 1) {
        int izbor;
        do {
            printf("\n--- AUTOMOBILI MENI ---\n");
            printf("1. Izaberi postojeći fajl\n"); // PREMESTENO
            printf("2. Kreiraj prazan sekvencijalni fajl (blok faktor 5)\n");
            printf("3. Unos automobila\n");
            printf("4. Prikaz podataka za registarsku oznaku\n");
            printf("5. Prikaz svih automobila sa punjenjima\n");
            printf("6. Izmena podataka automobila\n");
            printf("0. Nazad\n");
            printf("Izbor: ");
            scanf("%d", &izbor);
            getchar();

            switch (izbor) {
                case 1:
                    printf("Unesite ime postojećeg fajla: ");
                    fgets(aktivni_automobili, sizeof(aktivni_automobili), stdin);
                    aktivni_automobili[strcspn(aktivni_automobili, "\n")] = 0;
                    printf("Aktivni fajl za automobile je sada: %s\n", aktivni_automobili);
                    break;
                case 2:
                    printf("Unesite ime fajla: ");
                    fgets(aktivni_automobili, sizeof(aktivni_automobili), stdin);
                    aktivni_automobili[strcspn(aktivni_automobili, "\n")] = 0;
                    kreiraj_prazan_sekvencijalni_fajl(aktivni_automobili);
                    break;
                case 3:
                    unos_automobila(aktivni_automobili);
                    kreiraj_indeksirani_fajl(aktivni_automobili, aktivni_parkiranja, "indeksirani.bin");
                    break;
                case 4: {
                    int oznaka;
                    printf("Unesite registarsku oznaku: ");
                    scanf("%d", &oznaka);
                    getchar();
                    prikazi_podatke_za_registarsku(aktivni_automobili, oznaka);
                    break;
                }
                case 5:
                    prikazi_automobile_sa_punjenjima(aktivni_automobili, aktivni_parkiranja);
                    break;
                case 6: {
                    int oznaka;
                    printf("Unesite registarsku oznaku automobila za izmenu: ");
                    scanf("%d", &oznaka);
                    getchar();
                    izmeni_automobil(aktivni_automobili, oznaka);
                    kreiraj_indeksirani_fajl(aktivni_automobili, aktivni_parkiranja, "indeksirani.bin");
                    break;
                }
                case 0:
                    break;
                default:
                    printf("Nepoznat izbor.\n");
            }
        } while (izbor != 0);

        } else if (glavni_izbor == 2) {
            int izbor;
            do {
                printf("\n--- PARKIRANJE MENI ---\n");
                printf("1. Izaberi postojeći fajl\n"); // SADA JE PRVA OPCIJA
                printf("2. Kreiraj praznu serijsku datoteku (blok faktor 6)\n");
                printf("3. Unos parkiranja\n");
                printf("4. Prikaz svih parkiranja\n");
                printf("5. Prikaz log datoteke (prekoracenja)\n");
                printf("6. Prikaz prekoracenja po registarskoj oznaci\n"); // NOVO
                printf("0. Nazad\n");
                printf("Izbor: ");
                scanf("%d", &izbor);
                getchar();

                switch (izbor) {
                    case 1:
                        printf("Unesite ime postojećeg fajla: ");
                        fgets(aktivni_parkiranja, sizeof(aktivni_parkiranja), stdin);
                        aktivni_parkiranja[strcspn(aktivni_parkiranja, "\n")] = 0;
                        printf("Aktivni fajl za parkiranja je sada: %s\n", aktivni_parkiranja);
                        break;
                    case 2:
                        printf("Unesite ime fajla: ");
                        fgets(aktivni_parkiranja, sizeof(aktivni_parkiranja), stdin);
                        aktivni_parkiranja[strcspn(aktivni_parkiranja, "\n")] = 0;
                        kreiraj_praznu_serijsku_parkiranje_datoteku(aktivni_parkiranja);
                        break;
                    case 3:
                        unos_parkiranja(aktivni_parkiranja);
                        kreiraj_indeksirani_fajl(aktivni_automobili, aktivni_parkiranja, "indeksirani.bin");
                        break;
                    case 4:
                        prikazi_parkiranja(aktivni_parkiranja);
                        break;
                    case 5:
                        prikazi_log("log.bin");
                        break;
                    case 6: {
                        int oznaka;
                        printf("Unesite registarsku oznaku: ");
                        scanf("%d", &oznaka);
                        getchar();
                        prikazi_log_po_oznaci("log.bin", oznaka);
                        break;
                    }
                    case 0:
                        break;
                    default:
                        printf("Nepoznat izbor.\n");
                }
            } while (izbor != 0);

        } else if (glavni_izbor == 3) {
            // Ovde dodaj meni za indeks sekvencijalnu datoteku
            int izbor;
            do {
                printf("\n--- INDEKS SEKVENCIJALNA DATOTEKA MENI ---\n");
                printf("1. Kreiraj novu indeks sekvencijalnu datoteku\n");
                printf("2. Prikaz ukupne duzine boravka i iznosa za registarsku oznaku\n");
                printf("3. Prikaz svih slogova iz indeks sekvencijalne datoteke\n");
                printf("4. Prikaz svih automobila koji su se punili tokom boravka\n");
                printf("5. Logičko brisanje sloga po registarskoj oznaci\n"); 
                printf("6. Reorganizacija indeks-sekvencijalne datoteke\n");
                printf("0. Nazad\n");
                printf("Izbor: ");
                scanf("%d", &izbor);
                getchar();

                switch (izbor) {
                    case 1:
                        kreiraj_indeksirani_fajl(aktivni_automobili, aktivni_parkiranja, "indeksirani.bin");
                        break;
                    case 2: {
                        int oznaka;
                        printf("Unesite registarsku oznaku: ");
                        scanf("%d", &oznaka);
                        getchar();
                        prikazi_agregat_za_registarsku("indeksirani.bin", oznaka);
                        break;
                    }
                    case 3:
                        detaljan_prikaz_svih_slogova("indeksirani.bin");
                        break;
                    case 4:
                        prikazi_sve_sa_punjenjem("indeksirani.bin");
                        break;
                    case 5: {
                        int oznaka;
                        printf("Unesite registarsku oznaku za logičko brisanje: ");
                        scanf("%d", &oznaka);
                        getchar();
                        logicko_brisanje_sloga("indeksirani.bin", oznaka);
                        break;
                    }
                    case 6:
                        reorganizuj_indeksirani_fajl("indeksirani.bin");
                        break;
                    case 0:
                        break;
                    default:
                        printf("Nepoznat izbor.\n");
                }
            } while (izbor != 0);
        } else if (glavni_izbor == 0) {
            printf("Izlaz iz programa.\n");
        } else {
            printf("Nepoznat izbor.\n");
        }
    } while (glavni_izbor != 0);

    return 0;
}