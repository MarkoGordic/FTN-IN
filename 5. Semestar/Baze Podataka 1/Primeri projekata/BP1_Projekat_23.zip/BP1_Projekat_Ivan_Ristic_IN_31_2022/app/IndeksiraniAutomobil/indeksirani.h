#ifndef INDEKSIRANI_H
#define INDEKSIRANI_H

#define BLOCK_FACTOR_PRIMARY 5
#define BLOCK_FACTOR_INDEX 2
#define BLOCK_FACTOR_OVERFLOW 1
#define MAX_BLOKOVA 2

typedef struct {
    int registarska_oznaka;
    char marka[31];         
    char model[31];         
    int godina_proizvodnje;
    char elektricno[3];     
    int uk_duzina_boravka;  
    float iznos;            
    int status;             
    int next;               
} IndeksiraniAutomobil;

typedef struct {
    int max_key;     // najveća registarska oznaka u bloku
    int block_addr;  // redni broj bloka u primarnoj zoni
    int status;      // 1-popunjen, 0-prazan
} IndeksBlok;

void kreiraj_indeksirani_fajl(const char* automobili, const char* parkiranja, const char* indeksirani);
void prikazi_agregat_za_registarsku(const char* indeksirani, int trazena_oznaka);
void detaljan_prikaz_svih_slogova(const char* indeksirani);
void prikazi_sve_sa_punjenjem(const char* indeksirani);
void logicko_brisanje_sloga(const char* indeksirani, int oznaka);
void reorganizuj_indeksirani_fajl(const char* indeksirani);

#endif