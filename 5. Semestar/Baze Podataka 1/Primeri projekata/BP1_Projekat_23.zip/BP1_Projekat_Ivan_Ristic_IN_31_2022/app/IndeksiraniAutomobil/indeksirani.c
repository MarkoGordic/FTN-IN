#include "indeksirani.h"
#include "../Automobil/automobil.h"
#include "../Parkiranje/parkiranje.h"
#include <stdio.h>
#include <string.h>

#include "indeksirani.h"
#include "../Automobil/automobil.h"
#include "../Parkiranje/parkiranje.h"
#include <stdio.h>
#include <string.h>

void kreiraj_indeksirani_fajl(const char* automobili, const char* parkiranja, const char* indeksirani) {
    FILE *fa = fopen(automobili, "rb");
    FILE *fp = fopen(parkiranja, "rb");
    FILE *fi = fopen(indeksirani, "wb+");
    if (!fa || !fp || !fi) {
        printf("Greska pri otvaranju fajlova!\n");
        if (fa) fclose(fa);
        if (fp) fclose(fp);
        if (fi) fclose(fi);
        return;
    }

    // 1. Učitaj sve automobile i agregiraj podatke iz parkiranja
    IndeksiraniAutomobil primarni[1000];
    int ukupno = 0;

    Automobil blok_a[BLOCK_FACTOR_PRIMARY];
    size_t procitano;
    while ((procitano = fread(blok_a, sizeof(Automobil), BLOCK_FACTOR_PRIMARY, fa)) > 0) {
        for (int i = 0; i < procitano; i++) {
            if (blok_a[i].registarska_oznaka == -1) break;
            if (blok_a[i].registarska_oznaka == 0) continue;

            IndeksiraniAutomobil novi = {0};
            novi.registarska_oznaka = blok_a[i].registarska_oznaka;
            strncpy(novi.marka, blok_a[i].marka, 30); novi.marka[30] = 0;
            strncpy(novi.model, blok_a[i].model, 30); novi.model[30] = 0;
            novi.godina_proizvodnje = blok_a[i].godina_proizvodnje;
            strncpy(novi.elektricno, blok_a[i].elektricno, 2); novi.elektricno[2] = 0;
            novi.uk_duzina_boravka = 0;
            novi.iznos = 0.0f;
            novi.status = 1;
            novi.next = -1;

            // Agregacija iz parkiranja
            rewind(fp);
            Parkiranje blok_p[BLOCK_FACTOR_PARKIRANJE];
            size_t proc_park;
            while ((proc_park = fread(blok_p, sizeof(Parkiranje), BLOCK_FACTOR_PARKIRANJE, fp)) > 0) {
                for (int j = 0; j < proc_park; j++) {
                    if (blok_p[j].identifikator == -1) break;
                    if (blok_p[j].registarska_oznaka == novi.registarska_oznaka) {
                        // Uvek saberi duzinu boravka
                        novi.uk_duzina_boravka += blok_p[j].duzina_boravka;
                        // Iznos samo ako je bilo punjenje
                        if (strcmp(blok_p[j].punjenje, "DA") == 0) {
                            novi.iznos += blok_p[j].duzina_boravka * 10.0f;
                        }
                    }
                }
            }
            primarni[ukupno++] = novi;
        }
    }

    // OGRANIČENJE: Maksimalan broj blokova u primarnoj zoni
    int max_primarnih = MAX_BLOKOVA * BLOCK_FACTOR_PRIMARY;
    int ukupno_primarnih = ukupno > max_primarnih ? max_primarnih : ukupno;

    // 2. Upis primarne zone blok po blok (samo do MAX_BLOKOVA)
    int idx = 0;
    for (int i = 0; i < MAX_BLOKOVA; i++) {
        IndeksiraniAutomobil blok[BLOCK_FACTOR_PRIMARY] = {0};
        for (int j = 0; j < BLOCK_FACTOR_PRIMARY; j++) {
            if (idx < ukupno_primarnih) {
                blok[j] = primarni[idx++];
            } else {
                blok[j].status = 0;
                blok[j].next = -1;
            }
        }
        fwrite(blok, sizeof(IndeksiraniAutomobil), BLOCK_FACTOR_PRIMARY, fi);
    }

    // 2b. Slogovi koji ne stanu u primarnu zonu idu u overflow zonu
    int broj_overflow = ukupno - ukupno_primarnih;
    if (broj_overflow > 0) {
        IndeksiraniAutomobil overflow[broj_overflow];
        for (int i = 0; i < broj_overflow; i++) {
            overflow[i] = primarni[ukupno_primarnih + i];
            overflow[i].status = 1;
            overflow[i].next = -1;
        }
        fwrite(overflow, sizeof(IndeksiraniAutomobil), broj_overflow, fi);
    }
    // Ako nema slogova za overflow, NEMOJ upisivati ništa!

    // 3. Upis index zone (propagacija najvećih ključeva iz svakog bloka) - NA KRAJ FAJLA!
    IndeksBlok index_blok[BLOCK_FACTOR_INDEX] = {0};
    int index_count = 0;
    for (int i = 0; i < MAX_BLOKOVA; i++) {
        int idx_blok = i * BLOCK_FACTOR_PRIMARY;
        int max_key = -1;
        for (int j = 0; j < BLOCK_FACTOR_PRIMARY; j++) {
            if (idx_blok + j < ukupno_primarnih) {
                if (primarni[idx_blok + j].status == 1 && primarni[idx_blok + j].registarska_oznaka > max_key)
                    max_key = primarni[idx_blok + j].registarska_oznaka;
            }
        }
        index_blok[index_count].max_key = max_key;
        index_blok[index_count].block_addr = i;
        index_blok[index_count].status = 1;
        index_count++;

        // Upis index bloka kada se napuni ili je poslednji
        if (index_count == BLOCK_FACTOR_INDEX || i == MAX_BLOKOVA - 1) {
            fwrite(index_blok, sizeof(IndeksBlok), BLOCK_FACTOR_INDEX, fi);
            memset(index_blok, 0, sizeof(index_blok));
            index_count = 0;
        }
    }

    fclose(fa);
    fclose(fp);
    fclose(fi);
}

void prikazi_agregat_za_registarsku(const char* indeksirani, int trazena_oznaka) {
    FILE *fi = fopen(indeksirani, "rb");
    if (!fi) {
        printf("Ne mogu da otvorim indeksirani fajl!\n");
        return;
    }

    // 1. Prvo pretraga primarne zone
    int blok_broj = 0;
    IndeksiraniAutomobil blok[BLOCK_FACTOR_PRIMARY];
    while (fread(blok, sizeof(IndeksiraniAutomobil), BLOCK_FACTOR_PRIMARY, fi) == BLOCK_FACTOR_PRIMARY) {
        for (int i = 0; i < BLOCK_FACTOR_PRIMARY; i++) {
            if (blok[i].status == 1 && blok[i].registarska_oznaka == trazena_oznaka) {
                printf("UKUPNA DUZINA BORAVKA: %d minuta\n", blok[i].uk_duzina_boravka);
                printf("UKUPAN IZNOS: %.2f dinara\n", blok[i].iznos);
                printf("Adresa bloka: %d\n", blok_broj);
                printf("Redni broj sloga u bloku: %d\n", i);
                printf("Slog je u primarnoj zoni.\n");
                fclose(fi);
                return;
            }
        }
        blok_broj++;
    }

    // 2. Pretraga overflow zone (dinamičke veličine)
    // Izračunaj offset na početak overflow zone
    long overflow_offset = MAX_BLOKOVA * BLOCK_FACTOR_PRIMARY * sizeof(IndeksiraniAutomobil);

    // Izračunaj offset i veličinu index zone
    fseek(fi, 0, SEEK_END);
    long velicina = ftell(fi);
    int broj_index_blokova = (MAX_BLOKOVA + BLOCK_FACTOR_INDEX - 1) / BLOCK_FACTOR_INDEX;
    long index_zone_size = broj_index_blokova * BLOCK_FACTOR_INDEX * sizeof(IndeksBlok);
    long index_zone_offset = velicina - index_zone_size;

    // Prikaz overflow zone (samo slogovi između kraja primarne i početka index zone)
    long broj_overflow = (index_zone_offset - overflow_offset) / sizeof(IndeksiraniAutomobil);

    fseek(fi, overflow_offset, SEEK_SET);
    for (int i = 0; i < broj_overflow; i++) {
        IndeksiraniAutomobil slog;
        if (fread(&slog, sizeof(IndeksiraniAutomobil), 1, fi) != 1) break;
        if (slog.status == 1 && slog.registarska_oznaka == trazena_oznaka) {
            printf("UKUPNA DUZINA BORAVKA: %d minuta\n", slog.uk_duzina_boravka);
            printf("UKUPAN IZNOS: %.2f dinara\n", slog.iznos);
            printf("Adresa bloka: OVERFLOW\n");
            printf("Redni broj sloga u overflow zoni: %d\n", i);
            printf("Slog je PREKORAČILAC (overflow zona).\n");
            fclose(fi);
            return;
        }
    }

    fclose(fi);
    printf("Slog sa tom registarskom oznakom nije pronađen u aktivnoj datoteci.\n");
}

void prikazi_sve_sa_punjenjem(const char* indeksirani) {
    FILE *fi = fopen(indeksirani, "rb");
    if (!fi) {
        printf("Ne mogu da otvorim indeksirani fajl!\n");
        return;
    }

    int found = 0;

    // Prikaz primarne zone
    IndeksiraniAutomobil blok[BLOCK_FACTOR_PRIMARY];
    for (int b = 0; b < MAX_BLOKOVA; b++) {
        size_t procitano = fread(blok, sizeof(IndeksiraniAutomobil), BLOCK_FACTOR_PRIMARY, fi);
        if (procitano != BLOCK_FACTOR_PRIMARY) break;
        for (int i = 0; i < BLOCK_FACTOR_PRIMARY; i++) {
            if (blok[i].status == 1 && blok[i].iznos > 0.0f) {
                found = 1;
                printf("Registarska oznaka: %d\n", blok[i].registarska_oznaka);
                printf("Marka: %s\n", blok[i].marka);
                printf("Model: %s\n", blok[i].model);
                printf("Godina proizvodnje: %d\n", blok[i].godina_proizvodnje);
                printf("Elektricno: %s\n", blok[i].elektricno);
                printf("Ukupna duzina boravka: %d\n", blok[i].uk_duzina_boravka);
                printf("Ukupan iznos: %.2f\n", blok[i].iznos);
                printf("Status: PRIMARNA\n");
                printf("---------------------------------------------\n");
            }
        }
    }

    // Izračunaj offset i veličinu index zone
    fseek(fi, 0, SEEK_END);
    long velicina = ftell(fi);
    int broj_index_blokova = (MAX_BLOKOVA + BLOCK_FACTOR_INDEX - 1) / BLOCK_FACTOR_INDEX;
    long index_zone_size = broj_index_blokova * BLOCK_FACTOR_INDEX * sizeof(IndeksBlok);
    long overflow_offset = MAX_BLOKOVA * BLOCK_FACTOR_PRIMARY * sizeof(IndeksiraniAutomobil);
    long index_zone_offset = velicina - index_zone_size;
    long broj_overflow = (index_zone_offset - overflow_offset) / sizeof(IndeksiraniAutomobil);

    // Prikaz overflow zone
    if (broj_overflow > 0) {
        fseek(fi, overflow_offset, SEEK_SET);
        for (int i = 0; i < broj_overflow; i++) {
            IndeksiraniAutomobil slog;
            if (fread(&slog, sizeof(IndeksiraniAutomobil), 1, fi) != 1) break;
            if (slog.status == 1 && slog.iznos > 0.0f) {
                found = 1;
                printf("Registarska oznaka: %d\n", slog.registarska_oznaka);
                printf("Marka: %s\n", slog.marka);
                printf("Model: %s\n", slog.model);
                printf("Godina proizvodnje: %d\n", slog.godina_proizvodnje);
                printf("Elektricno: %s\n", slog.elektricno);
                printf("Ukupna duzina boravka: %d\n", slog.uk_duzina_boravka);
                printf("Ukupan iznos: %.2f\n", slog.iznos);
                printf("Status: PREKORAČILAC (overflow zona)\n");
                printf("---------------------------------------------\n");
            }
        }
    }

    fclose(fi);

    if (!found) {
        printf("Nijedan automobil nije imao punjenje tokom boravka.\n");
    }
}

void logicko_brisanje_sloga(const char* indeksirani, int oznaka) {
    FILE *fi = fopen(indeksirani, "rb+");
    if (!fi) {
        printf("Ne mogu da otvorim indeksirani fajl!\n");
        return;
    }

    // 1. Traži u primarnoj zoni
    IndeksiraniAutomobil blok[BLOCK_FACTOR_PRIMARY];
    long pozicija = 0;
    for (int b = 0; b < MAX_BLOKOVA; b++) {
        size_t procitano = fread(blok, sizeof(IndeksiraniAutomobil), BLOCK_FACTOR_PRIMARY, fi);
        if (procitano != BLOCK_FACTOR_PRIMARY) break;
        for (int i = 0; i < BLOCK_FACTOR_PRIMARY; i++) {
            if (blok[i].status == 1 && blok[i].registarska_oznaka == oznaka) {
                blok[i].status = 0;
                fseek(fi, pozicija + i * sizeof(IndeksiraniAutomobil), SEEK_SET);
                fwrite(&blok[i], sizeof(IndeksiraniAutomobil), 1, fi);
                printf("Slog logički obrisan iz primarne zone.\n");
                fclose(fi);
                return;
            }
        }
        pozicija += BLOCK_FACTOR_PRIMARY * sizeof(IndeksiraniAutomobil);
    }

    // 2. Traži u overflow zoni
    fseek(fi, 0, SEEK_END);
    long velicina = ftell(fi);
    int broj_index_blokova = (MAX_BLOKOVA + BLOCK_FACTOR_INDEX - 1) / BLOCK_FACTOR_INDEX;
    long index_zone_size = broj_index_blokova * BLOCK_FACTOR_INDEX * sizeof(IndeksBlok);
    long overflow_offset = MAX_BLOKOVA * BLOCK_FACTOR_PRIMARY * sizeof(IndeksiraniAutomobil);
    long index_zone_offset = velicina - index_zone_size;
    long broj_overflow = (index_zone_offset - overflow_offset) / sizeof(IndeksiraniAutomobil);

    fseek(fi, overflow_offset, SEEK_SET);
    for (int i = 0; i < broj_overflow; i++) {
        IndeksiraniAutomobil slog;
        long slog_poz = ftell(fi);
        if (fread(&slog, sizeof(IndeksiraniAutomobil), 1, fi) != 1) break;
        if (slog.status == 1 && slog.registarska_oznaka == oznaka) {
            slog.status = 0;
            fseek(fi, slog_poz, SEEK_SET);
            fwrite(&slog, sizeof(IndeksiraniAutomobil), 1, fi);
            printf("Slog logički obrisan iz overflow zone.\n");
            fclose(fi);
            return;
        }
    }

    fclose(fi);
    printf("Slog sa tom registarskom oznakom nije pronađen.\n");
}

void detaljan_prikaz_svih_slogova(const char* indeksirani) {
    FILE *fi = fopen(indeksirani, "rb");
    if (!fi) {
        printf("Ne mogu da otvorim indeksirani fajl!\n");
        return;
    }

    printf("\n--- DETALJAN PRIKAZ SVIH SLOGOVA IZ INDEKS SEKVENCIJALNE DATOTEKE ---\n");

    // Prikaz primarne zone
    int blok_broj = 0;
    IndeksiraniAutomobil blok[BLOCK_FACTOR_PRIMARY];

    long primarna_offset = 0;
    long overflow_offset = MAX_BLOKOVA * BLOCK_FACTOR_PRIMARY * sizeof(IndeksiraniAutomobil);

    // Prikaz primarne zone
    fseek(fi, primarna_offset, SEEK_SET);
    for (int i = 0; i < MAX_BLOKOVA; i++) {
        size_t procitano = fread(blok, sizeof(IndeksiraniAutomobil), BLOCK_FACTOR_PRIMARY, fi);
        if (procitano != BLOCK_FACTOR_PRIMARY) break;
        for (int j = 0; j < BLOCK_FACTOR_PRIMARY; j++) {
            printf("Zona: PRIMARNA | Blok: %d | Slog: %d\n", blok_broj, j);
            printf("Registarska oznaka: %d\n", blok[j].registarska_oznaka);
            printf("Marka: %s\n", blok[j].marka);
            printf("Model: %s\n", blok[j].model);
            printf("Godina proizvodnje: %d\n", blok[j].godina_proizvodnje);
            printf("Elektricno: %s\n", blok[j].elektricno);
            printf("Ukupna duzina boravka: %d\n", blok[j].uk_duzina_boravka);
            printf("Ukupan iznos: %.2f\n", blok[j].iznos);
            printf("Status: %d\n", blok[j].status);
            printf("Next: %d\n", blok[j].next);
            printf("---------------------------------------------\n");
        }
        blok_broj++;
    }

    // Izračunaj offset i veličinu index zone
    fseek(fi, 0, SEEK_END);
    long velicina = ftell(fi);
    int broj_index_blokova = (MAX_BLOKOVA + BLOCK_FACTOR_INDEX - 1) / BLOCK_FACTOR_INDEX;
    long index_zone_size = broj_index_blokova * BLOCK_FACTOR_INDEX * sizeof(IndeksBlok);
    long index_zone_offset = velicina - index_zone_size;

    // Prikaz overflow zone (samo slogovi između kraja primarne i početka index zone)
    long broj_overflow = (index_zone_offset - overflow_offset) / sizeof(IndeksiraniAutomobil);

    if (broj_overflow > 0) {
        fseek(fi, overflow_offset, SEEK_SET);
        for (int i = 0; i < broj_overflow; i++) {
            IndeksiraniAutomobil slog;
            if (fread(&slog, sizeof(IndeksiraniAutomobil), 1, fi) != 1) break;
            printf("Zona: OVERFLOW | Slog: %d\n", i);
            printf("Registarska oznaka: %d\n", slog.registarska_oznaka);
            printf("Marka: %s\n", slog.marka);
            printf("Model: %s\n", slog.model);
            printf("Godina proizvodnje: %d\n", slog.godina_proizvodnje);
            printf("Elektricno: %s\n", slog.elektricno);
            printf("Ukupna duzina boravka: %d\n", slog.uk_duzina_boravka);
            printf("Ukupan iznos: %.2f\n", slog.iznos);
            printf("Status: %d\n", slog.status);
            printf("Next: %d\n", slog.next);
            printf("---------------------------------------------\n");
        }
    }

    fclose(fi);
}

void reorganizuj_indeksirani_fajl(const char* indeksirani) {
    FILE *fi = fopen(indeksirani, "rb");
    if (!fi) {
        printf("Ne mogu da otvorim indeksirani fajl!\n");
        return;
    }

    // 1. Učitaj sve slogove sa statusom 1 iz primarne i overflow zone
    IndeksiraniAutomobil svi[1000];
    int ukupno = 0;

    // Primarna zona
    IndeksiraniAutomobil blok[BLOCK_FACTOR_PRIMARY];
    for (int b = 0; b < MAX_BLOKOVA; b++) {
        size_t procitano = fread(blok, sizeof(IndeksiraniAutomobil), BLOCK_FACTOR_PRIMARY, fi);
        if (procitano != BLOCK_FACTOR_PRIMARY) break;
        for (int i = 0; i < BLOCK_FACTOR_PRIMARY; i++) {
            if (blok[i].status == 1) {
                svi[ukupno++] = blok[i];
            }
        }
    }

    // Overflow zona
    fseek(fi, 0, SEEK_END);
    long velicina = ftell(fi);
    int broj_index_blokova = (MAX_BLOKOVA + BLOCK_FACTOR_INDEX - 1) / BLOCK_FACTOR_INDEX;
    long index_zone_size = broj_index_blokova * BLOCK_FACTOR_INDEX * sizeof(IndeksBlok);
    long overflow_offset = MAX_BLOKOVA * BLOCK_FACTOR_PRIMARY * sizeof(IndeksiraniAutomobil);
    long index_zone_offset = velicina - index_zone_size;
    long broj_overflow = (index_zone_offset - overflow_offset) / sizeof(IndeksiraniAutomobil);

    fseek(fi, overflow_offset, SEEK_SET);
    for (int i = 0; i < broj_overflow; i++) {
        IndeksiraniAutomobil slog;
        if (fread(&slog, sizeof(IndeksiraniAutomobil), 1, fi) != 1) break;
        if (slog.status == 1) {
            svi[ukupno++] = slog;
        }
    }
    fclose(fi);

    // (opciono) Sortiraj po registarskoj oznaci
    for (int i = 0; i < ukupno - 1; i++) {
        for (int j = i + 1; j < ukupno; j++) {
            if (svi[i].registarska_oznaka > svi[j].registarska_oznaka) {
                IndeksiraniAutomobil tmp = svi[i];
                svi[i] = svi[j];
                svi[j] = tmp;
            }
        }
    }

    // 2. Upisi ponovo u fajl
    fi = fopen(indeksirani, "wb+");
    if (!fi) {
        printf("Ne mogu da otvorim indeksirani fajl za upis!\n");
        return;
    }

    // Primarna zona
    int idx = 0;
    for (int b = 0; b < MAX_BLOKOVA; b++) {
        IndeksiraniAutomobil blok[BLOCK_FACTOR_PRIMARY] = {0};
        for (int i = 0; i < BLOCK_FACTOR_PRIMARY; i++) {
            if (idx < ukupno) {
                blok[i] = svi[idx++];
                blok[i].status = 1;
                blok[i].next = -1;
            } else {
                blok[i].status = 0;
                blok[i].next = -1;
            }
        }
        fwrite(blok, sizeof(IndeksiraniAutomobil), BLOCK_FACTOR_PRIMARY, fi);
    }

    // Overflow zona
    int broj_overflow_novi = ukupno - (MAX_BLOKOVA * BLOCK_FACTOR_PRIMARY);
    if (broj_overflow_novi > 0) {
        for (int i = 0; i < broj_overflow_novi; i++) {
            IndeksiraniAutomobil slog = svi[MAX_BLOKOVA * BLOCK_FACTOR_PRIMARY + i];
            slog.status = 1;
            slog.next = -1;
            fwrite(&slog, sizeof(IndeksiraniAutomobil), 1, fi);
        }
    }

    // Index zona
    IndeksBlok index_blok[BLOCK_FACTOR_INDEX] = {0};
    int index_count = 0;
    idx = 0;
    for (int b = 0; b < MAX_BLOKOVA; b++) {
        int max_key = -1;
        for (int i = 0; i < BLOCK_FACTOR_PRIMARY; i++) {
            if (idx < ukupno && svi[idx].status == 1 && svi[idx].registarska_oznaka > max_key)
                max_key = svi[idx].registarska_oznaka;
            idx++;
        }
        index_blok[index_count].max_key = max_key;
        index_blok[index_count].block_addr = b;
        index_blok[index_count].status = 1;
        index_count++;
        if (index_count == BLOCK_FACTOR_INDEX || b == MAX_BLOKOVA - 1) {
            fwrite(index_blok, sizeof(IndeksBlok), BLOCK_FACTOR_INDEX, fi);
            memset(index_blok, 0, sizeof(index_blok));
            index_count = 0;
        }
    }

    fclose(fi);
    printf("Reorganizacija indeks-sekvencijalne datoteke je završena.\n");
}

