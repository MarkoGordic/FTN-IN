#include "automobil.h"
#include "../Parkiranje/parkiranje.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_AUTOMOBILI 1000
#define BLOCK_FACTOR 5

void kreiraj_prazan_sekvencijalni_fajl(const char* filename) {
    FILE *fp = fopen(filename, "wb");
    if (!fp) {
        printf("Greska pri kreiranju fajla!\n");
        return;
    }
    Automobil blok[BLOCK_FACTOR] = {0};
    blok[0].registarska_oznaka = -1; // EOF marker
    fwrite(blok, sizeof(Automobil), BLOCK_FACTOR, fp);
    fclose(fp);
    printf("Prazan sekvencijalni fajl '%s' sa EOF markerom je kreiran.\n", filename);
}

void unos_automobila(const char* filename) {
    FILE *fp = fopen(filename, "rb+");
    if (!fp) {
        printf("Ne mogu da otvorim fajl za upis!\n");
        return;
    }

    Automobil novi;
    printf("Unesite registarsku oznaku (broj): ");
    scanf("%d", &novi.registarska_oznaka);
    getchar();

    printf("Unesite marku (do 30 karaktera): ");
    fgets(novi.marka, MAX_STR, stdin);
    novi.marka[strcspn(novi.marka, "\n")] = 0;

    printf("Unesite model (do 30 karaktera): ");
    fgets(novi.model, MAX_STR, stdin);
    novi.model[strcspn(novi.model, "\n")] = 0;

    printf("Unesite godinu proizvodnje (4 cifre): ");
    scanf("%d", &novi.godina_proizvodnje);
    getchar();

    do {
        printf("Da li je elektricno vozilo? (DA/NE): ");
        fgets(novi.elektricno, 3, stdin);
        novi.elektricno[strcspn(novi.elektricno, "\n")] = 0;
        if (strcmp(novi.elektricno, "DA") != 0 && strcmp(novi.elektricno, "NE") != 0) {
            printf("Dozvoljene vrednosti su 'DA' ili 'NE'. Pokusajte ponovo.\n");
        }
    } while (strcmp(novi.elektricno, "DA") != 0 && strcmp(novi.elektricno, "NE") != 0);

    Automobil blok[BLOCK_FACTOR];
    int blok_broj = 0;
    long pozicija = 0;

    while (fread(blok, sizeof(Automobil), BLOCK_FACTOR, fp) == BLOCK_FACTOR) {
        for (int i = 0; i < BLOCK_FACTOR; i++) {
            // a. KRAJ DATOTEKE, blok NIJE popunjen
            if (blok[i].registarska_oznaka == -1) {
                // Provera da li je blok popunjen
                if (i < BLOCK_FACTOR - 1) {
                    blok[i] = novi;
                    blok[i + 1].registarska_oznaka = -1; // novi EOF marker
                    fseek(fp, pozicija, SEEK_SET);
                    fwrite(blok, sizeof(Automobil), BLOCK_FACTOR, fp);
                    printf("Blok: %d, Pozicija: %d\n", blok_broj, i);
                    fclose(fp);
                    return;
                } else {
                    // b. KRAJ DATOTEKE, blok POPUNJEN
                    blok[i] = novi;
                    fseek(fp, pozicija, SEEK_SET);
                    fwrite(blok, sizeof(Automobil), BLOCK_FACTOR, fp);
                    // Novi blok sa EOF markerom
                    Automobil novi_blok[BLOCK_FACTOR] = {0};
                    novi_blok[0].registarska_oznaka = -1;
                    fwrite(novi_blok, sizeof(Automobil), BLOCK_FACTOR, fp);
                    printf("Blok: %d, Pozicija: %d\n", blok_broj, i);
                    fclose(fp);
                    return;
                }
            }
            // c. LOGIČKI OBRISAN (npr. registarska_oznaka == 0)
            else if (blok[i].registarska_oznaka == 0) {
                blok[i] = novi;
                fseek(fp, pozicija, SEEK_SET);
                fwrite(blok, sizeof(Automobil), BLOCK_FACTOR, fp);
                printf("Blok: %d, Pozicija: %d\n", blok_broj, i);
                fclose(fp);
                return;
            }
            // d. POSTOJI ISTI KLJUČ
            else if (blok[i].registarska_oznaka == novi.registarska_oznaka) {
                printf("Automobil sa tom registarskom oznakom već postoji!\n");
                fclose(fp);
                return;
            }
            // e. Ako je vrednost ključa veća od novog - umetanje i pomeranje
            else if (blok[i].registarska_oznaka > novi.registarska_oznaka) {
                Automobil temp = blok[i];
                blok[i] = novi;
                // Shift right i umetanje
                for (int j = i + 1; j < BLOCK_FACTOR; j++) {
                    Automobil tmp2 = blok[j];
                    blok[j] = temp;
                    temp = tmp2;
                }
                fseek(fp, pozicija, SEEK_SET);
                fwrite(blok, sizeof(Automobil), BLOCK_FACTOR, fp);
                // Ako je temp (poslednji) != -1, treba ga upisati u sledeći blok rekurzivno
                if (temp.registarska_oznaka != -1 && temp.registarska_oznaka != 0) {
                    // Pomeri se na sledeći blok i rekurzivno umetni temp
                    pozicija += BLOCK_FACTOR * sizeof(Automobil);
                    fseek(fp, pozicija, SEEK_SET);
                    fread(blok, sizeof(Automobil), BLOCK_FACTOR, fp);
                    
                    // Pronađi pravu poziciju za umetanje u sortiranom redu
                    int umetnuto = 0;
                    int pozicija_u_bloku = -1;
                    for (int j = 0; j < BLOCK_FACTOR; j++) {
                        // Ako je prazno mesto ili EOF marker
                        if (blok[j].registarska_oznaka == -1 || blok[j].registarska_oznaka == 0) {
                            blok[j] = temp;
                            if (j < BLOCK_FACTOR - 1 && blok[j + 1].registarska_oznaka != -1)
                                blok[j + 1].registarska_oznaka = -1;
                            umetnuto = 1;
                            pozicija_u_bloku = j;
                            break;
                        }
                        // Ako treba umetanje sa pomeranjem u sortiranom redu
                        else if (blok[j].registarska_oznaka > temp.registarska_oznaka) {
                            // Pomeri sve elemente udesno
                            Automobil temp2 = blok[j];
                            blok[j] = temp;
                            for (int k = j + 1; k < BLOCK_FACTOR; k++) {
                                Automobil temp3 = blok[k];
                                blok[k] = temp2;
                                temp2 = temp3;
                                if (temp2.registarska_oznaka == -1 || temp2.registarska_oznaka == 0) 
                                    break;
                            }
                            umetnuto = 1;
                            pozicija_u_bloku = j;
                            break;
                        }
                    }
                    
                    if (umetnuto) {
                        fseek(fp, pozicija, SEEK_SET);
                        fwrite(blok, sizeof(Automobil), BLOCK_FACTOR, fp);
                        fclose(fp);
                        printf("Blok: %d, Pozicija: %d\n", (int)(pozicija / (BLOCK_FACTOR * sizeof(Automobil))), pozicija_u_bloku);
                        return;
                    }
                    // Ako je i sledeći blok pun, kreiraj novi blok
                    Automobil novi_blok[BLOCK_FACTOR] = {0};
                    novi_blok[0] = temp;
                    novi_blok[1].registarska_oznaka = -1;
                    fseek(fp, 0, SEEK_END);
                    long nova_pozicija = ftell(fp);
                    fwrite(novi_blok, sizeof(Automobil), BLOCK_FACTOR, fp);
                    fclose(fp);
                    printf("Blok: %d, Pozicija: 0\n", (int)(nova_pozicija / (BLOCK_FACTOR * sizeof(Automobil))));
                    return;
                }
                fclose(fp);
                printf("Blok: %d, Pozicija: %d\n", blok_broj, i);
                return;
            }
        }
        pozicija += BLOCK_FACTOR * sizeof(Automobil);
        blok_broj++;
    }
    // Ako nismo pronašli EOF marker, dodaj novi blok na kraj fajla
    Automobil novi_blok[BLOCK_FACTOR] = {0};
    novi_blok[0] = novi;
    novi_blok[1].registarska_oznaka = -1; // EOF marker
    fseek(fp, 0, SEEK_END);
    long nova_pozicija = ftell(fp);
    fwrite(novi_blok, sizeof(Automobil), BLOCK_FACTOR, fp);
    fclose(fp);
    printf("Blok: %d, Pozicija: 0\n", (int)(nova_pozicija / (BLOCK_FACTOR * sizeof(Automobil))));
}

void prikazi_automobile(const char* filename) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("Ne mogu da otvorim fajl!\n");
        return;
    }
    Automobil blok[BLOCK_FACTOR];
    int redni_broj = 1;
    printf("\nSvi automobili u bazi:\n");
    printf("-------------------------------------------------------------\n");
    while (fread(blok, sizeof(Automobil), BLOCK_FACTOR, fp) == BLOCK_FACTOR) {
        for (int i = 0; i < BLOCK_FACTOR; i++) {
            // Zaustavi ispis na EOF markeru
            if (blok[i].registarska_oznaka == -1) {
                fclose(fp);
                return;
            }
            // Prikazi samo popunjene zapise (preskoci logički obrisane)
            if (blok[i].registarska_oznaka != 0) {
                printf("Automobil #%d\n", redni_broj++);
                printf("Registarska oznaka: %d\n", blok[i].registarska_oznaka);
                printf("Marka: %s\n", blok[i].marka);
                printf("Model: %s\n", blok[i].model);
                printf("Godina proizvodnje: %d\n", blok[i].godina_proizvodnje);
                printf("Elektricno: %s\n", blok[i].elektricno);
                printf("-------------------------------------------------------------\n");
            }
        }
    }
    fclose(fp);
}

void prikazi_podatke_za_registarsku(const char* filename, int trazena_oznaka) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("Ne mogu da otvorim fajl!\n");
        return;
    }
    Automobil blok[BLOCK_FACTOR];
    int blok_broj = 0;
    while (fread(blok, sizeof(Automobil), BLOCK_FACTOR, fp) == BLOCK_FACTOR) {
        for (int i = 0; i < BLOCK_FACTOR; i++) {
            if (blok[i].registarska_oznaka == -1) {
                fclose(fp);
                printf("Slog sa tom registarskom oznakom nije pronađen.\n");
                return;
            }
            if (blok[i].registarska_oznaka == trazena_oznaka) {
                printf("Godina proizvodnje: %d\n", blok[i].godina_proizvodnje);
                printf("Elektricno: %s\n", blok[i].elektricno);
                printf("Blok: %d\n", blok_broj);
                printf("Redni broj sloga u bloku: %d\n", i);
                fclose(fp);
                return;
            }
        }
        blok_broj++;
    }
    fclose(fp);
    printf("Slog sa tom registarskom oznakom nije pronađen.\n");
}

void prikazi_automobile_sa_punjenjima(const char* filename_automobili, const char* filename_parkiranja) {
    FILE *fa = fopen(filename_automobili, "rb");
    if (!fa) {
        printf("Ne mogu da otvorim fajl sa automobilima!\n");
        return;
    }
    FILE *fp = fopen(filename_parkiranja, "rb");
    if (!fp) {
        fclose(fa);
        printf("Ne mogu da otvorim fajl sa parkiranjima!\n");
        return;
    }

    Automobil blok_a[BLOCK_FACTOR];
    int redni_broj = 1;
    int found_any = 0;
    int blok_broj_a = 0;

    printf("\nSvi automobili i njihova parkiranja sa punjenjem:\n");
    printf("=============================================================\n");
    while (fread(blok_a, sizeof(Automobil), BLOCK_FACTOR, fa) == BLOCK_FACTOR) {
        for (int i = 0; i < BLOCK_FACTOR; i++) {
            if (blok_a[i].registarska_oznaka == -1) {
                fclose(fa);
                fclose(fp);
                if (!found_any)
                    printf("Nijedan automobil nema parkiranje sa punjenjem.\n");
                return;
            }
            if (blok_a[i].registarska_oznaka != 0) {
                printf("Automobil #%d\n", redni_broj++);
                printf("Registarska oznaka: %d\n", blok_a[i].registarska_oznaka);
                printf("Marka: %s\n", blok_a[i].marka);
                printf("Model: %s\n", blok_a[i].model);
                printf("Godina proizvodnje: %d\n", blok_a[i].godina_proizvodnje);
                printf("Elektricno: %s\n", blok_a[i].elektricno);
                printf("Blok: %d, Pozicija u bloku: %d\n", blok_broj_a, i);

                // Traži parkiranja za ovaj automobil gde je punjenje "DA"
                int nasao_parkiranje = 0;
                rewind(fp); // vrati se na početak parkiranja
                Parkiranje blok_p[BLOCK_FACTOR_PARKIRANJE];
                int blok_broj = 0;
                int kraj = 0;
                while (!kraj && fread(blok_p, sizeof(Parkiranje), BLOCK_FACTOR_PARKIRANJE, fp) == BLOCK_FACTOR_PARKIRANJE) {
                    for (int j = 0; j < BLOCK_FACTOR_PARKIRANJE; j++) {
                        if (blok_p[j].identifikator == -1) {
                            kraj = 1;
                            break;
                        }
                        if (blok_p[j].registarska_oznaka == blok_a[i].registarska_oznaka &&
                            strcmp(blok_p[j].punjenje, "DA") == 0) {
                            if (!nasao_parkiranje) {
                                printf("  Parkiranja sa punjenjem:\n");
                                nasao_parkiranje = 1;
                                found_any = 1;
                            }
                            printf("    - Datum i vreme: %s\n", blok_p[j].datum_vreme);
                            printf("      Duzina boravka: %d minuta\n", blok_p[j].duzina_boravka);
                            printf("      Blok: %d, Redni broj u bloku: %d\n", blok_broj, j);
                        }
                    }
                    blok_broj++;
                }
                if (!nasao_parkiranje)
                    printf("  Nema parkiranja sa punjenjem za ovaj automobil.\n");
                printf("-------------------------------------------------------------\n");
            }
        }
        blok_broj_a++;
    }
    fclose(fa);
    fclose(fp);
    if (!found_any)
        printf("Nijedan automobil nema parkiranje sa punjenjem.\n");
}

void izmeni_automobil(const char* filename, int trazena_oznaka) {
    FILE *fp = fopen(filename, "rb+");
    if (!fp) {
        printf("Ne mogu da otvorim fajl za izmenu!\n");
        return;
    }
    Automobil blok[BLOCK_FACTOR];
    long pozicija = 0;
    int pronadjen = 0;

    while (fread(blok, sizeof(Automobil), BLOCK_FACTOR, fp) == BLOCK_FACTOR) {
        for (int i = 0; i < BLOCK_FACTOR; i++) {
            if (blok[i].registarska_oznaka == -1) {
                fclose(fp);
                printf("Automobil sa tom registarskom oznakom nije pronađen.\n");
                return;
            }
            if (blok[i].registarska_oznaka == trazena_oznaka) {
                printf("Trenutni podaci:\n");
                printf("Marka: %s\n", blok[i].marka);
                printf("Model: %s\n", blok[i].model);
                printf("Godina proizvodnje: %d\n", blok[i].godina_proizvodnje);
                printf("Elektricno: %s\n", blok[i].elektricno);

                printf("Unesite novu marku (do 30 karaktera): ");
                fgets(blok[i].marka, MAX_STR, stdin);
                blok[i].marka[strcspn(blok[i].marka, "\n")] = 0;

                printf("Unesite novi model (do 30 karaktera): ");
                fgets(blok[i].model, MAX_STR, stdin);
                blok[i].model[strcspn(blok[i].model, "\n")] = 0;

                printf("Unesite novu godinu proizvodnje (4 cifre): ");
                scanf("%d", &blok[i].godina_proizvodnje);
                getchar();

                do {
                    printf("Da li je elektricno vozilo? (DA/NE): ");
                    fgets(blok[i].elektricno, 3, stdin);
                    blok[i].elektricno[strcspn(blok[i].elektricno, "\n")] = 0;
                    if (strcmp(blok[i].elektricno, "DA") != 0 && strcmp(blok[i].elektricno, "NE") != 0) {
                        printf("Dozvoljene vrednosti su 'DA' ili 'NE'. Pokusajte ponovo.\n");
                    }
                } while (strcmp(blok[i].elektricno, "DA") != 0 && strcmp(blok[i].elektricno, "NE") != 0);

                // Upis izmenjenog bloka nazad u fajl
                fseek(fp, pozicija, SEEK_SET);
                fwrite(blok, sizeof(Automobil), BLOCK_FACTOR, fp);
                fclose(fp);
                printf("Podaci o automobilu su uspešno izmenjeni.\n");
                return;
            }
        }
        pozicija += BLOCK_FACTOR * sizeof(Automobil);
    }
    fclose(fp);
    printf("Automobil sa tom registarskom oznakom nije pronađen.\n");
}