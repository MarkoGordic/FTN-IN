#ifndef AUTOMOBIL_H
#define AUTOMOBIL_H

#define MAX_STR 31

typedef struct {
    int registarska_oznaka;
    char marka[MAX_STR];
    char model[MAX_STR];
    int godina_proizvodnje;
    char elektricno[3];
} Automobil;

void kreiraj_prazan_sekvencijalni_fajl(const char* filename);
void unos_automobila(const char* filename);
void prikazi_automobile(const char* filename);
void prikazi_podatke_za_registarsku(const char* filename, int trazena_oznaka);
void prikazi_automobile_sa_punjenjima(const char* filename_automobili, const char* filename_parkiranja);
void izmeni_automobil(const char* filename, int trazena_oznaka);

#endif