#include "parkiranje.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BLOCK_FACTOR_PARKIRANJE 6

void kreiraj_praznu_serijsku_parkiranje_datoteku(const char* filename) {
    FILE *fp = fopen(filename, "wb");
    if (!fp) {
        printf("Greska pri kreiranju fajla!\n");
        return;
    }
    Parkiranje blok[BLOCK_FACTOR_PARKIRANJE] = {0};
    blok[0].identifikator = -1; // specijalan EOF marker na prvoj poziciji
    fwrite(blok, sizeof(Parkiranje), BLOCK_FACTOR_PARKIRANJE, fp);
    fclose(fp);
    printf("Prazna serijska datoteka '%s' sa EOF markerom na prvoj poziciji je kreirana.\n", filename);
}

void unos_parkiranja(const char* filename) {
    FILE *fp = fopen(filename, "rb+");
    if (!fp) {
        printf("Ne mogu da otvorim fajl za upis!\n");
        return;
    }

    Parkiranje novi;
    printf("Unesite identifikator: ");
    scanf("%d", &novi.identifikator);
    getchar();

    printf("Unesite registarsku oznaku (broj): ");
    scanf("%d", &novi.registarska_oznaka);
    getchar();

    printf("Unesite datum i vreme (D-M-YYYY HH:MM): ");
    fgets(novi.datum_vreme, MAX_DATUM_VREME, stdin);
    novi.datum_vreme[strcspn(novi.datum_vreme, "\n")] = 0;

    printf("Unesite duzinu boravka (u minutima): ");
    scanf("%d", &novi.duzina_boravka);
    getchar();

    do {
        printf("Da li je bilo dopunjavanja? (DA/NE): ");
        fgets(novi.punjenje, 3, stdin);
        novi.punjenje[strcspn(novi.punjenje, "\n")] = 0;
        if (strcmp(novi.punjenje, "DA") != 0 && strcmp(novi.punjenje, "NE") != 0) {
            printf("Dozvoljene vrednosti su 'DA' ili 'NE'. Pokusajte ponovo.\n");
        }
    } while (strcmp(novi.punjenje, "DA") != 0 && strcmp(novi.punjenje, "NE") != 0);

    Parkiranje blok[BLOCK_FACTOR_PARKIRANJE];
    long pozicija = 0;
    int blok_broj = 0;

    // Prolazak kroz blokove i provera postojanja identifikatora
    while (fread(blok, sizeof(Parkiranje), BLOCK_FACTOR_PARKIRANJE, fp) == BLOCK_FACTOR_PARKIRANJE) {
        for (int i = 0; i < BLOCK_FACTOR_PARKIRANJE; i++) {
            // Provera duplikata
            if (blok[i].identifikator == novi.identifikator) {
                printf("Parkiranje sa tim identifikatorom već postoji!\n");
                fclose(fp);
                return;
            }
            // Provera EOF markera
            if (blok[i].identifikator == -1) {
                // Upis novog sloga na mesto EOF-a
                blok[i] = novi;
                // Pomeri EOF marker za jedno mesto desno (ako ima mesta u bloku)
                if (i < BLOCK_FACTOR_PARKIRANJE - 1) {
                    blok[i + 1].identifikator = -1;
                } 

                // Vratite se na početak bloka i upišite ga
                fseek(fp, pozicija, SEEK_SET);
                fwrite(blok, sizeof(Parkiranje), BLOCK_FACTOR_PARKIRANJE, fp);
                // Ako je EOF marker bio poslednji u bloku, dodajte novi blok sa EOF markerom
                if (i == BLOCK_FACTOR_PARKIRANJE - 1) {
                    Parkiranje novi_blok[BLOCK_FACTOR_PARKIRANJE] = {0};
                    novi_blok[0].identifikator = -1;
                    fwrite(novi_blok, sizeof(Parkiranje), BLOCK_FACTOR_PARKIRANJE, fp);
                }
                printf("Blok: %d, Pozicija: %d\n", blok_broj, i);

                if (novi.duzina_boravka > 480) {
                    evidentiraj_prekoracenje_log(novi.registarska_oznaka, novi.duzina_boravka);
                }

                fclose(fp);
                return;
            }
        }
        pozicija += BLOCK_FACTOR_PARKIRANJE * sizeof(Parkiranje);
        blok_broj++;
    }

    printf("Greska: nije pronadjen EOF marker ili nije moguce upisati slog.\n");
    fclose(fp);
}

void prikazi_parkiranja(const char* filename) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("Ne mogu da otvorim fajl!\n");
        return;
    }
    Parkiranje blok[BLOCK_FACTOR_PARKIRANJE];
    int redni_broj = 1;
    int blok_broj = 0;
    printf("\nSva parkiranja u bazi:\n");
    printf("-------------------------------------------------------------\n");
    while (fread(blok, sizeof(Parkiranje), BLOCK_FACTOR_PARKIRANJE, fp) == BLOCK_FACTOR_PARKIRANJE) {
        for (int i = 0; i < BLOCK_FACTOR_PARKIRANJE; i++) {
            // Zaustavi ispis na EOF markeru
            if (blok[i].identifikator == -1) {
                fclose(fp);
                return;
            }
            // Prikazi samo popunjene zapise (preskoci logički obrisane)
            if (blok[i].identifikator != 0) {
                printf("Parkiranje #%d\n", redni_broj++);
                printf("Identifikator: %d\n", blok[i].identifikator);
                printf("Registarska oznaka: %d\n", blok[i].registarska_oznaka);
                printf("Datum i vreme: %s\n", blok[i].datum_vreme);
                printf("Duzina boravka: %d minuta\n", blok[i].duzina_boravka);
                printf("Punjenje: %s\n", blok[i].punjenje);
                printf("Blok: %d, Pozicija: %d\n", blok_broj, i);
                printf("-------------------------------------------------------------\n");
            }
        }
        blok_broj++;
    }
    fclose(fp);
}

void evidentiraj_prekoracenje_log(int registarska_oznaka, int duzina_boravka_min) {
    FILE *fp = fopen("log.bin", "rb+");
    if (!fp) {
        // Ako ne postoji, kreiraj novi fajl sa praznim blokom i EOF markerom
        fp = fopen("log.bin", "wb+");
        if (!fp) {
            printf("Ne mogu da otvorim ili kreiram log fajl!\n");
            return;
        }
        LogPrekoracenje blok[BLOCK_FACTOR_LOG] = {0};
        blok[0].identifikator = -1; // EOF marker
        fwrite(blok, sizeof(LogPrekoracenje), BLOCK_FACTOR_LOG, fp);
        fflush(fp);
    }

    LogPrekoracenje blok[BLOCK_FACTOR_LOG];
    long pozicija = 0;
    int nasao_eof = 0;
    int max_id = 0;

    // Pronađi maksimalni identifikator
    fseek(fp, 0, SEEK_SET);
    while (fread(blok, sizeof(LogPrekoracenje), BLOCK_FACTOR_LOG, fp) == BLOCK_FACTOR_LOG) {
        for (int i = 0; i < BLOCK_FACTOR_LOG; i++) {
            if (blok[i].identifikator == -1) break;
            if (blok[i].identifikator > max_id)
                max_id = blok[i].identifikator;
        }
    }

    // Traži EOF marker i upiši novi slog
    fseek(fp, 0, SEEK_SET);
    pozicija = 0;
    while (fread(blok, sizeof(LogPrekoracenje), BLOCK_FACTOR_LOG, fp) == BLOCK_FACTOR_LOG) {
        for (int i = 0; i < BLOCK_FACTOR_LOG; i++) {
            if (blok[i].identifikator == -1) {
                blok[i].identifikator = max_id + 1;
                blok[i].registarska_oznaka = registarska_oznaka;
                blok[i].duzina_boravka = duzina_boravka_min / 60; // u satima

                // Pomeri EOF marker ako ima mesta
                if (i < BLOCK_FACTOR_LOG - 1) {
                    blok[i + 1].identifikator = -1;
                }
                fseek(fp, pozicija, SEEK_SET);
                fwrite(blok, sizeof(LogPrekoracenje), BLOCK_FACTOR_LOG, fp);
                fflush(fp);

                // Ako je EOF bio poslednji, dodaj novi blok sa EOF markerom
                if (i == BLOCK_FACTOR_LOG - 1) {
                    LogPrekoracenje novi_blok[BLOCK_FACTOR_LOG] = {0};
                    novi_blok[0].identifikator = -1;
                    fwrite(novi_blok, sizeof(LogPrekoracenje), BLOCK_FACTOR_LOG, fp);
                    fflush(fp);
                }
                nasao_eof = 1;
                break;
            }
        }
        if (nasao_eof) break;
        pozicija += BLOCK_FACTOR_LOG * sizeof(LogPrekoracenje);
    }
    fclose(fp);
}

void prikazi_log(const char* filename) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("Ne mogu da otvorim log fajl!\n");
        return;
    }
    LogPrekoracenje blok[BLOCK_FACTOR_LOG];
    printf("\nSadržaj log datoteke:\n");
    printf("ID | Reg. oznaka | Boravak (sati)\n");
    printf("-------------------------------\n");
    while (fread(blok, sizeof(LogPrekoracenje), BLOCK_FACTOR_LOG, fp) == BLOCK_FACTOR_LOG) {
        for (int i = 0; i < BLOCK_FACTOR_LOG; i++) {
            if (blok[i].identifikator == -1) {
                fclose(fp);
                return;
            }
            if (blok[i].identifikator != 0) {
                printf("%d | %d | %d\n", blok[i].identifikator, blok[i].registarska_oznaka, blok[i].duzina_boravka);
            }
        }
    }
    fclose(fp);
}

void prikazi_log_po_oznaci(const char* filename, int trazena_oznaka) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("Ne mogu da otvorim log fajl!\n");
        return;
    }
    LogPrekoracenje blok[BLOCK_FACTOR_LOG];
    int found = 0;
    printf("\nPrekoracenja za registarsku oznaku %d:\n", trazena_oznaka);
    printf("ID | Reg. oznaka | Boravak (sati)\n");
    printf("-------------------------------\n");
    while (fread(blok, sizeof(LogPrekoracenje), BLOCK_FACTOR_LOG, fp) == BLOCK_FACTOR_LOG) {
        for (int i = 0; i < BLOCK_FACTOR_LOG; i++) {
            if (blok[i].identifikator == -1) {
                fclose(fp);
                if (!found)
                    printf("Nema prekoracenja za ovu registarsku oznaku.\n");
                return;
            }
            if (blok[i].identifikator != 0 && blok[i].registarska_oznaka == trazena_oznaka) {
                printf("%d | %d | %d\n", blok[i].identifikator, blok[i].registarska_oznaka, blok[i].duzina_boravka);
                found = 1;
            }
        }
    }
    fclose(fp);
    if (!found)
        printf("Nema prekoracenja za ovu registarsku oznaku.\n");
}