#ifndef PARKIRANJE_H
#define PARKIRANJE_H

#define MAX_DATUM_VREME 20
#define BLOCK_FACTOR_PARKIRANJE 6
#define BLOCK_FACTOR_LOG 6

typedef struct {
    int identifikator;
    int registarska_oznaka;
    int duzina_boravka; // u satima
} LogPrekoracenje;



typedef struct {
    int identifikator;
    int registarska_oznaka;
    char datum_vreme[MAX_DATUM_VREME];
    int duzina_boravka;
    char punjenje[3];
} Parkiranje;

void kreiraj_praznu_serijsku_parkiranje_datoteku(const char* filename);
void unos_parkiranja(const char* filename);
void prikazi_parkiranja(const char* filename);
void evidentiraj_prekoracenje_log(int registarska_oznaka, int duzina_boravka_min);
void prikazi_log(const char* filename);
void prikazi_log_po_oznaci(const char* filename, int trazena_oznaka);

#endif