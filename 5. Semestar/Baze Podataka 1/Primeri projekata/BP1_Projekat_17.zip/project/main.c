// Nenad Lukic IN17/2022
// Projektni zadatak #17

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
#include "polaganje_ispita.h"
#include "agregirani_podaci.h"
#include "utils.h"
#include "log_greska.h"

int main()
{
    int glavni_izbor = 0;
    char aktivni_student_fajl[64] = "student.bin";
    char aktivni_polaganje_ispita_fajl[64] = "polaganje_ispita.bin";
    char aktivni_agregirani_podaci_fajl[64] = "agregirani_podaci.bin";

    if (fopen("log.bin", "r") == NULL) {
        kreiraj_praznu_serijsku_log_greska_datoteku("log.bin");
    }


    do {
        printf("\n --- GLAVNI MENI --- \n");
        printf("1. Rad nad datotekom sa podacima studenata \n");
        printf("2. Rad nad datotekom sa podacima o polaganjima ispita \n");
        printf("3. Rad nad datotekom sa agregiranim podacima \n");

        printf("0. Izlaz \n");
        printf("\nIzbor: ");
        scanf("%d", &glavni_izbor);
        ocisti_bafer();

        if (glavni_izbor == 1) {
            int izbor = 0;
            do {
                printf("\n --- MENI STUDENT --- \n");
                printf("Trenutno aktivna datoteka sa podacima studenata: \"%s\"\n", aktivni_student_fajl);

                printf("1. Izaberi naziv fajla \n");
                printf("2. Kreiranje prazne serijske datoteke (faktor blokiranja = 4) \n");
                printf("3. Unos student \n");
                printf("4. Prikaz podataka na osnovu studentski_broj \n");
                printf("5. Prikaz specificnog uslova \n");
                printf("6. Modifikacija informacija o studentu \n");
                printf("7. Izvestaj o log datoteci \n");
                printf("8. DEBAG: Ispis informacija o studentima \n");

                printf("0. Nazad na glavni meni \n");
                printf("\nIzbor: ");
                scanf("%d", &izbor);
                ocisti_bafer();

                switch (izbor) {
                    case 1: {
                        printf("Unesite ime datoteke: ");
                        fgets(aktivni_student_fajl, sizeof(aktivni_student_fajl), stdin);
                        aktivni_student_fajl[strcspn(aktivni_student_fajl, "\n")] = 0;
                        printf("Promenjena trenutno aktivna datoteka za studente na: %s\n", aktivni_student_fajl);
                        break;
                    }
                    case 2: {
                        printf("Unesite ime datoteke koju zelite da napravite: ");
                        fgets(aktivni_student_fajl, sizeof(aktivni_student_fajl), stdin);
                        aktivni_student_fajl[strcspn(aktivni_student_fajl, "\n")] = 0;
                        kreiraj_praznu_serijsku_student_datoteku(aktivni_student_fajl);
                        break;
                    }
                    case 3: {
                        unos_studenta(aktivni_student_fajl, aktivni_polaganje_ispita_fajl, aktivni_agregirani_podaci_fajl);
                        break;
                    }
                    case 4: {
                        int studentski_broj = 0;
                        printf("Unesite studentski_broj: "); scanf("%d", &studentski_broj); ocisti_bafer();
                        prikazi_podatke_za_studentski_broj(aktivni_student_fajl, studentski_broj);
                        break;
                    }
                    case 5: {
                        uslov_studenti(aktivni_student_fajl, aktivni_polaganje_ispita_fajl);
                        break;
                    }
                    case 6: {
                        int studentski_broj = 0;
                        printf("Unesite studentski_broj: "); scanf("%d", &studentski_broj); ocisti_bafer();
                        izmeni_studenta(aktivni_student_fajl, aktivni_agregirani_podaci_fajl, studentski_broj);
                        break;
                    }
                    case 7: {
                        prikaz_log_datoteka();
                        break;
                    }
                    case 8: {
                        ispis_studenti(aktivni_student_fajl);
                        break;
                    }
                    case 0: {
                        printf("Povratak na glavni meni.\n");
                        break;
                    }
                    default: {
                        printf("Nepoznat izbor.\n");
                    }
                }
            } while (izbor != 0);
        }
        else if (glavni_izbor == 2) {
            int izbor = 0;
            do {
                printf("\n --- MENI POLAGANJE ISPITA --- \n");
                printf("Trenutno aktivna datoteka sa podacima o polaganjima ispita: \"%s\"\n", aktivni_polaganje_ispita_fajl);

                printf("1. Izaberi naziv fajla \n");
                printf("2. Kreiranje prazne serijske datoteke (faktor blokiranja = 5) \n");
                printf("3. Unos polaganje_ispita \n");
                printf("4. DEBAG: Ispis polaganje_ispita \n");

                printf("0. Nazad na glavni meni \n");
                printf("\nIzbor: ");
                scanf("%d", &izbor);
                ocisti_bafer();

                switch (izbor) {
                    case 1: {
                        printf("Unesite ime datoteke: ");
                        fgets(aktivni_polaganje_ispita_fajl, sizeof(aktivni_polaganje_ispita_fajl), stdin);
                        aktivni_polaganje_ispita_fajl[strcspn(aktivni_polaganje_ispita_fajl, "\n")] = 0;
                        printf("Promenjena trenutno aktivna datoteka za polaganje ispita na: %s\n", aktivni_polaganje_ispita_fajl);
                        break;
                    }
                    case 2: {
                        printf("Unesite ime datoteke koju zelite da napravite: ");
                        fgets(aktivni_polaganje_ispita_fajl, sizeof(aktivni_polaganje_ispita_fajl), stdin);
                        aktivni_polaganje_ispita_fajl[strcspn(aktivni_polaganje_ispita_fajl, "\n")] = 0;
                        kreiraj_praznu_serijsku_polaganje_ispita_datoteku(aktivni_polaganje_ispita_fajl);
                        break;
                    }
                    case 3: {
                        unos_polaganja_ispita(aktivni_polaganje_ispita_fajl, aktivni_student_fajl, aktivni_agregirani_podaci_fajl);
                        break;
                    }
                    case 4: {
                        ispis_polaganje_ispita(aktivni_polaganje_ispita_fajl);
                        break;
                    }
                    case 0: {
                        printf("Povratak na glavni meni.\n");
                        break;
                    }
                    default: {
                        printf("Nepoznat izbor.\n");
                    }
                }
            } while (izbor != 0);
        }
        else if (glavni_izbor == 3) {
            int izbor = 0;
            do {
                printf("\n --- MENI AGREGIRANI PODACI --- \n");
                printf("Trenutno aktivna datoteka sa agregiranim podacima: \"%s\"\n", aktivni_agregirani_podaci_fajl);

                printf("1. Izaberi naziv fajla \n");
                printf("2. Formiranje staticke rasute datoteke u 2 prolaza na osnvou \"%s\" i \"%s\" datoteka\n", aktivni_student_fajl, aktivni_polaganje_ispita_fajl);
                printf("3. Unos agregirani_podaci \n");
                printf("4. Prikaz podataka na osnovu studentski_broj \n");
                printf("5. Prikaz studenata sa broj_izlaska koji je veci od unetog \n");
                printf("6. Logicko brisanje sloga \n");
                printf("7. DEBAG: Ispis sadrzaja datoteke \n");

                printf("0. Nazad na glavni meni \n");
                printf("\nIzbor: ");
                scanf("%d", &izbor);
                ocisti_bafer();

                switch (izbor) {
                    case 1: {
                        printf("Unesite ime datoteke: ");
                        fgets(aktivni_agregirani_podaci_fajl, sizeof(aktivni_agregirani_podaci_fajl), stdin);
                        aktivni_agregirani_podaci_fajl[strcspn(aktivni_agregirani_podaci_fajl, "\n")] = 0;
                        printf("Promenjena trenutno aktivna datoteka za agregirane podatke na: %s\n", aktivni_agregirani_podaci_fajl);
                        break;
                    }
                    case 2: {
                        printf("Unesite ime datoteke koju zelite da napravite: ");
                        fgets(aktivni_agregirani_podaci_fajl, sizeof(aktivni_agregirani_podaci_fajl), stdin);
                        aktivni_agregirani_podaci_fajl[strcspn(aktivni_agregirani_podaci_fajl, "\n")] = 0;
                        kreiraj_staticku_agregirani_podaci_datoteku(aktivni_agregirani_podaci_fajl, aktivni_student_fajl, aktivni_polaganje_ispita_fajl);
                        break;
                    }
                    case 3: {
                        unos_agregirani_podaci(aktivni_agregirani_podaci_fajl);
                        break;
                    }
                    case 4: {
                        int studentski_broj = 0;
                        printf("Unesite studentski_broj: "); scanf("%d", &studentski_broj); ocisti_bafer();
                        prikaz_prosecna_ocena(aktivni_agregirani_podaci_fajl, studentski_broj);
                        break;
                    }
                    case 5: {
                        int broj_izlazaka = 0;
                        printf("Unesite broj_izlazaka: "); scanf("%d", &broj_izlazaka); ocisti_bafer();
                        prikaz_broj_izlazaka(aktivni_agregirani_podaci_fajl, broj_izlazaka);
                        break;
                    }
                    case 6: {
                        int studentski_broj = 0;
                        printf("Unesite studentski_broj: "); scanf("%d", &studentski_broj); ocisti_bafer();
                        logicko_brisanje_agregirani_podaci(aktivni_agregirani_podaci_fajl, studentski_broj);
                        break;
                    }
                    case 7: {
                        ispis_agregirani_podaci(aktivni_agregirani_podaci_fajl);
                        break;
                    }
                    case 0: {
                        printf("Povratak na glavni meni.\n");
                        break;
                    }
                    default: {
                        printf("Nepoznat izbor.\n");
                    }
                }
            } while (izbor != 0);
        }
        else if (glavni_izbor == 0) {
            printf("Izlaz iz programa.\n");
        }
        else {
            printf("Nepoznat izbor.\n");
        }

    } while (glavni_izbor != 0);

    return 0;
}
