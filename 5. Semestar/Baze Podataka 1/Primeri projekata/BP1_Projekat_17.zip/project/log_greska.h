#ifndef LOG_GRESKA_H_INCLUDED
#define LOG_GRESKA_H_INCLUDED

#define UNETI_STUDENT_VEC_POSTOJI_U_STATICKOJ 1
#define UNETI_STUDENT_NIJE_UNET_U_STATICKU 2
#define UNETI_STUDENT_NIJE_UNET_UOPSTE 3

#define MAX_OPIS_GRESKE 61
#define FAKTOR_BLOKIRANJA_LOG_GRESKA 5

#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int identifikator;
    int kod_greske;
    char opis_greske[MAX_OPIS_GRESKE];
} log_greska;

// Formiranje prazne serijske datoteke
void kreiraj_praznu_serijsku_log_greska_datoteku(const char*);

// Unos log_greska
void unos_log_greska(int, const char*);

// Ispis log_greska i statistike o log_greskama
void prikaz_log_datoteka();

#endif // LOG_GRESKA_H_INCLUDED
