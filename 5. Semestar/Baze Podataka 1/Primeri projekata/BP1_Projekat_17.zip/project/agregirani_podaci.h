#ifndef AGREGIRANI_PODACI_H_INCLUDED
#define AGREGIRANI_PODACI_H_INCLUDED

#define MAX_IME_I_PREZIME 51
#define MAX_SMER 5
#define FAKTOR_BAKETIRANJA 5
#define BROJ_BAKETA 7
#define FIKSNI_KORAK 1
#define FAKTOR_BLOKIRANJA_STUDENT 4
#define FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA 5

#include "utils.h"
#include "polaganje_ispita.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct student_st student;
typedef struct polaganje_ispita_st polaganje_ispita;

typedef struct {
    int studentski_broj;
    char ime_i_prezime[MAX_IME_I_PREZIME];
    char smer[MAX_SMER];
    int broj_dosijea;
    int godina_upisa;
    int godina_studija;
    int broj_polozenih_ispita;
    int broj_izlazaka;
    double prosecna_ocena;
    double prosek_predispitnih;
    int statusno_polje;
} agregirani_podaci;

// Kreiranje staticke rasute datoteke
int probabilisticka_transformacija(int);
int upis_prvi_prolaz(FILE*, agregirani_podaci);
int upis_drugi_prolaz(FILE*, agregirani_podaci);
void kreiraj_staticku_agregirani_podaci_datoteku(const char*, const char*, const char*);

// Unos sloga
int unos_agregirani_podaci(const char*);
void upisi_slog(FILE*, int, int, agregirani_podaci*);
void trazenje_sloga(FILE*, int, int*, int*, int*, int*);

// Prikaz prosecne ocene
void prikaz_prosecna_ocena(const char*, int);

// Prikaz studenata na osnovu broj_izlazaka
void prikaz_broj_izlazaka(const char*, int);

// Logicko brisanje
int logicko_brisanje_agregirani_podaci(const char*, int);

// Propagiranje unosa studenta ka rasutoj datoteci
int unos_na_osnovu_studenta(const char*, const char*, student);

// Propagiranje modifikacije studenta ka rasutoj datoteci
int modifikacija_na_osnovu_studenta(const char*, student);

// Propagiranje unosa polaganja_ispita ka rasutoj datoteci
int modifikacija_na_osnovu_polaganja_ispita(const char*, const char*, const char*, polaganje_ispita);

// Ispis agregirani_podaci
void ispis_agregirani_podaci(const char*);

#endif // AGREGIRANI_PODACI_H_INCLUDED
