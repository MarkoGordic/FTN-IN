#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void ocisti_bafer();
int provera_ascii(const char*);

#endif // UTILS_H_INCLUDED
