#include "utils.h"

void ocisti_bafer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

int provera_ascii(const char* tekst) {
    for(int i = 0; tekst[i]; i++) {
        if ((unsigned char)tekst[i] < 32 || (unsigned char)tekst[i] > 127)
            return 0;
    }
    return 1;
}
