#ifndef STUDENT_H_INCLUDED
#define STUDENT_H_INCLUDED

#define MAX_IME_I_PREZIME 51
#define MAX_SMER 5
#define FAKTOR_BLOKIRANJA_STUDENT 4

#include "utils.h"
#include "polaganje_ispita.h"
#include "agregirani_podaci.h"
#include "log_greska.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct student_st {
    int studentski_broj;
    char ime_i_prezime[MAX_IME_I_PREZIME];
    char smer[MAX_SMER];
    int broj_dosijea;
    int godina_upisa;
    int godina_studija;
} student;

// Formiranje prazne serijske datoteke
void kreiraj_praznu_serijsku_student_datoteku(const char*);

// Unos studenta
void unos_studenta(const char*, const char*, const char*);

// Prikaz trazenih informacija za studenta na osnovu studentski_broj
void prikazi_podatke_za_studentski_broj(const char*, int);
void uslov_studenti(const char*, const char*);

// Modifikacija studenta
void izmeni_studenta(const char*, const char*, int);

// Korisceno za deo 3, zahtev 9, provera da li student postoji u serijskoj
int postoji_student(const char*, int);

// Ispis student
void ispis_studenti(const char*);

#endif // STUDENT_H_INCLUDED
