#ifndef POLAGANJE_ISPITA_H_INCLUDED
#define POLAGANJE_ISPITA_H_INCLUDED

#define MAX_NAZIV_PREDMETA 31
#define FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA 5

#include "utils.h"
#include "student.h"
#include "agregirani_podaci.h"
#include "log_greska.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct polaganje_ispita_st {
    int identifikator;
    int studentski_broj;
    char naziv_predmeta[MAX_NAZIV_PREDMETA];
    int ocena;
    int broj_predispitnih_poena;
    int broj_ispitnih_poena;
} polaganje_ispita;

// Formiranje prazne serijske datoteke
void kreiraj_praznu_serijsku_polaganje_ispita_datoteku(const char*);

// Unos polaganje_ispita
void unos_polaganja_ispita(const char*, const char*, const char*);

// Ispis polaganje_ispita
void ispis_polaganje_ispita(const char*);

#endif // POLAGANJE_ISPITA_H_INCLUDED
