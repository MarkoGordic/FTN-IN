#include "log_greska.h"

/// Formiranje prazne serijske datoteke

void kreiraj_praznu_serijsku_log_greska_datoteku(const char* filename) {
    FILE *fajl = fopen(filename, "wb");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom kreiranja datoteke \"%s\"!\n", filename);
        return;
    }

    // Kreiranje prvog bloka i specijalnog poslednjeg sloga
    log_greska blok[FAKTOR_BLOKIRANJA_LOG_GRESKA] = {0};
    blok[0].identifikator = -1;
    fwrite(blok, sizeof(log_greska), FAKTOR_BLOKIRANJA_LOG_GRESKA, fajl);
    fclose(fajl);
}

/// Unos log_greska

void unos_log_greska(int kod_greske, const char* opis_greske) {
    // Otvaranje fajla
    FILE *fajl = fopen("log.bin", "rb+");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"log.bin\"!\n");
        return;
    }

    // Novi log_greska koji se dodaje u fajl
    log_greska novi_log_greska = {0};
    novi_log_greska.kod_greske = kod_greske;
    strcpy(novi_log_greska.opis_greske, opis_greske);

    // Ako je prazan, prvi novi ce biti 1, a ako nije bice sracunato ovo ispravno :)
    int novi_identifikator = 1;
    int pozicija_bloka = 0;
    log_greska blok[FAKTOR_BLOKIRANJA_LOG_GRESKA];
    while((int)fread(blok, sizeof(log_greska), FAKTOR_BLOKIRANJA_LOG_GRESKA, fajl) == FAKTOR_BLOKIRANJA_LOG_GRESKA) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_LOG_GRESKA; i++) {
            // Provera krajnjeg sloga
            if (blok[i].identifikator == -1) {
                // Upis novog sloga
                novi_log_greska.identifikator = novi_identifikator;
                blok[i] = novi_log_greska;
                // Upis krajnjeg sloga
                if (i < FAKTOR_BLOKIRANJA_LOG_GRESKA - 1) {
                    blok[i+1].identifikator = -1;
                }
                // Upis bloka
                fseek(fajl, pozicija_bloka, SEEK_SET);
                fwrite(blok, sizeof(log_greska), FAKTOR_BLOKIRANJA_LOG_GRESKA, fajl);
                // U slucaju da je krajnji slog fajla bio poslednji u bloku
                if (i == FAKTOR_BLOKIRANJA_LOG_GRESKA - 1) {
                    log_greska novi_blok[FAKTOR_BLOKIRANJA_LOG_GRESKA] = {0};
                    novi_blok[0].identifikator = -1;
                    fwrite(novi_blok, sizeof(log_greska), FAKTOR_BLOKIRANJA_LOG_GRESKA, fajl);
                }

                fclose(fajl);
                return;
            }
            novi_identifikator++;
        }
        pozicija_bloka += FAKTOR_BLOKIRANJA_LOG_GRESKA * sizeof(log_greska);
    }

    fclose(fajl);
}

/// Ispis log_greska i statistike o log_greskama

void prikaz_log_datoteka() {
    // Otvaranje fajla
    FILE *fajl = fopen("log.bin", "rb");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"log.bin\"!\n");
        return;
    }

    log_greska blok[FAKTOR_BLOKIRANJA_LOG_GRESKA];

    // Broj pojavljivanja svakog tipa greske
    int tip_greske_1 = 0, tip_greske_2 = 0, tip_greske_3 = 0;

    int blok_broj = 0;
    // Prolazak kroz blokove
    while((int)fread(blok, sizeof(log_greska), FAKTOR_BLOKIRANJA_LOG_GRESKA, fajl) == FAKTOR_BLOKIRANJA_LOG_GRESKA) {
        printf("\n--- BLOK %d ---\n", blok_broj);
        for (int i = 0; i < FAKTOR_BLOKIRANJA_LOG_GRESKA; i++) {
            // Provera krajnjeg sloga
            if (blok[i].identifikator == -1) {
                fclose(fajl);

                printf("Tip greske: 1 tj. \"UNETI_STUDENT_VEC_POSTOJI_U_STATICKOJ\", Broj pojavljivanja: %d\n", tip_greske_1);
                printf("Tip greske: 2 tj. \"UNETI_STUDENT_NIJE_UNET_U_STATICKU\", Broj pojavljivanja: %d\n", tip_greske_2);
                printf("Tip greske: 3 tj. \"UNETI_STUDENT_NIJE_UNET_UOPSTE\", Broj pojavljivanja: %d\n", tip_greske_3);

                return;
            }
            printf("%d %d %s\n", blok[i].identifikator, blok[i].kod_greske, blok[i].opis_greske);
            if (blok[i].kod_greske == UNETI_STUDENT_VEC_POSTOJI_U_STATICKOJ) tip_greske_1++;
            if (blok[i].kod_greske == UNETI_STUDENT_NIJE_UNET_U_STATICKU) tip_greske_2++;
            if (blok[i].kod_greske == UNETI_STUDENT_NIJE_UNET_UOPSTE) tip_greske_3++;
        }
        blok_broj++;
    }

    fclose(fajl);
}
