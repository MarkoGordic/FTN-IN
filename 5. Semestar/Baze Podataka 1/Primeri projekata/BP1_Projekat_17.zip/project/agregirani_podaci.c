#include "agregirani_podaci.h"

/// Kreiranje staticke rasute datoteke

int probabilisticka_transformacija(int identifikator) {
    return identifikator % BROJ_BAKETA;
}

int upis_prvi_prolaz(FILE* fajl, agregirani_podaci novi_podaci) {
    int baket_idx = probabilisticka_transformacija(novi_podaci.studentski_broj);
    int pozicija_bloka = baket_idx * FAKTOR_BAKETIRANJA * sizeof(agregirani_podaci);

    agregirani_podaci blok[FAKTOR_BAKETIRANJA];

    fseek(fajl, pozicija_bloka, SEEK_SET);
    fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);
    fseek(fajl, pozicija_bloka, SEEK_SET);

    for (int i = 0; i < FAKTOR_BAKETIRANJA; i++) {
        if (!blok[i].statusno_polje) {
            blok[i] = novi_podaci;
            fwrite(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);
            return 1;
        }
    }
    return 0;
}

int upis_drugi_prolaz(FILE* fajl, agregirani_podaci prekoracilac) {
    int baket_idx = probabilisticka_transformacija(prekoracilac.studentski_broj);
    int pocetni_idx = baket_idx;
    baket_idx = (baket_idx + 1) % BROJ_BAKETA; // pretragu slobodnog mesta zapocinjemo od narednog baketa

    int pozicija_bloka = baket_idx * FAKTOR_BAKETIRANJA * sizeof(agregirani_podaci);
    agregirani_podaci blok[FAKTOR_BAKETIRANJA];

    // Idemo redom kroz svaki baket i citamo njegove slogove i trazimo prvi slobodan
    while (baket_idx != pocetni_idx) {
        fseek(fajl, pozicija_bloka, SEEK_SET);
        fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);
        fseek(fajl, pozicija_bloka, SEEK_SET);

        for (int i = 0; i < FAKTOR_BAKETIRANJA; i++) {
            if (!blok[i].statusno_polje) {
                blok[i] = prekoracilac;
                fwrite(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);
                return 1; // uspesno smesten
            }
        }

        baket_idx = (baket_idx + FIKSNI_KORAK) % BROJ_BAKETA;
        pozicija_bloka = baket_idx * FAKTOR_BAKETIRANJA * sizeof(agregirani_podaci);
    }
    return 0; // puna datoteka
}

void kreiraj_staticku_agregirani_podaci_datoteku(const char* filename_agregirani_podaci, const char* filename_student, const char* filename_polaganje_ispita) {
    // Otvaranje fajlova
    FILE* file_student = fopen(filename_student, "rb");
    FILE* file_polaganje_ispita = fopen(filename_polaganje_ispita, "rb");

    FILE* file_agregirani_podaci = fopen(filename_agregirani_podaci, "wb+");
    FILE* temp_prekoracioci = fopen("prekoracioci.bin", "wb+");

    if (file_student == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename_student);
        return;
    }
    if (file_polaganje_ispita == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename_polaganje_ispita);
        return;
    }
    if (file_agregirani_podaci == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename_agregirani_podaci);
        return;
    }
    if (temp_prekoracioci == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"prekoracioci.bin\"!\n");
        return;
    }

    // Kreiranje prazne staticke rasute datoteke
    agregirani_podaci blok[FAKTOR_BAKETIRANJA] = {0};
    for (int i = 0; i < BROJ_BAKETA; i++) {
        fwrite(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, file_agregirani_podaci);
    }

    // Prvi prolaz - Upis slogova
    // Ucitavamo studenta i onda prolazimo kroz polaganja da vidimo da li negde ima studenta
    student blok_studenti[FAKTOR_BLOKIRANJA_STUDENT];
    polaganje_ispita blok_polaganje_ispita[FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA];

    int studenti_obradjeni = 0;

    while((int)fread(blok_studenti, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, file_student) == FAKTOR_BLOKIRANJA_STUDENT) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_STUDENT; i++) {
            // Provera krajnjeg sloga
            if (blok_studenti[i].studentski_broj == -1) {
                studenti_obradjeni = 1;
                break;
            }

            // Otkrivanje podataka za agregirani_podaci za trenutnog student
            int broj_izlazaka = 0, broj_polozenih_ispita = 0, suma_ocena = 0;
            rewind(file_polaganje_ispita);
            while ((int)fread(blok_polaganje_ispita, sizeof(polaganje_ispita), FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA, file_polaganje_ispita) == FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA) {
                for (int j = 0; j < FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA; j++) {
                    if (blok_polaganje_ispita[j].studentski_broj == blok_studenti[i].studentski_broj) {
                        broj_izlazaka++;
                        if (blok_polaganje_ispita[j].ocena > 5) {
                            suma_ocena += blok_polaganje_ispita[j].ocena;
                            broj_polozenih_ispita++;
                        }
                    }
                }
            }

            // Kreiranje novog studenta
            agregirani_podaci novi_podaci = {0};
            novi_podaci.studentski_broj = blok_studenti[i].studentski_broj;
            strcpy(novi_podaci.ime_i_prezime, blok_studenti[i].ime_i_prezime);
            strcpy(novi_podaci.smer, blok_studenti[i].smer);
            novi_podaci.broj_dosijea = blok_studenti[i].broj_dosijea;
            novi_podaci.godina_upisa = blok_studenti[i].godina_upisa;
            novi_podaci.godina_studija = blok_studenti[i].godina_studija;
            novi_podaci.broj_polozenih_ispita = broj_polozenih_ispita;
            novi_podaci.broj_izlazaka = broj_izlazaka;
            novi_podaci.prosecna_ocena = (broj_polozenih_ispita > 0) ? round(((double)suma_ocena / broj_polozenih_ispita) * 100) / 100 : 0;
            novi_podaci.statusno_polje = 1;

            // Upisivanje sloga u njegov maticni baket ako je to moguce
            if (!upis_prvi_prolaz(file_agregirani_podaci, novi_podaci)) {
                fwrite(&novi_podaci, sizeof(agregirani_podaci), 1, temp_prekoracioci);
            }
        }
        if (studenti_obradjeni)
            break;
    }


    // Drugi prolaz - Obrada prekoracilaca
    rewind(temp_prekoracioci);
    agregirani_podaci prekoracilac = {0};
    while (fread(&prekoracilac, sizeof(agregirani_podaci), 1, temp_prekoracioci) == 1) {
        upis_drugi_prolaz(file_agregirani_podaci, prekoracilac);
    }

    // Zatvaranje fajlova
    fclose(file_student);
    fclose(file_polaganje_ispita);
    fclose(file_agregirani_podaci);
    fclose(temp_prekoracioci);
    remove("prekoracioci.bin");
}

/// Unos sloga

int unos_agregirani_podaci(const char* filename) {
    // Otvaranje fajla
    FILE* fajl = fopen(filename, "rb+");
    if (!fajl) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename);
        return 1;
    }

    agregirani_podaci novi_podatak = {0};

    printf("Unesite studentski_broj: "); scanf("%d", &novi_podatak.studentski_broj); ocisti_bafer();

    printf("Unesite ime_i_prezime (do 50 karaktera): ");
    fgets(novi_podatak.ime_i_prezime, MAX_IME_I_PREZIME, stdin);
    novi_podatak.ime_i_prezime[strcspn(novi_podatak.ime_i_prezime, "\n")] = 0;
    if (!provera_ascii(novi_podatak.ime_i_prezime)) {
        printf("Greska: ime_i_prezime sme da sadrzi samo ASCII karaktere.\n");
        fclose(fajl);
        return 1;
    }

    printf("Unesite smer (do 4 karaktera): ");
    fgets(novi_podatak.smer, MAX_SMER, stdin);
    novi_podatak.smer[strcspn(novi_podatak.smer, "\n")] = 0;
    if (!provera_ascii(novi_podatak.smer)) {
        printf("Greska: smer sme da sadrzi samo ASCII karaktere.\n");
        fclose(fajl);
        return 1;
    }

    printf("Unesite broj_dosijea: "); scanf("%d", &novi_podatak.broj_dosijea); ocisti_bafer();

    printf("Unesite godina_upisa (4 cifre): "); scanf("%d", &novi_podatak.godina_upisa); ocisti_bafer();
    if (novi_podatak.godina_upisa < 0 || novi_podatak.godina_upisa > 9999) {
        printf("Greska: godina_upisa mora da ima tacno 4 cifre.\n");
        fclose(fajl);
        return 1;
    }

    printf("Unesite godina_studija (1 cifra): "); scanf("%d", &novi_podatak.godina_studija); ocisti_bafer();
    if (novi_podatak.godina_studija < 0 || novi_podatak.godina_studija > 9) {
        printf("Greska: godina_studija mora da ima tacno 1 cifru.\n");
        fclose(fajl);
        return 1;
    }

    printf("Unesite broj_polozenih_ispita: "); scanf("%d", &novi_podatak.broj_polozenih_ispita); ocisti_bafer();

    printf("Unesite broj_izlazaka: "); scanf("%d", &novi_podatak.broj_izlazaka); ocisti_bafer();

    printf("Unesite prosecna_ocena: "); scanf("%lf", &novi_podatak.prosecna_ocena); ocisti_bafer();
    novi_podatak.statusno_polje = 1;

    // Korak 1 - Pozivanje procesa trazenja
    int ind_usp_tr = 0, ind_psl = 0, baket_idx = 0, poz_u_baketu = 0;
    trazenje_sloga(fajl, novi_podatak.studentski_broj, &ind_usp_tr, &ind_psl, &baket_idx, &poz_u_baketu);

    // Korak 2 - Provera rezultata trazenja
    if (ind_usp_tr) {
        // Slog vec postoji!
        printf("Greska: Slog sa datim studentski_broj = %d vec postoji!\n", novi_podatak.studentski_broj);
        fclose(fajl);
        return 1;  // Neuspesno
    }
    if (!ind_psl) {
        // Nema slobodnih lokacija u datoteci
        printf("Greska: Staticka rasuta datoteka je puna!\n");
        fclose(fajl);
        return 1;  // Neuspesno
    }

    // Korak 3 - Nastavak upisa
    // Dodajemo slog:
    // ako je trazenje neuspesno -> ind_usp_tr == 0,
    // ako postoje slobodne lokacije -> ind_psl == 1.
    upisi_slog(fajl, baket_idx, poz_u_baketu, &novi_podatak);

    printf("Uspesno dodat slog.\n");
    fclose(fajl);
    return 0;
}

// Upisi slog na odredjenu poziciju u datoteci
void upisi_slog(FILE* f, int baket_idx, int pozicija_u_baketu, agregirani_podaci* slog) {
    int pozicija = baket_idx * FAKTOR_BAKETIRANJA * sizeof(agregirani_podaci);

    agregirani_podaci blok[FAKTOR_BAKETIRANJA];
    fseek(f, pozicija, SEEK_SET);
    fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, f);
    fseek(f, pozicija, SEEK_SET);

    blok[pozicija_u_baketu] = *slog;
    fwrite(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, f);
}

void trazenje_sloga(FILE* fajl, int id_kljuc, int* ind_usp_tr, int* ind_psl, int* baket_idx, int* poz_u_baketu) {
    *baket_idx = probabilisticka_transformacija(id_kljuc);  // Maticni baket
    int pocetni_idx = *baket_idx;
    int prva_slobodna_baket = -1;
    int prva_slobodna_poz = -1;

    *ind_usp_tr = 99;  // Indikator: 99 = u toku, 0 = nije pronadjen, 1 = pronadjen
    *ind_psl = 1;      // Indikator: 0 = nema slobodnih, 1 = ima slobodnih

    // Idemo redom kroz svaki baket i citamo njegove slogove i trazimo prvi slobodan slog
    int pozicija_bloka = *baket_idx * FAKTOR_BAKETIRANJA * sizeof(agregirani_podaci);
    agregirani_podaci blok[FAKTOR_BAKETIRANJA];
    do {
        fseek(fajl, pozicija_bloka, SEEK_SET);
        fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);
        fseek(fajl, pozicija_bloka, SEEK_SET);

        for (int i = 0; i < FAKTOR_BAKETIRANJA; i++) {
            // Proveravamo da li slog vec postoji
            if (blok[i].studentski_broj == id_kljuc && blok[i].statusno_polje) {
                *ind_usp_tr = 1;
                *poz_u_baketu = i;
                return;
            }

            // Proveravamo da li smo pronasli slobodnu lokaciju
            if (!blok[i].statusno_polje) {
                if (prva_slobodna_baket == -1) {
                    prva_slobodna_baket = *baket_idx;
                    prva_slobodna_poz = i;
                }
                *baket_idx = prva_slobodna_baket;
                *poz_u_baketu = i;
                *ind_usp_tr = 0;
                *ind_psl = 1;
                return;
            }
        }

        *baket_idx = (*baket_idx + FIKSNI_KORAK) % BROJ_BAKETA;
        pozicija_bloka = *baket_idx * FAKTOR_BAKETIRANJA * sizeof(agregirani_podaci);
    } while (*baket_idx != pocetni_idx);

    // Obisli smo sve bakete i ipak je jedan slobodan
    if (prva_slobodna_baket != -1) {
        *baket_idx = prva_slobodna_baket;
        *poz_u_baketu = prva_slobodna_poz;
        *ind_usp_tr = 0;
        *ind_psl = 1;
    }
    // Obisli smo sve bakete i datoteka je puna
    else {
        *ind_usp_tr = 0;
        *ind_psl = 0;
    }
}

/// Prikaz prosecne ocene

void prikaz_prosecna_ocena(const char* filename, int studentski_broj) {
    FILE* fajl = fopen(filename, "rb");
    if (!fajl) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename);
        return;
    }

    int ind_usp_tr = 0, ind_psl = 0, baket_idx = 0, poz_u_baketu = 0;
    trazenje_sloga(fajl, studentski_broj, &ind_usp_tr, &ind_psl, &baket_idx, &poz_u_baketu);

    if (ind_usp_tr) {
        int pozicija = baket_idx * FAKTOR_BAKETIRANJA * sizeof(agregirani_podaci);

        agregirani_podaci blok[FAKTOR_BAKETIRANJA];
        fseek(fajl, pozicija, SEEK_SET);
        fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);
        printf("------------------------------------------------------------\n");
        printf("Informacije o studentu za studentski_broj = %d\n", studentski_broj);
        printf("prosecna_ocena: %lf\n", blok[poz_u_baketu].prosecna_ocena);
        printf("adresa baketa: %d\n", baket_idx);
        printf("redni broj sloga u baketu: %d\n", poz_u_baketu);
        (baket_idx != probabilisticka_transformacija(studentski_broj)) ? printf("Dobijeni slog je prekoracilac.\n") : printf("\n");
        printf("------------------------------------------------------------\n");
    }
    else {
        printf("Greska: Slog sa datim studentski_broj = %d NE postoji!\n", studentski_broj);
    }
    fclose(fajl);
}

/// Prikaz studenata na osnovu broj_izlazaka

void prikaz_broj_izlazaka(const char* filename, int broj_izlazaka) {
    // Otvaranje fajlova
    FILE *fajl = fopen(filename, "rb");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename);
        return;
    }

    int bar_jedan_pronadjen = 0;
    agregirani_podaci blok[FAKTOR_BAKETIRANJA];
    int blok_broj = 0;

    // Prolazak kroz blokove
    while((int)fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl) == FAKTOR_BAKETIRANJA) {
        for (int i = 0; i < FAKTOR_BAKETIRANJA; i++) {
            if (blok[i].statusno_polje && blok[i].broj_izlazaka > broj_izlazaka) {
                printf("studentski_broj: %d\n", blok[i].studentski_broj);
                printf("ime_i_prezime: %s\n", blok[i].ime_i_prezime);
                printf("smer: %s\n", blok[i].smer);
                printf("broj_dosijea: %d\n", blok[i].broj_dosijea);
                printf("godina_upisa: %d\n", blok[i].godina_upisa);
                printf("godina_studija: %d\n", blok[i].godina_studija);
                printf("broj_polozenih_ispita: %d\n", blok[i].broj_polozenih_ispita);
                printf("broj_izlazaka: %d\n", blok[i].broj_izlazaka);
                printf("prosecna_ocena: %lf\n", blok[i].prosecna_ocena);
                printf("adresa baketa: %d\n", blok_broj);
                printf("redni broj sloga u baketu: %d\n", i);
                (blok_broj != probabilisticka_transformacija(blok[i].studentski_broj)) ? printf("Dobijeni slog je prekoracilac.\n\n") : printf("\n");
                bar_jedan_pronadjen = 1;
            }
        }
        blok_broj++;
    }

    if (!bar_jedan_pronadjen) {
        printf("Greska: Nije pronadjen nijedan student koji ispunjava kriterijum \"blok[i].broj_izlazaka > %d\".\n", broj_izlazaka);
    }

    fclose(fajl);
}

/// Logicko brisanje

int logicko_brisanje_agregirani_podaci(const char* filename, int studentski_broj) {
    // Otvaranje fajla
    FILE* fajl = fopen(filename, "rb+");
    if (!fajl) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename);
        return 1;
    }

    // Korak 1 - Pozivanje procesa trazenja
    int ind_usp_tr = 0, ind_psl = 0, baket_idx = 0, poz_u_baketu = 0;
    trazenje_sloga(fajl, studentski_broj, &ind_usp_tr, &ind_psl, &baket_idx, &poz_u_baketu);

    // Korak 2 - Provera rezultata trazenja
    if (!ind_usp_tr) {
        // Slog ne postoji!
        printf("Greska: Slog sa datim studentski_broj = %d NE postoji!\n", studentski_broj);
        fclose(fajl);
        return 1;  // Neuspesno
    }

    // Korak 3 - Oznaciti slog kao logicki obrisan
    int pozicija = baket_idx * FAKTOR_BAKETIRANJA * sizeof(agregirani_podaci);

    agregirani_podaci blok[FAKTOR_BAKETIRANJA];
    fseek(fajl, pozicija, SEEK_SET);
    fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);
    fseek(fajl, pozicija, SEEK_SET);

    blok[poz_u_baketu].statusno_polje = 0;

    // Korak 4 - Upis sloga u datoteku
    fwrite(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);

    // Korak 5 - Provera da li je uspesno logicki obrisan slog
    fseek(fajl, pozicija, SEEK_SET);
    fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);
    if (!blok[poz_u_baketu].statusno_polje) {
        printf("Uspesno je logicki obrisan slog koji ima studentski_broj = %d.\n", studentski_broj);
        fclose(fajl);
        return 1;
    }
    else {
        printf("Greska: Prilikom logickog brisanja sloga koji ima studentski_broj = %d, je doslo do greske.\n", studentski_broj);
        fclose(fajl);
        return 0;
    }
}

/// Propagiranje unosa studenta ka rasutoj datoteci

int unos_na_osnovu_studenta(const char* filename, const char* filename_polaganja_ispita, student novi_student) {
    // Otvaranje fajlova
    FILE* fajl = fopen(filename, "rb+");
    if (!fajl) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename);
        return 1;
    }

    FILE* fajl_polaganja_ispita = fopen(filename_polaganja_ispita, "rb");
    if (!fajl_polaganja_ispita) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename_polaganja_ispita);
        return 1;
    }

    agregirani_podaci novi_podatak = {0};
    novi_podatak.studentski_broj = novi_student.studentski_broj;
    strcpy(novi_podatak.ime_i_prezime, novi_student.ime_i_prezime);
    strcpy(novi_podatak.smer, novi_student.smer);
    novi_podatak.broj_dosijea = novi_student.broj_dosijea;
    novi_podatak.godina_upisa = novi_student.godina_upisa;
    novi_podatak.godina_studija = novi_student.godina_studija;

    int broj_izlazaka = 0, broj_polozenih_ispita = 0, suma_ocena = 0;
    polaganje_ispita blok[FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA];
    while((int)fread(blok, sizeof(polaganje_ispita), FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA, fajl_polaganja_ispita) == FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA; i++) {
            if (blok[i].studentski_broj == novi_podatak.studentski_broj) {
                broj_izlazaka++;
                if (blok[i].ocena > 5) {
                    suma_ocena += blok[i].ocena;
                    broj_polozenih_ispita++;
                }
            }
        }
    }
    fclose(fajl_polaganja_ispita);

    novi_podatak.broj_polozenih_ispita = broj_polozenih_ispita;
    novi_podatak.broj_izlazaka = broj_izlazaka;
    novi_podatak.prosecna_ocena = (broj_polozenih_ispita > 0) ? round(((double)suma_ocena / broj_polozenih_ispita) * 100) / 100 : 0;
    novi_podatak.statusno_polje = 1;

    // Korak 1 - Pozivanje procesa trazenja
    int ind_usp_tr = 0, ind_psl = 0, baket_idx = 0, poz_u_baketu = 0;
    trazenje_sloga(fajl, novi_podatak.studentski_broj, &ind_usp_tr, &ind_psl, &baket_idx, &poz_u_baketu);

    // Korak 2 - Provera rezultata trazenja
    if (ind_usp_tr) {
        // Slog vec postoji!
        printf("Greska - Staticka rasuta datoteka: Slog sa datim studentski_broj = %d vec postoji!\n", novi_podatak.studentski_broj);
        fclose(fajl);
        return 1;  // Neuspesno
    }
    if (!ind_psl) {
        // Nema slobodnih lokacija u datoteci
        printf("Greska: Staticka rasuta datoteka je puna!\n");
        fclose(fajl);
        return 1;  // Neuspesno
    }

    // Korak 3 - Nastavak upisa
    // Dodajemo slog:
    // ako je trazenje neuspesno -> ind_usp_tr == 0,
    // ako postoje slobodne lokacije -> ind_psl == 1.
    upisi_slog(fajl, baket_idx, poz_u_baketu, &novi_podatak);

    printf("Uspesno dodat slog.\n");
    fclose(fajl);
    return 0;
}

/// Propagiranje modifikacije studenta ka rasutoj datoteci

int modifikacija_na_osnovu_studenta(const char* filename, student novi_student) {
    // Otvaranje fajlova
    FILE* fajl = fopen(filename, "rb+");
    if (!fajl) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename);
        return 1;
    }

    // Korak 1 - Pozivanje procesa trazenja
    int ind_usp_tr = 0, ind_psl = 0, baket_idx = 0, poz_u_baketu = 0;
    trazenje_sloga(fajl, novi_student.studentski_broj, &ind_usp_tr, &ind_psl, &baket_idx, &poz_u_baketu);

    // Korak 2 - Provera rezultata trazenja
    if (!ind_usp_tr) {
        // Slog NE postoji!
        printf("Greska - Staticka rasuta datoteka: Slog sa datim studentski_broj = %d NE postoji!\n", novi_student.studentski_broj);
        fclose(fajl);
        return 1;  // Neuspesno
    }

    // Korak 3 - Ucitavanje bloka sa odgovarajucim podacima
    int pozicija = baket_idx * FAKTOR_BAKETIRANJA * sizeof(agregirani_podaci);

    agregirani_podaci blok[FAKTOR_BAKETIRANJA];
    fseek(fajl, pozicija, SEEK_SET);
    fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);
    fseek(fajl, pozicija, SEEK_SET);

    // Korak 4 - Menjanje podataka
    strcpy(blok[poz_u_baketu].ime_i_prezime, novi_student.ime_i_prezime);
    strcpy(blok[poz_u_baketu].smer, novi_student.smer);
    blok[poz_u_baketu].broj_dosijea = novi_student.broj_dosijea;
    blok[poz_u_baketu].godina_upisa = novi_student.godina_upisa;
    blok[poz_u_baketu].godina_studija = novi_student.godina_studija;

    // Korak 5 - Upis bloka sa slogom
    fwrite(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);

    printf("Uspesno izmenjen slog.\n");
    fclose(fajl);
    return 0;
}

/// Propagiranje unosa polaganja_ispita ka rasutoj datoteci

int modifikacija_na_osnovu_polaganja_ispita(const char* filename_agregirani_podaci, const char* filename_student, const char* filename_polaganje_ispita, polaganje_ispita novo_polaganje_ispita) {
    // Otvaranje fajlova
    FILE* fajl = fopen(filename_agregirani_podaci, "rb+");
    if (!fajl) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename_agregirani_podaci);
        return 1;
    }

    // Korak 1 - Pozivanje procesa trazenja u rasutoj datoteci
    int ind_usp_tr = 0, ind_psl = 0, baket_idx = 0, poz_u_baketu = 0;
    trazenje_sloga(fajl, novo_polaganje_ispita.studentski_broj, &ind_usp_tr, &ind_psl, &baket_idx, &poz_u_baketu);

    if (!ind_psl) {
        printf("Greska - Staticka datoteka: Staticka datoteka je \"%s\" puna!\n", filename_agregirani_podaci);
        fclose(fajl);
        return 1;
    }

    // Korak 2 - Provera rezultata trazenja u rasutoj datoteci
    if (!ind_usp_tr) {
        // Slog NE postoji u statickoj!
        // Ako ne postoji, potrebno je to evidentirati u log datoteci
        char opis_greske[MAX_OPIS_GRESKE];
        snprintf(opis_greske, sizeof(opis_greske), "Student NE postoji u rasutoj, studentski_broj = %d!", novo_polaganje_ispita.studentski_broj);
        printf("%s\n", opis_greske);
        unos_log_greska(UNETI_STUDENT_NIJE_UNET_U_STATICKU, opis_greske);

        // Korak 3 - Treba proveriti da li se student sa datim identifikatorom nalazi u studentskoj datoteci
        // Ako je odgovor ne -> potrebno je to evidentirati u log datoteci i zavrsiti unos
        if (!postoji_student(filename_student, novo_polaganje_ispita.studentski_broj)) {
            char opis_greske[MAX_OPIS_GRESKE];
            snprintf(opis_greske, sizeof(opis_greske), "Student NE postoji u sistemu, studentski_broj = %d!", novo_polaganje_ispita.studentski_broj);
            printf("%s\n", opis_greske);
            unos_log_greska(UNETI_STUDENT_NIJE_UNET_UOPSTE, opis_greske);
            return 1;
        }

        // Ako je odgovor da -> potrebno je pripremiti slog za upis u rasutu datoteku

        agregirani_podaci novi_agregirani_podatak = {0};

        FILE* student_fajl = fopen(filename_student, "rb");
        if (student_fajl == NULL) {
            printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename_student);
            return 0;
        }
        student blok[FAKTOR_BLOKIRANJA_STUDENT];
        // Prolazak kroz blokove
        while((int)fread(blok, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, student_fajl) == FAKTOR_BLOKIRANJA_STUDENT) {
            for (int i = 0; i < FAKTOR_BLOKIRANJA_STUDENT; i++) {
                // Provera postojanja studenta na osnovu studentski_broj
                if (blok[i].studentski_broj == novo_polaganje_ispita.studentski_broj) {
                    novi_agregirani_podatak.studentski_broj = blok[i].studentski_broj;
                    strcpy(novi_agregirani_podatak.ime_i_prezime, blok[i].ime_i_prezime);
                    strcpy(novi_agregirani_podatak.smer, blok[i].smer);
                    novi_agregirani_podatak.broj_dosijea = blok[i].broj_dosijea;
                    novi_agregirani_podatak.godina_upisa = blok[i].godina_upisa;
                    novi_agregirani_podatak.godina_studija = blok[i].godina_studija;
                    novi_agregirani_podatak.broj_polozenih_ispita = 0;
                    novi_agregirani_podatak.broj_izlazaka = 0;
                    novi_agregirani_podatak.prosecna_ocena = 0;
                    novi_agregirani_podatak.statusno_polje = 1;
                    fclose(student_fajl);
                }
            }
        }

        printf("Student je uspesno upisan na osnovu serijske datoteke!\n");
        upisi_slog(fajl, baket_idx, poz_u_baketu, &novi_agregirani_podatak);
    }

    // Korak 3 - Ucitavanje bloka sa odgovarajucim podacima
    // Ako slog postoji u rasutoj ili ako ne postoji u rasutoj ali je unet iz studentske!
    // U sustini, student se sad sigurno nalazi u rasutoj -> ponovo ga trazimo
    trazenje_sloga(fajl, novo_polaganje_ispita.studentski_broj, &ind_usp_tr, &ind_psl, &baket_idx, &poz_u_baketu);
    int pozicija = baket_idx * FAKTOR_BAKETIRANJA * sizeof(agregirani_podaci);
    agregirani_podaci blok[FAKTOR_BAKETIRANJA];
    fseek(fajl, pozicija, SEEK_SET);
    fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);
    fseek(fajl, pozicija, SEEK_SET);

    // Korak 4 - Racunanje novog proseka
    FILE* file_polaganje_ispita = fopen(filename_polaganje_ispita, "rb");
    if (file_polaganje_ispita == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename_polaganje_ispita);
        return 1;
    }
    polaganje_ispita blok_polaganje_ispita[FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA];
    int broj_izlazaka = 0, broj_polozenih_ispita = 0, suma_ocena = 0;
    while ((int)fread(blok_polaganje_ispita, sizeof(polaganje_ispita), FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA, file_polaganje_ispita) == FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA) {
        for (int j = 0; j < FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA; j++) {
            if (blok_polaganje_ispita[j].studentski_broj == novo_polaganje_ispita.studentski_broj) {
                broj_izlazaka++;
                if (blok_polaganje_ispita[j].ocena > 5) {
                    suma_ocena += blok_polaganje_ispita[j].ocena;
                    broj_polozenih_ispita++;
                }
            }
        }
    }
    fclose(file_polaganje_ispita);
    blok[poz_u_baketu].broj_izlazaka = broj_izlazaka;
    blok[poz_u_baketu].broj_polozenih_ispita = broj_polozenih_ispita;
    blok[poz_u_baketu].prosecna_ocena = (broj_polozenih_ispita > 0) ? round(((double)suma_ocena / broj_polozenih_ispita) * 100) / 100 : 0;

    // Korak 5 - Cuvanje modifikovanih podataka u staticku datoteku
    fwrite(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, fajl);

    printf("Uspesno izmenjen slog na osnovu polaganja_ispita.\n");
    fclose(fajl);
    return 0;
}

/// Ispis agregirani_podaci

void ispis_agregirani_podaci(const char* aktivni_agregirani_podaci_fajl) {
    // Otvaranje fajla
    FILE *agregirani_podaci_fajl = fopen(aktivni_agregirani_podaci_fajl, "rb");
    if (agregirani_podaci_fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", aktivni_agregirani_podaci_fajl);
        return;
    }

    agregirani_podaci blok[FAKTOR_BAKETIRANJA];

    int blok_broj = 0;
    // Prolazak kroz blokove
    while((int)fread(blok, sizeof(agregirani_podaci), FAKTOR_BAKETIRANJA, agregirani_podaci_fajl) == FAKTOR_BAKETIRANJA) {
        printf("--- BLOK %d ---\n", blok_broj);
        for (int i = 0; i < FAKTOR_BAKETIRANJA; i++) {
            printf("%d: %d %s %s %d %d %d %d %d %.2lf %d\n", blok[i].statusno_polje, blok[i].studentski_broj, blok[i].ime_i_prezime, blok[i].smer,
                blok[i].broj_dosijea, blok[i].godina_upisa, blok[i].godina_studija, blok[i].broj_polozenih_ispita,
                blok[i].broj_izlazaka, blok[i].prosecna_ocena, i);
        }
        blok_broj++;
        printf("---------------\n");
    }

    fclose(agregirani_podaci_fajl);
}
