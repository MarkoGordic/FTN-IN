#include "student.h"

/// Formiranje prazne serijske datoteke

void kreiraj_praznu_serijsku_student_datoteku(const char* filename) {
    FILE *fajl = fopen(filename, "wb");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom kreiranja datoteke \"%s\"!\n", filename);
        return;
    }

    // Kreiranje prvog bloka i specijalnog poslednjeg sloga
    student blok[FAKTOR_BLOKIRANJA_STUDENT] = {0};
    blok[0].studentski_broj = -1;
    fwrite(blok, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, fajl);
    fclose(fajl);
    printf("Uspesno kreirana datoteka \"%s\" sa EOF markerom na prvoj poziciji!\n", filename);
}

/// Unos studenta

void unos_studenta(const char* filename, const char* filename_polaganje_ispita, const char* filename_agregirani_podaci) {
    // Kreiranje novog studenta
    student novi_student;
    printf("Unesite studentski_broj: "); scanf("%d", &novi_student.studentski_broj); ocisti_bafer();

    printf("Unesite ime_i_prezime (do 50 karaktera): ");
    fgets(novi_student.ime_i_prezime, MAX_IME_I_PREZIME, stdin);
    novi_student.ime_i_prezime[strcspn(novi_student.ime_i_prezime, "\n")] = 0;
    if (!provera_ascii(novi_student.ime_i_prezime)) {
        printf("Greska: ime_i_prezime sme da sadrzi samo ASCII karaktere.\n");
        return;
    }

    printf("Unesite smer (do 4 karaktera): ");
    fgets(novi_student.smer, MAX_SMER, stdin);
    novi_student.smer[strcspn(novi_student.smer, "\n")] = 0;
    if (!provera_ascii(novi_student.smer)) {
        printf("Greska: smer sme da sadrzi samo ASCII karaktere.\n");
        return;
    }

    printf("Unesite broj_dosijea: "); scanf("%d", &novi_student.broj_dosijea); ocisti_bafer();

    printf("Unesite godina_upisa (4 cifre): "); scanf("%d", &novi_student.godina_upisa); ocisti_bafer();
    if (novi_student.godina_upisa < 0 || novi_student.godina_upisa > 9999) {
        printf("Greska: godina_upisa mora da ima tacno 4 cifre.\n");
        return;
    }

    printf("Unesite godina_studija (1 cifra): "); scanf("%d", &novi_student.godina_studija); ocisti_bafer();
    if (novi_student.godina_studija < 0 || novi_student.godina_studija > 9) {
        printf("Greska: godina_studija mora da ima tacno 1 cifru.\n");
        return;
    }

    // Otvaranje fajla
    FILE *fajl = fopen(filename, "rb+");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename);
        return;
    }

    student blok[FAKTOR_BLOKIRANJA_STUDENT];
    int pozicija_bloka = 0;
    int blok_broj = 0;
    // Prolazak kroz blokove
    while((int)fread(blok, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, fajl) == FAKTOR_BLOKIRANJA_STUDENT) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_STUDENT; i++) {
            // Provera duplikata
            if (blok[i].studentski_broj == novi_student.studentski_broj) {
                printf("Student sa datim studentskim_brojem = %d vec postoji.\n", novi_student.studentski_broj);
                fclose(fajl);
                return;
            }

            // Provera krajnjeg sloga
            if (blok[i].studentski_broj == -1) {
                // Upis novog sloga
                blok[i] = novi_student;
                // Upis krajnjeg sloga
                if (i < FAKTOR_BLOKIRANJA_STUDENT - 1) {
                    blok[i+1].studentski_broj = -1;
                }
                // Upis bloka
                fseek(fajl, pozicija_bloka, SEEK_SET);
                fwrite(blok, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, fajl);
                // U slucaju da je krajnji slog fajla bio poslednji u bloku
                if (i == FAKTOR_BLOKIRANJA_STUDENT - 1) {
                    student novi_blok[FAKTOR_BLOKIRANJA_STUDENT] = {0};
                    novi_blok[0].studentski_broj = -1;
                    fwrite(novi_blok, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, fajl);
                }
                printf("Student je uspesno upisan\nBlok: %d, Pozicija unutar bloka: %d\n", blok_broj, i);

                // Propagiranje unosa u staticku datoteku
                fclose(fajl);
                if(unos_na_osnovu_studenta(filename_agregirani_podaci, filename_polaganje_ispita, novi_student)) {
                    // RAD SA LOG DATOTEKOM U SLUCAJU NEUSPEHA
                    char opis_greske[MAX_OPIS_GRESKE];
                    snprintf(opis_greske, sizeof(opis_greske), "Student vec postoji u rasutoj, studentski_broj = %d!", novi_student.studentski_broj);
                    printf("%s\n", opis_greske);
                    unos_log_greska(UNETI_STUDENT_VEC_POSTOJI_U_STATICKOJ, opis_greske);
                }
                return;
            }
        }
        pozicija_bloka += FAKTOR_BLOKIRANJA_STUDENT * sizeof(student);
        blok_broj++;
    }

    printf("Greska: nije pronadjen krajnji slog datoteke ili nije moguce upisati slog.\n");
    fclose(fajl);
}

/// Prikaz trazenih informacija za studenta na osnovu studentski_broj

void prikazi_podatke_za_studentski_broj(const char* filename, int studentski_broj) {
    // Otvaranje fajla
    FILE *fajl = fopen(filename, "rb");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename);
        return;
    }

    student blok[FAKTOR_BLOKIRANJA_STUDENT];
    int pozicija_bloka = 0;
    int blok_broj = 0;
    // Prolazak kroz blokove
    while((int)fread(blok, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, fajl) == FAKTOR_BLOKIRANJA_STUDENT) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_STUDENT; i++) {
            // Provera krajnjeg sloga
            if (blok[i].studentski_broj == -1) {
                printf("Greska: ne postoji slog za dati studentski_broj = %d.\n", studentski_broj);
                fclose(fajl);
                return;
            }

            // Provera da li trenutni slog ima isti studentski_broj kao uneti studentski_broj
            if (blok[i].studentski_broj == studentski_broj) {
                printf("------------------------------------------------------------\n");
                printf("Informacije o studentu za dati studentski_broj = %d.\n", studentski_broj);
                printf("Godina studija: %d\n", blok[i].godina_studija);
                printf("Godina upisa: %d\n", blok[i].godina_upisa);
                printf("Adresa bloka: %d\n", blok_broj);
                printf("Redni broj sloga u bloku: %d\n", i);
                printf("------------------------------------------------------------\n");
                fclose(fajl);
                return;
            }
        }
        pozicija_bloka += FAKTOR_BLOKIRANJA_STUDENT * sizeof(student);
        blok_broj++;
    }

    printf("Greska: nije pronadjen krajnji slog datoteke ili nije moguce upisati slog.\n");
    fclose(fajl);
}

void uslov_studenti(const char* aktivni_student_fajl, const char* aktivni_polaganje_ispita_fajl) {
    // Otvaranje fajlova
    FILE *student_fajl = fopen(aktivni_student_fajl, "rb");
    if (student_fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", aktivni_student_fajl);
        return;
    }

    FILE *polaganje_ispita_fajl = fopen(aktivni_polaganje_ispita_fajl, "rb");
    if (polaganje_ispita_fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", aktivni_polaganje_ispita_fajl);
        return;
    }

    student blok_studenti[FAKTOR_BLOKIRANJA_STUDENT];
    polaganje_ispita blok_polaganje_ispita[FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA];

    int pozicija_bloka = 0;
    int blok_broj = 0;
    int pronadjeno_studenata = 0;
    // Prolazak kroz blokove
    while((int)fread(blok_studenti, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, student_fajl) == FAKTOR_BLOKIRANJA_STUDENT) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_STUDENT; i++) {
            // Provera krajnjeg sloga
            if (blok_studenti[i].studentski_broj == -1) {
                if (!pronadjeno_studenata)
                    printf("Info: Nijedan student nema ostvarene sve 10ke i da je u cetvrtoj godini.\n");

                fclose(student_fajl);
                fclose(polaganje_ispita_fajl);
                return;
            }

            // Provera godina_studija da je 4. godina
            if (blok_studenti[i].godina_studija == 4) {
                // Provera ocena u datoteci polaganje_ispita
                int pojavljuje_se_student = 0;  // koristimo da vidimo da li se pojavljuje uopste sa ocenama
                int ima_sve_10 = 1;             // smatramo da student ima sve 10

                // Prolazak kroz datoteku polaganje_ispita
                while ((int)fread(blok_polaganje_ispita, sizeof(polaganje_ispita), FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA, polaganje_ispita_fajl) == FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA) {
                    for (int j = 0; j < FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA; j++) {

                        if (blok_polaganje_ispita[j].studentski_broj == blok_studenti[i].studentski_broj) {
                            // Zapisujemo da se student pojavljuje da ima polozene ispite
                            pojavljuje_se_student = 1;

                            // Zapisujemo da student nema sve 10 iz polozenih ispita
                            if (blok_polaganje_ispita[j].ocena != 10)
                                ima_sve_10 = 0;
                        }

                    }
                }

                if (pojavljuje_se_student && ima_sve_10) {
                    printf("------------------------------------------------------------\n");
                    printf("Informacije o studentu: \n");
                    printf("studentski_broj: %d\n", blok_studenti[i].studentski_broj);
                    printf("ime_i_prezime: %s\n", blok_studenti[i].ime_i_prezime);
                    printf("smer: %s\n", blok_studenti[i].smer);
                    printf("broj_dosijea: %d\n", blok_studenti[i].broj_dosijea);
                    printf("godina_upisa: %d\n", blok_studenti[i].godina_upisa);
                    printf("godina_studija: %d\n", blok_studenti[i].godina_studija);

                    printf("Adresa bloka: %d\n", blok_broj);
                    printf("Redni broj sloga u bloku: %d\n", i);
                    printf("------------------------------------------------------------\n");
                    pronadjeno_studenata++;
                }
            }
        }

        pozicija_bloka += FAKTOR_BLOKIRANJA_STUDENT * sizeof(student);
        blok_broj++;
    }

    if (!pronadjeno_studenata)
        printf("Info: Nijedan student nema ostvarene sve 10ke i da je u cetvrtoj godini.\n");

    fclose(student_fajl);
    fclose(polaganje_ispita_fajl);
}

/// Modifikacija studenta

void izmeni_studenta(const char* filename, const char* filename_agregirani_podaci, int studentski_broj) {
    // Otvaranje fajla
    FILE *fajl = fopen(filename, "rb+");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename);
        return;
    }

    student blok[FAKTOR_BLOKIRANJA_STUDENT];
    int pozicija_bloka = 0;
    int blok_broj = 0;
    // Prolazak kroz blokove
    while((int)fread(blok, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, fajl) == FAKTOR_BLOKIRANJA_STUDENT) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_STUDENT; i++) {
            // Provera krajnjeg sloga
            if (blok[i].studentski_broj == -1) {
                printf("Greska: ne postoji slog za dati studentski_broj = %d.\n", studentski_broj);
                fclose(fajl);
                return;
            }

            // Provera da li trenutni slog ima isti studentski_broj kao uneti studentski_broj
            if (blok[i].studentski_broj == studentski_broj) {
                // Ispis trenutnih podataka
                printf("------------------------------------------------------------\n");
                printf("Trenutnu informacije o studentu: \n");
                printf("studentski_broj: %d\n", blok[i].studentski_broj);
                printf("ime_i_prezime: %s\n", blok[i].ime_i_prezime);
                printf("smer: %s\n", blok[i].smer);
                printf("broj_dosijea: %d\n", blok[i].broj_dosijea);
                printf("godina_upisa: %d\n", blok[i].godina_upisa);
                printf("godina_studija: %d\n", blok[i].godina_studija);
                printf("------------------------------------------------------------\n");

                printf("Unesite ime_i_prezime (do 50 karaktera): ");
                fgets(blok[i].ime_i_prezime, MAX_IME_I_PREZIME, stdin);
                blok[i].ime_i_prezime[strcspn(blok[i].ime_i_prezime, "\n")] = 0;
                if (!provera_ascii(blok[i].ime_i_prezime)) {
                    printf("Greska: ime_i_prezime sme da sadrzi samo ASCII karaktere.\n");
                    return;
                }

                printf("Unesite smer (do 4 karaktera): ");
                fgets(blok[i].smer, MAX_SMER, stdin);
                blok[i].smer[strcspn(blok[i].smer, "\n")] = 0;
                if (!provera_ascii(blok[i].smer)) {
                    printf("Greska: smer sme da sadrzi samo ASCII karaktere.\n");
                    return;
                }

                printf("Unesite broj_dosijea: "); scanf("%d", &blok[i].broj_dosijea); ocisti_bafer();

                printf("Unesite godina_upisa (4 cifre): "); scanf("%d", &blok[i].godina_upisa); ocisti_bafer();
                if (blok[i].godina_upisa < 0 || blok[i].godina_upisa > 9999) {
                    printf("Greska: godina_upisa mora da ima tacno 4 cifre.\n");
                    return;
                }

                printf("Unesite godina_studija (1 cifra): "); scanf("%d", &blok[i].godina_studija); ocisti_bafer();
                if (blok[i].godina_studija < 0 || blok[i].godina_studija > 9) {
                    printf("Greska: godina_studija mora da ima tacno 1 cifru.\n");
                    return;
                }

                fseek(fajl, pozicija_bloka, SEEK_SET);
                fwrite(blok, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, fajl);
                printf("Info: Podaci o studentu su uspesno izmenjeni.\n");

                if (modifikacija_na_osnovu_studenta(filename_agregirani_podaci, blok[i])) {
                    printf("Greska: Nije moguce propagirati modifikacije studenta u rasutu datoteku.\n");
                }

                fclose(fajl);
                return;
            }
        }
        pozicija_bloka += FAKTOR_BLOKIRANJA_STUDENT * sizeof(student);
        blok_broj++;
    }

    printf("Greska: nije pronadjen krajnji slog datoteke ili nije moguce azurirati slog.\n");
    fclose(fajl);
}

/// Korisceno za deo 3, zahtev 9, provera da li student postoji u serijskoj

int postoji_student(const char* filename, int studentski_broj) {
    // Otvaranje fajla
    FILE *fajl = fopen(filename, "rb");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename);
        return 0;
    }

    student blok[FAKTOR_BLOKIRANJA_STUDENT];
    // Prolazak kroz blokove
    while((int)fread(blok, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, fajl) == FAKTOR_BLOKIRANJA_STUDENT) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_STUDENT; i++) {
            // Provera postojanja studenta na osnovu studentski_broj
            if (blok[i].studentski_broj == studentski_broj) {
                fclose(fajl);
                return 1;
            }
        }
    }
    fclose(fajl);
    return 0;
}

/// Ispis student

void ispis_studenti(const char* aktivni_student_fajl) {
    // Otvaranje fajla
    FILE *student_fajl = fopen(aktivni_student_fajl, "rb");
    if (student_fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", aktivni_student_fajl);
        return;
    }

    student blok_studenti[FAKTOR_BLOKIRANJA_STUDENT];

    int pozicija_bloka = 0;
    int blok_broj = 0;
    // Prolazak kroz blokove
    while((int)fread(blok_studenti, sizeof(student), FAKTOR_BLOKIRANJA_STUDENT, student_fajl) == FAKTOR_BLOKIRANJA_STUDENT) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_STUDENT; i++) {
            // Provera krajnjeg sloga
            if (blok_studenti[i].studentski_broj == -1) {
                fclose(student_fajl);
                return;
            }

            printf("%d %s %s %d %d %d %d %d\n", blok_studenti[i].studentski_broj, blok_studenti[i].ime_i_prezime, blok_studenti[i].smer, blok_studenti[i].broj_dosijea, blok_studenti[i].godina_upisa, blok_studenti[i].godina_studija, blok_broj, i);
        }
        pozicija_bloka += FAKTOR_BLOKIRANJA_STUDENT * sizeof(student);
        blok_broj++;
    }

    fclose(student_fajl);
}
