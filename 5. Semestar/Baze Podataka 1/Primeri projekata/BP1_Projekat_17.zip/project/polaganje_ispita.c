#include "polaganje_ispita.h"

/// Formiranje prazne serijske datoteke

void kreiraj_praznu_serijsku_polaganje_ispita_datoteku(const char* filename) {
    FILE *fajl = fopen(filename, "wb");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom kreiranja datoteke \"%s\"!\n", filename);
        return;
    }

    polaganje_ispita blok[FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA] = {0};
    blok[0].identifikator = -1;
    fwrite(blok, sizeof(polaganje_ispita), FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA, fajl);
    fclose(fajl);
    printf("Uspesno kreirana datoteka \"%s\" sa EOF markerom na prvoj poziciji!\n", filename);
}

/// Unos polaganje_ispita

void unos_polaganja_ispita(const char* filename_polaganje_ispita, const char* filename_student, const char* filename_agregirani_podaci) {
    /// u ovoj funkciji ce se dodati nesto za Deo 3, 3.

    // Kreiranje novog polaganja_ispita
    polaganje_ispita novo_polaganje_ispita;
    printf("Unesite identifikator: "); scanf("%d", &novo_polaganje_ispita.identifikator); ocisti_bafer();

    printf("Unesite studentski_broj: "); scanf("%d", &novo_polaganje_ispita.studentski_broj); ocisti_bafer();

    printf("Unesite naziv_predmeta (do 30 karaktera): ");
    fgets(novo_polaganje_ispita.naziv_predmeta, MAX_NAZIV_PREDMETA, stdin);
    novo_polaganje_ispita.naziv_predmeta[strcspn(novo_polaganje_ispita.naziv_predmeta, "\n")] = 0;
    if (!provera_ascii(novo_polaganje_ispita.naziv_predmeta)) {
        printf("Greska: naziv_predmeta sme da sadrzi samo ASCII karaktere.\n");
        return;
    }

    printf("Unesite ocenu (5 - 10): "); scanf("%d", &novo_polaganje_ispita.ocena); ocisti_bafer();
    if (novo_polaganje_ispita.ocena < 5 || novo_polaganje_ispita.ocena > 10) {
        printf("Greska: ocena mora da bude iz opsega [5, 10].\n");
        return;
    }

    printf("Unesite broj_predispitnih_poena: "); scanf("%d", &novo_polaganje_ispita.broj_predispitnih_poena); ocisti_bafer();

    printf("Unesite broj_ispitnih_poena: "); scanf("%d", &novo_polaganje_ispita.broj_ispitnih_poena); ocisti_bafer();

    // Otvaranje fajla
    FILE *fajl = fopen(filename_polaganje_ispita, "rb+");
    if (fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", filename_polaganje_ispita);
        return;
    }

    polaganje_ispita blok[FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA];
    int pozicija_bloka = 0;
    int blok_broj = 0;
    // Prolazak kroz blokove
    while ((int)fread(blok, sizeof(polaganje_ispita), FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA, fajl) == FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA; i++) {
            // Provera duplikata
            if (blok[i].identifikator == novo_polaganje_ispita.identifikator) {
                printf("Polaganje ispita sa datim identifikatorom = %d vec postoji.\n", novo_polaganje_ispita.identifikator);
                fclose(fajl);
                return;
            }

            // Provera krajnjeg sloga
            if (blok[i].identifikator == -1) {
                // Upis novog sloga
                blok[i] = novo_polaganje_ispita;
                // Upis krajnjeg sloga
                if (i < FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA - 1) {
                    blok[i+1].identifikator = -1;
                }
                // Upis bloka
                fseek(fajl, pozicija_bloka, SEEK_SET);
                fwrite(blok, sizeof(polaganje_ispita), FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA, fajl);
                // U slucaju da je kranji slog fajla bio poslednji u bloku
                if (i == FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA - 1) {
                    polaganje_ispita novi_blok[FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA] = {0};
                    novi_blok[0].identifikator = -1;
                    fwrite(novi_blok, sizeof(polaganje_ispita), FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA, fajl);
                }
                printf("Polaganje ispita je uspesno upisano\nBlok: %d, Pozicija unutar bloka: %d\n", blok_broj, i);

                // Propagiranje unosa u staticku datoteku
                fclose(fajl);
                modifikacija_na_osnovu_polaganja_ispita(filename_agregirani_podaci, filename_student, filename_polaganje_ispita, novo_polaganje_ispita);
                return;
            }
        }
        pozicija_bloka += FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA * sizeof(polaganje_ispita);
        blok_broj++;
    }

    printf("Greska: nije pronadjen krajnji slog datoteke ili nije moguce upisati slog.\n");
    fclose(fajl);
}

/// Ispis polaganje_ispita

void ispis_polaganje_ispita(const char* aktivni_polaganje_ispita_fajl) {
    // Otvaranje fajla
    FILE *polaganje_ispita_fajl = fopen(aktivni_polaganje_ispita_fajl, "rb");
    if (polaganje_ispita_fajl == NULL) {
        printf("Doslo je do greske prilikom otvaranja datoteke \"%s\"!\n", aktivni_polaganje_ispita_fajl);
        return;
    }

    polaganje_ispita blok[FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA];

    int pozicija_bloka = 0;
    int blok_broj = 0;
    // Prolazak kroz blokove
    while((int)fread(blok, sizeof(polaganje_ispita), FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA, polaganje_ispita_fajl) == FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA) {
        for (int i = 0; i < FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA; i++) {
            // Provera krajnjeg sloga
            if (blok[i].identifikator == -1) {
                fclose(polaganje_ispita_fajl);
                return;
            }

            printf("%d %d %s %d %d %d %d %d\n", blok[i].identifikator, blok[i].studentski_broj, blok[i].naziv_predmeta, blok[i].ocena, blok[i].broj_predispitnih_poena, blok[i].broj_ispitnih_poena, blok_broj, i);
        }
        pozicija_bloka += FAKTOR_BLOKIRANJA_POLAGANJE_ISPITA * sizeof(student);
        blok_broj++;
    }

    fclose(polaganje_ispita_fajl);
}
