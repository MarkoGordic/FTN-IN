package demo.beans;

public class ElektricniUredjaj extends Proizvod {

  private int snaga; // u W
  private int radniNapon; // u V

  public ElektricniUredjaj() {
    super();
    this.snaga = 0;
    this.radniNapon = 230;
  }

  public ElektricniUredjaj(int id, String naziv, String opis, int potrosnja, int napon) {
    super(id, naziv, opis);
    this.snaga = potrosnja;
    this.radniNapon = napon;
  }

  public int getSnaga() {
    return snaga;
  }

  public void setSnaga(int snaga) {
    this.snaga = snaga;
  } 

  public int getRadniNapon() {
    return radniNapon;
  } 

  public void setRadniNapon(int radniNapon) {
    this.radniNapon = radniNapon ;
  }

  @Override
  public String toString() {
    return super.toString() + " | snaga: " + snaga + " W, radni napon: " + radniNapon + " V";
  } 
  
}
