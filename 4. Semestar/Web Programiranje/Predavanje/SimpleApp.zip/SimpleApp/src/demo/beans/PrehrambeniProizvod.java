package demo.beans;

public class PrehrambeniProizvod extends Proizvod {

	private boolean istekaoRokTrajanja;

	
	public PrehrambeniProizvod() {
    super();
		istekaoRokTrajanja = false;
	}

	public PrehrambeniProizvod(int id, String naziv, String opis, boolean istekao) {
		super(id, naziv, opis);
		this.istekaoRokTrajanja=istekao;
	}

	public boolean isIstekaoRokTrajanja() {
		return istekaoRokTrajanja;
	}

	public void setIstekaoRokTrajanja(boolean istekaoRokTrajanja) {
		this.istekaoRokTrajanja = istekaoRokTrajanja;
	}
	
	public String toString() {
		return super.toString()+" istekao: "+istekaoRokTrajanja;
	}

}
