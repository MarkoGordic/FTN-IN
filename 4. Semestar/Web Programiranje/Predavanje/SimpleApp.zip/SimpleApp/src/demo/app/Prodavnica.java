package demo.app;

import java.util.ArrayList;
import java.util.List;

import demo.beans.ElektricniUredjaj;
import demo.beans.PrehrambeniProizvod;
import demo.beans.Proizvod;

public class Prodavnica {
	
	private String nazivProd;
	private List<Proizvod> proizvodi;

	public Prodavnica() {
		// TODO Auto-generated constructor stub
		this.nazivProd="Moja prodavnica";
		this.proizvodi=new ArrayList<Proizvod>();
	}
	
	

	public Prodavnica(String nazivProd) {
		super();
		this.nazivProd = nazivProd;
		this.proizvodi=new ArrayList<Proizvod>();
	}



	public String getNazivProd() {
		return nazivProd;
	}

	public void setNazivProd(String nazivProd) {
		this.nazivProd = nazivProd;
	}

	public List<Proizvod> getProizvodi() {
		return proizvodi;
	}

	public void setProizvodi(List<Proizvod> proizvodi) {
		this.proizvodi = proizvodi;
	}
	
	public void printProizvoda() {
    System.out.println("\n>>>>>> Proizvodi u prodavnici: " + this.nazivProd);
		for(Proizvod p : this.proizvodi) {
			System.out.println(p.toString());
		}
    System.out.println("<<<<<<<<<<<<<<<<<<\n");
	}
	
	public void dodajProizvod(Proizvod p) {
		this.proizvodi.add(p);
	}

	public static void main(String args[]) {
		Proizvod p1 = new Proizvod(1,"Nivea Dezodorans","nivea Men Fresh 200 ml");
    Proizvod p2 = new Proizvod(2,"Strip Alan Ford","epizoda 245");

    Prodavnica thisApp = new Prodavnica("Prva prodavnica");
		
		thisApp.dodajProizvod(p1);
    thisApp.dodajProizvod(p2);
		thisApp.dodajProizvod(new PrehrambeniProizvod(3,"Jaffa keks","pakovanje 200 g",false));
		
		thisApp.printProizvoda();

    thisApp.dodajProizvod(new ElektricniUredjaj(4, "Fen za kosu", "Fen za kosu 2000 W", 2000, 230));
    thisApp.dodajProizvod(new ElektricniUredjaj(5, "Usisivač", "Usisivač 1500 W", 1500, 230));

    thisApp.printProizvoda();
	}
}
