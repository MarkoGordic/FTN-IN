package rs.ac.uns.ftn.wpii.wpstarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WpstarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
