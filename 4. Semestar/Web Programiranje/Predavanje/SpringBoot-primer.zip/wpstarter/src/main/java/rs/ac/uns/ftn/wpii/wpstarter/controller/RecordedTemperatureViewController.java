package rs.ac.uns.ftn.wpii.wpstarter.controller;

import rs.ac.uns.ftn.wpii.wpstarter.model.RecordedTemperature;
import rs.ac.uns.ftn.wpii.wpstarter.service.RecordedTemperatureService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/temperatures")
public class RecordedTemperatureViewController {

    @Autowired
    private RecordedTemperatureService temperatureService;

    @GetMapping
    public String getAllTemperatures(Model model, @RequestParam(required = false, defaultValue = "K") String scale) {
        // System.out.println("Getting all temperatures")
        List<RecordedTemperature> temperatures = temperatureService.getAllTemperatures(scale);
        model.addAttribute("temperatures", temperatures);
        model.addAttribute("scale", scale);
        return "temperature-list";
    }

    @GetMapping("/{date}")
    public String getTemperaturesByDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam(required = false, defaultValue = "K") String scale,
            Model model) {
        List<RecordedTemperature> temperatures = temperatureService.getTemperaturesByDate(date, scale);
        model.addAttribute("temperatures", temperatures);
        model.addAttribute("date", date);
        model.addAttribute("scale", scale != null ? scale : "K");
        return "temperature-list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("temperatureRecording", new RecordedTemperature());
        return "temperature-form";
    }

    @PostMapping("/save")
    public String saveTemperatureRecording(
        @RequestParam("temperature") double value,
        @RequestParam("scale") String scale
    ) {
        temperatureService.saveTemperature(value, scale);
        return "redirect:/temperatures?scale=" + scale;
    }
}
