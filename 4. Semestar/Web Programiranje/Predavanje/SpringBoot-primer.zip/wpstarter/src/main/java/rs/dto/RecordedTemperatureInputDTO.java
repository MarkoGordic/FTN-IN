package rs.dto;

public class RecordedTemperatureInputDTO {

    private double temperature;
    private String scale;

    public RecordedTemperatureInputDTO() {
      temperature = 0;
    }

    public RecordedTemperatureInputDTO(double temperature, String scale) {
        this.temperature = temperature;
        this.scale = scale;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public String getScale() {
        return scale;
    }

    public void setScale(String scale) {
        this.scale = scale;
    }
}
