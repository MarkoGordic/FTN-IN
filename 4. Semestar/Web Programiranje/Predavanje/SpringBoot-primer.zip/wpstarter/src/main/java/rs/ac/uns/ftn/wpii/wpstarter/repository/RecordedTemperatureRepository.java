package rs.ac.uns.ftn.wpii.wpstarter.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import rs.ac.uns.ftn.wpii.wpstarter.model.RecordedTemperature;

import java.time.LocalDateTime;


public interface RecordedTemperatureRepository extends JpaRepository<RecordedTemperature, Long> {
  List<RecordedTemperature> findAll();
  Optional<RecordedTemperature> findById(Long id);
  // ovo je ok ali bi bilo malo korisno jer bi morali uvek zadati i datetime
  List<RecordedTemperature> findByRecordingDateTimeOrderByRecordingDateTimeDesc(LocalDateTime recordingDateTime);
  //ovo je vec korisnije, jer vraca sva zapisana merenja temperature za neki datum, ali se mora pripremiti pre poziva
  List<RecordedTemperature> findByRecordingDateTimeBetweenOrderByRecordingDateTimeDesc(LocalDateTime startOfDay, LocalDateTime endOfDay);
  // The save method is inherited from JpaRepository, no need to redeclare it.
  void deleteById(Long id);
}
