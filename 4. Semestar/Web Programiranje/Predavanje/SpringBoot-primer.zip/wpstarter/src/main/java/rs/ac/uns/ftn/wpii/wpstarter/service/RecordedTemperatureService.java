package rs.ac.uns.ftn.wpii.wpstarter.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import rs.ac.uns.ftn.wpii.wpstarter.model.RecordedTemperature;
import rs.ac.uns.ftn.wpii.wpstarter.repository.RecordedTemperatureRepository;

@Service
public class RecordedTemperatureService {

    @Autowired
    private RecordedTemperatureRepository repository;

    public List<RecordedTemperature> getAllTemperatures(String scale) {

        if (scale == null) {
            scale = "K";
        }
        List<RecordedTemperature> temperatures = repository.findAll();
        if (scale.equals("C")) {
            temperatures.forEach(temp -> temp.setTemperature(convertKelvinToCelsius(temp.getTemperature())));
        } else if (scale.equals("F")) {
            temperatures.forEach(temp -> temp.setTemperature(convertKelvinToFahrenheit(temp.getTemperature())));
        }
        return temperatures;
    }

    public List<RecordedTemperature> getTemperaturesByDate(LocalDate date, String scale) {
        if (scale == null) {
            scale = "K";
        }
        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(LocalTime.MAX);
        List<RecordedTemperature> temperatures = repository.findByRecordingDateTimeBetweenOrderByRecordingDateTimeDesc(startOfDay, endOfDay);
        if (scale.equals("C")) {
            temperatures.forEach(temp -> temp.setTemperature(convertKelvinToCelsius(temp.getTemperature())));
        } else if (scale.equals("F")) {
            temperatures.forEach(temp -> temp.setTemperature(convertKelvinToFahrenheit(temp.getTemperature())));
        }
        return temperatures;
    }

    public RecordedTemperature saveTemperature(Double temperature, String scale) {
        Double kelvinTemp = convertToKelvin(temperature, scale);
        RecordedTemperature recordedTemp = new RecordedTemperature();
        recordedTemp.setTemperature(kelvinTemp);
        return repository.save(recordedTemp);
    }

    private Double convertToKelvin(Double temperature, String scale) {
        switch (scale.toUpperCase()) {
            case "C":
                return temperature + 273.15;
            case "F":
                return (temperature - 32) * 5/9 + 273.15;
            default:
                return temperature;
        }
    }

    private Double convertKelvinToCelsius(Double temperature) {
        // Assumes input temperature is in Kelvin
        return temperature - 273.15;
    }

    private Double convertKelvinToFahrenheit(Double temperature) {
        // Assumes input temperature is in Kelvin
        return (temperature - 273.15) * 9/5 + 32;
    }
}


