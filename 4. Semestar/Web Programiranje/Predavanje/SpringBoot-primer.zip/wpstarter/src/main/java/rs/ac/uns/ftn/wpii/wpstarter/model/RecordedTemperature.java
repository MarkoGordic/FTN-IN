package rs.ac.uns.ftn.wpii.wpstarter.model;

import jakarta.persistence.*;  // verzije SpringBoot 3+ i Java>17, za starije javax.persistance
import java.time.LocalDateTime;

@Entity
public class RecordedTemperature {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private LocalDateTime recordingDateTime;
  private double temperature;  // temperatura u Kelvinima

  public RecordedTemperature() {
    recordingDateTime = LocalDateTime.now();
    temperature = 0.0;  // Default to absolute zero
  }

  public RecordedTemperature(LocalDateTime recordingDateTime, double temperature) {
    this.recordingDateTime = recordingDateTime;
    this.temperature = temperature;
  }

  public LocalDateTime getRecordingDateTime() {
    return recordingDateTime;
  }

  public void setRecordingDateTime(LocalDateTime recordingDateTime) {
    this.recordingDateTime = recordingDateTime;
  }

  public double getTemperature() {
    return temperature;
  }

  public void setTemperature(double temperature) {
    this.temperature = temperature;
  }
}
