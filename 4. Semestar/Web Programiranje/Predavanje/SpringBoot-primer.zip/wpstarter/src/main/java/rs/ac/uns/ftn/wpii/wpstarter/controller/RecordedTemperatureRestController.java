package rs.ac.uns.ftn.wpii.wpstarter.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import rs.ac.uns.ftn.wpii.wpstarter.model.RecordedTemperature;
import rs.ac.uns.ftn.wpii.wpstarter.service.RecordedTemperatureService;
import rs.dto.RecordedTemperatureInputDTO;

@RestController
@RequestMapping("/api/temperatures")
public class RecordedTemperatureRestController {

    @Autowired
    private RecordedTemperatureService temperatureService;

    @GetMapping
    public List<RecordedTemperature> getAllTemperatures(@RequestParam(required = false, defaultValue = "K") String scale) {
        return temperatureService.getAllTemperatures(scale);
    }

    @GetMapping("/{date}")
    public List<RecordedTemperature> getTemperaturesByDate(
            @PathVariable LocalDate date,
            @RequestParam(required = false, defaultValue = "K") String scale) {
        return temperatureService.getTemperaturesByDate(date, scale);
    }

    @PostMapping
    public ResponseEntity<RecordedTemperature> saveTemperature(@RequestBody RecordedTemperatureInputDTO temperature) {
        RecordedTemperature savedTemperature = temperatureService.saveTemperature(temperature.getTemperature(), temperature.getScale());
        return ResponseEntity.ok(savedTemperature);
    }
}
