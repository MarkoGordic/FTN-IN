package rs.ac.uns.ftn.example;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class SimpleServer {
	public static final int PORT = 8081;
	public static int clientCount = 0;
	
	public static void main(String args[]){
		ServerSocket ss = null;
		try{
			ss = new ServerSocket(PORT);	
		}catch(IOException ioe){
			System.out.println("Port nedostupan!");
			System.exit(-1);
		}
		System.out.println("Server startovan na adresi: "+ss.getInetAddress()+" i sluša na portu: "+ss.getLocalPort());
		//sad startovati server loop koji ceka da se klijenti jave
		while(true){
			Socket s = null; 
			try{
				// socket objekat koji će prihvatiti klijentski zahtev
				// ovde se kod blokira sve dok ne stigne zahtev sa klijenta
          s = ss.accept(); 
			}catch(IOException ioe){
				System.out.println("Ne mogu prihvatiti klijentsku konekciju");
				System.exit(-1);
			}
			
			//ako smo stigli ovde klijent je poslao nešto i socket je odradio acceptđ
      System.out.println("klijent se konektovao na server : " + s.getInetAddress()); 
      clientCount++;
      
      try{
          // sada treba pristupiti input stream-u kako bi mogli preuzeti ono što je stiglo sa klijenta
            DataInputStream in = new DataInputStream(s.getInputStream()); 
            // treba nam i output stream da preko njega možemo poslati podatke klijentu
            DataOutputStream out= new DataOutputStream(s.getOutputStream());
            // sada možemo predati klijentski zahtev na obradu, a server se može vratiti da čeka sledeću konekciju
            RequestHandlerClass reqHandler = new RequestHandlerClass(s,in,out,clientCount);
            
            // requestHandler je Thread, startuje se i on preuzima obradu
            reqHandler.start();
            
      }catch(IOException ioe){
				System.out.println("Ne mogu prihvatiti klijentsku konekciju");
				try{
					ss.close(); 
				}catch(IOException ioe1){
					System.out.println("Greska pri zatvaranju socketa");
				}
                
				System.exit(-1);
			}
            
		}
		
	}
}
