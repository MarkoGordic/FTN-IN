package rs.ac.uns.ftn.example;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class SimpleClient {
	
	public static void main(String args[]){
		
		try
        { 
            Scanner keyb = new Scanner(System.in); 
              
            // treba nam ip adresa servera, u ovom slucaju localhost 
            InetAddress ip = InetAddress.getByName("localhost"); 
      
            // kreira s ekonekcija na trazeni port 
            Socket s = new Socket(ip, 8081); 
      
            // kao i na serveru trebaju nam ulazni i izlazni stream 
            DataInputStream in = new DataInputStream(s.getInputStream()); 
            DataOutputStream out = new DataOutputStream(s.getOutputStream()); 
      
            // sada cemo razmenjivati poruke sa serverom sve dok ne posaljemo 
            //poruku exit
            
            while (true)  
            { 
                String toSend = keyb.nextLine(); 
                out.writeUTF(toSend); 
                  
                // printing date or time as requested by client 
                String received = in.readUTF(); 
                System.out.println(received); 
                if(toSend.equalsIgnoreCase("Exit")) 
                { 
                    System.out.println("Zatvaramo konekciju : " + s); 
                    in.close(); 
                    out.close(); 
                    s.close(); 
                    System.out.println("Konekcija zatvorena"); 
                    break; 
                }
            } 
              
            // closing resources 
            keyb.close(); 
            
        }catch(Exception e){ 
            e.printStackTrace(); 
        }
	}
}
