package rs.ac.uns.ftn.example;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RequestHandlerClass extends Thread {
	
	// klasa koja služi za handlanje klijentskih zahteva 
    private final DataInputStream dis; 
    private final DataOutputStream dos; 
    private final Socket s; 
    private final String id;
  
    // Constructor 
    public RequestHandlerClass(Socket s, DataInputStream dis, DataOutputStream dos, int cc)  
    { 
        this.s = s; 
        this.dis = dis; 
        this.dos = dos; 
        this.id="KLIJENT_"+cc;
    } 
  
    @Override
    public void run()  
    { 
        String received; 
        String retVal; 
        
        // i ovde se u beskonacnoj petlji obradjuje sve sto stize od klijenta
        // dok se ne dobije 
        while (true)  
        { 
            try { 
            	    // receive the answer from client 
                received = dis.readUTF(); 
                Date date = new Date(); 
                
                if(received.equalsIgnoreCase("Exit")) 
                {  
                    dos.writeUTF("@"+date.toString()+" Zatražen prekid konekcije - ćao!");
                    System.out.println("Client " + this.s + " sends exit..."); 
                    System.out.println("Closing this connection."); 
                    this.s.close(); 
                    System.out.println("Connection closed"); 
                    break; 
                } 
                  
                // creating Date object 
                retVal = "Server primio poruku:"+received+" u "+date.toString(); 
                System.out.println("Primljena poruka od:"+id+"\n\t"+received+" u "+date.toString());
                dos.writeUTF(retVal);
            } catch (IOException e) { 
                e.printStackTrace(); 
            } 
        } 
          
        try
        { 
            // zatvaranje resursa 
            System.out.println("Zatvaramo streamove");
            this.dis.close(); 
            this.dos.close(); 
              
        }catch(IOException e){ 
            e.printStackTrace(); 
        } 
        
    } 
}
