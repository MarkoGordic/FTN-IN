import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import model.Student;

public class Server
{
    private int port;
    private ServerSocket serverSocket;
    private ArrayList<Student> students;

    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public Server(int port)
            throws IOException
    {
        this.port = port;
        this.serverSocket = new ServerSocket(this.port);
        this.students = new ArrayList<>();
    }


    public void run()
    {
        System.out.println("Web server running on port: " + port);
        System.out.println("Document root is: " + new File("/static").getAbsolutePath() + "\n");

        Socket socket;

        while (true)
        {
            try
            {
                // prihvataj zahteve
                socket = serverSocket.accept();
                InetAddress addr = socket.getInetAddress();

                // dobavi resurs zahteva
                String resource = this.getResource(socket.getInputStream());
              
                // fail-safe
                if (resource == null)
                    continue;

                if (resource.equals(""))
                    resource = "static/index.html";

                System.out.println("Request from " + addr.getHostName() + ": " +  resource);

                // posalji odgovor
                this.sendResponse(resource, socket.getOutputStream());
                socket.close();
                socket = null;
            }
            catch (IOException ex)
            {
                ex.printStackTrace();
            }
        }
    }


    private String getResource(InputStream is)
            throws IOException
    {
        BufferedReader dis = new BufferedReader(new InputStreamReader(is));
        String s = dis.readLine();

        // fail-safe
        if (s == null)
            return null;

        String[] tokens = s.split(" ");

        // prva linija HTTP zahteva: METOD /resurs HTTP/verzija
        // obradjujemo samo GET metodu
        String method = tokens[0];
        if (!method.equals("GET"))
            return null;

        // String resursa
        String resource = tokens[1];

        // izbacimo znak '/' sa pocetka
        resource = resource.substring(1);
        // ignorisemo ostatak zaglavlja
        String s1;
        while (!(s1 = dis.readLine()).equals("")) {
            System.out.println(s1);
        }
    
        return resource;
    }


    private void sendResponse(String resource, OutputStream os)
            throws IOException
    {
        //prvi zadatak
        if (resource.startsWith("register")) {
            String response = register(resource);
            printResponse(response, os);
            return;
        }
        //drugi zadatak
        if (resource.startsWith("students")) {
            String response = studentsTable(resource);
            printResponse(response, os);
            return;
        }

        // zamenimo web separator sistemskim separatorom
        PrintStream ps = new PrintStream(os);
        resource = resource.replace('/', File.separatorChar);
        File file = new File(resource);

        if (!file.exists())
        {
            // ako datoteka ne postoji, vratimo kod za gresku
            String errorCode = "HTTP/1.0 404 File not found\r\n"
                    + "Content-type: text/html; charset=UTF-8\r\n\r\n<b>404 Not found:"
                    + file.getName() + "</b>";

            ps.print(errorCode);

//          ps.flush();
            System.out.println("Could not find resource: " + file);
            return;
        }

        // ispisemo zaglavlje HTTP odgovora
        ps.print("HTTP/1.0 200 OK\r\n\r\n");

        // a, zatim datoteku
        FileInputStream fis = new FileInputStream(file);
        byte[] data = new byte[8192];
        int len;

        while ((len = fis.read(data)) != -1)
            ps.write(data, 0, len);

        ps.flush();
        fis.close();
    }

    private void printResponse(String response, OutputStream os) throws UnsupportedEncodingException {
        PrintWriter pw = new PrintWriter(new OutputStreamWriter(os, "utf-8"), true);
        pw.print(response);
        pw.close();
        return;
    }

    private String register(String resource) {
        String param = resource.split("\\?")[1];
        System.out.println(param);
        String[] parameters = param.split("&");
        String name = parameters[0].split("=")[1];
        String lastname = parameters[1].split("=")[1];
        String username = parameters[2].split("=")[1];
        String password = parameters[3].split("=")[1];
        LocalDate date = LocalDate.parse(parameters[4].split("=")[1],formatter);
        String index = parameters[5].split("=")[1];

        if(!isStudentUsernameUnique(username)) {
            return invalidRequest("Postoji korisnik sa zadatim korisničkim imenom.");
        }

        if(!isIndexValid(index)) {
            return invalidRequest("Indeks nije validnog formata");
        }

        Student student = new Student(name, lastname, username, password, date, index);

        this.students.add(student);

        return "HTTP/1.0 200 OK\r\n" +
               "Content-type: text/html; charset=UTF-8\r\n\r\n" +
               "<html>" +
               "<body>" +
               "<p>Korisnik " + student.getKorisnickoIme() + " je uspješno registrovan!</p>" +
               "<a href=\"http://localhost:8080/\">Povratak na početnu stranicu</a>" +
               "</body>" +
               "</html>" ;

    }

    private boolean isStudentUsernameUnique(String username) {
        // for(Student s : students) {
        //     if(s.getKorisnickoIme().equalsIgnoreCase(username)) {
        //         return false;
        //     }
        // }
        // return true;
        return !students.stream().anyMatch(s -> s.getKorisnickoIme().equalsIgnoreCase(username));
    }

    private boolean isIndexValid(String index) {
        return Pattern.matches("RA-\\d{1,3}-\\d{4}", index);
    }

    private String invalidRequest(String text) {
        return "HTTP/1.0 400 Bad Request\r\n"
        + "Content-type: text/html; charset=UTF-8\r\n\r\n<b>Invalid: "
        + text + "</b>";
    }

    private String studentsTable(String resource) {
        if (students.isEmpty()) {
            return invalidRequest("Nema registrovanih studenata.");
        }

        String response = "HTTP/1.0 200 OK\r\n" +
                "Content-type: text/html; charset=UTF-8\r\n\r\n" +
                "<html>" +
                "<body>" +
                "<table border=\"1\">" + 
                "<tr>" + 
                "<th> Ime </th>" +
                "<th> Prezime </th>" +
                "<th> Korisničko Ime </th>" +
                "<th> Datum rođenja </th>" +
                "<th> Indeks </th>" + 
                "</tr>";

        for (Student s : this.students) {
            response += "<tr>" +
                        "<td>" + s.getIme() + "</td>" +
                        "<td>" + s.getPrezime() + "</td>" +
                        "<td>" + s.getKorisnickoIme() + "</td>" +
                        "<td>" + s.getDatumRodjenja().format(formatter) + "</td>" +
                        "<td>" + s.getIndeks() + "</td>" +
                        "</tr>";
        }

        response += "</table>" + 
                    "<a href=\"http://localhost:8080/\">Povratak na početnu stranicu</a>" +
                    "</body>" + 
                    "</html>";
        return response;
    }
}

