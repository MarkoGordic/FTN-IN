<template>
  <label for="firstName">First name:</label>
  <input v-model="employee.firstname" /><br />
  <label for="lastName">Last name:</label>
  <input v-model="employee.lastname" /><br />
  <label for="position">Position:</label>
  <input v-model="employee.position" /><br />
  <button v-on:click="submit()">submit</button>
</template>

<script>
import axios from "axios"
export default {
  name: "AddEmployeeView",
  data: function () {
    return {
      employee: {
        firstname: "",
        lastname: "",
        position: "",
      },
    };
  },
  methods: {
    submit: function () {

      axios
        .post("http://localhost:8081/api/employees", this.employee, { withCredentials: true })
        .then((res) => {
          console.log(res);
          this.$router.push("/employees");
        })
        .catch((err) => {
          console.log(err);
          alert("Something went wrong!");
        });

      // fetch("http://localhost:8081/api/employees", {
      //   method: "POST",
      //   credentials: 'include',
      //   headers: {
      //     Accept: "application/json",
      //     "Content-type": "application/json",
      //   },
      //   body: JSON.stringify(this.employee),
      // })
      //   .then((response) => response.json)
      //   .then((data) => {
      //     console.log("Success : " + data);
      //     this.$router.push("/employees");
      //   })
      //   .catch((err) => {
      //     console.log("Error : " + err);
      //     alert(err);
      //   });
    },
  },
};
</script>
