<template>
  <h1>Login</h1>
  <label for="username">Username:</label>
  <input v-model="employee.username" /><br />
  <label for="password">Password:</label>
  <input v-model="employee.password" /><br />
  <button v-on:click="login()">Login</button>
</template>

<script>
import axios from "axios";
export default {
  name: "LoginView",
  data: function () {
    return {
      employee: {},
    };
  },
  methods: {
    login: function () {
      axios
        .post("http://localhost:8081/api/login", this.employee, {
          withCredentials: true,
        })
        .then((res) => {
          console.log(res);
          this.$router.push("/home");
        })
        .catch((err) => {
          console.log(err);
          alert("Something went wrong!");
        });

      // fetch("http://localhost:8081/api/login", {
      //   method: "POST",
      //   credentials: "include",
      //   headers: {
      //     Accept: "application/json",
      //     "Content-type": "application/json",
      //   },
      //   body: JSON.stringify(this.employee),
      // })
      //   .then((response) => response.json)
      //   .then((data) => {
      //     console.log("Success : " + data);
      //     this.$router.push("/employees");
      //   })
      //   .catch((err) => {
      //     console.log("Error : " + err);
      //     alert(err);
      //   });
    },
  },
};
</script>