<template>
  <h1>Welcome</h1>

  <a type="button" href="/employees" class="btn">Show employee</a>
</template>

<script>
export default {
  name: "HomeView",
};
</script>
