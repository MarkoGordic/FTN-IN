<template>
  <tr>
    <td>{{ employee.firstname }}</td>
    <td>{{ employee.lastname }}</td>
    <td>{{ employee.position }}</td>
    <td>
      <button class="btnSeeMore" v-on:click="seeMore">See more</button>
    </td>
  </tr>
</template>

<script>
export default {
  name: "EmployeeComp",
  props: ["employee"],
  methods: {
    seeMore: function () {
      this.$router.push("/employee?id=" + this.employee.id);
    }
  },
};
</script>


<style>
</style>
